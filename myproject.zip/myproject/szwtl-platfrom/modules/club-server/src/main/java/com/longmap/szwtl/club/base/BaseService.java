package com.longmap.szwtl.club.base;

import com.alibaba.fastjson.JSON;

import com.longmap.szwtl.club.base.service.IAuthService;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.pojo.response.BaseUserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * @author Created by liuqm on 2019/8/12 10:33
 * @description
 **/
@Component
public class BaseService {

    @SuppressWarnings("all")
    @Autowired
    private IAuthService iAuthService;

    public BaseUserInfo getUserInfo() {
        ResponseResult responseResult = iAuthService.getUserInfo();
        BaseUserInfo baseUserInfo = null;
        if (ResponseStatus.SUCCESS.getStatus().equals(responseResult.getStatus())) {
            baseUserInfo = JSON.parseObject(JSON.toJSON(responseResult.getData()).toString(), BaseUserInfo.class);
            System.out.println(baseUserInfo);
        }
        return baseUserInfo;
    }




}
