package com.longmap.szwtl.club.mapper;

import com.longmap.szwtl.vo.ClubClassInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ClubClassInfoMapper {
    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(String clubId);

    /**
     *
     * @mbg.generated
     */
    int insert(ClubClassInfo record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(ClubClassInfo record);

    /**
     *根据社团id查询社团信息
     * @mbg.generated
     */
    ClubClassInfo selectByPrimaryKey(@Param("clubId") String clubId);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(ClubClassInfo record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(ClubClassInfo record);


    /**
     * 根据社团ID查询社团类型信息列表
     * @param clubId
     * @return
     */
    List<ClubClassInfo> selectByClubId(@Param("clubId") String clubId);

}