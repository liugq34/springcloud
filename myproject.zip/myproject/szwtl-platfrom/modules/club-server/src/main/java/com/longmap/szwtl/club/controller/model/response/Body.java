package com.longmap.szwtl.club.controller.model.response;

import lombok.Data;

/**
 * @author: liuqm
 * @create: 2019-08-14 14:20
 **/
@Data
public class Body {

    private String msgid;

    private String reserve;
}