package com.longmap.szwtl.club.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.club.controller.model.request.*;
import com.longmap.szwtl.club.enums.ClubInfoAuditsStatusEnum;
import com.longmap.szwtl.club.enums.ClubInfoStatus;
import com.longmap.szwtl.club.service.ClubInfoService;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @author liuqm  create on 2019/8/8 15:19
 * @description 社团接口
 **/
@RestController
@Api(tags = "社团增删查改，用于后台业务操作")
@RequestMapping("clubInfo")
public class ClubController {

    @Autowired
    private ClubInfoService clubService;


    /**
     * 根据社团id查询社团信息
     *
     * @return
     */
    @GetMapping("queryById/{clubId}")
    @ApiOperation("通过id查询社团信息")
    public ResponseResult queryById(@ApiParam("社团id") @PathVariable("clubId") String clubId) {
        try {
            Map<String,Object> map=new HashMap<String,Object>();
            ClubInfo clubInfo =clubService.queryClubInfoByClubId(clubId);
            map.put("clubInfo",clubInfo);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), map);
        } catch (BeansException e) {
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "查询失败！");
        }

    }

    /* 分页查询社团信息列表
     * @param clubInfoPageRequest
     * @return
     */
    @PostMapping("getClubInfoList")
    @ApiOperation("分页查询社团信息列表")
    public ResponseResult getClubInfoList(@RequestBody @ApiParam(value = "查询社团信息列表请求体") @Validated ClubInfoPageRequest clubInfoPageRequest) {
        try {
            PageInfo<ClubInfo> list = clubService.getClubInfoList(clubInfoPageRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<ClubInfo>(list));
        } catch (Exception e) {
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "查询社团信息列表失败");
        }
    }

    /**
     * 新增社团
     *
     * @param clubInfoRequest
     * @return
     */
    @PostMapping("addClubInfo")
    @ApiOperation("新增社团申请")
    public ResponseResult addClubInfo(@RequestBody @ApiParam("新增社团申请model") @Validated  ClubInfoRequest clubInfoRequest) {
        try {
            ClubInfo clubInfo = new ClubInfo();
            BeanUtils.copyProperties(clubInfoRequest, clubInfo);
            int result = clubService.addClubInfo(clubInfo);
            if (result > 0) {
                return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "社团申请操作成功");
            }
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "社团申请操作无效");
        } catch (BeansException e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "操作失败：" + e.getLocalizedMessage());
        }
    }


    /**
     * 修改加入社团
     *
     * @param clubInfoRequest
     * @return
     */
    @PostMapping("updateClubInfo")
    @ApiOperation("修改社团申请")
    public ResponseResult updateClubInfo(@RequestBody @ApiParam("修改社团model") @Validated  ClubInfoRequest clubInfoRequest) {
        try {
            ClubInfo clubInfo = new ClubInfo();
            BeanUtils.copyProperties(clubInfoRequest, clubInfo);
            int result = clubService.updateClubInfo(clubInfo);
            if (result > 0) {
                return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "社团申请操作成功");
            }
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "社团申请操作无效");
        } catch (BeansException e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "操作失败：" + e.getLocalizedMessage());
        }

    }

    /**
     * 修改审核状态
     *
     * @param auditStatusRequest
     * @return
     */
    @PostMapping("updateAuditStatus")
    @ApiOperation("修改审核状态")
    public ResponseResult updateAuditStatus(@RequestBody @ApiParam(value="修改审核状态model") @Validated AuditStatusRequest auditStatusRequest) {
        try {
            clubService.updateAuditStatus(auditStatusRequest);
        } catch (Exception e) {
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "操作失败：" + e.getLocalizedMessage());
        }
        if(ClubInfoAuditsStatusEnum.WAIT_AUDIT.getCode().equals(auditStatusRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"社团信息提交待审核成功");
        }else if(ClubInfoAuditsStatusEnum.AUDIT_SUCCESS.getCode().equals(auditStatusRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"社团信息审核通过成功");
        }else if(ClubInfoAuditsStatusEnum.AUDIT_FAIL.getCode().equals(auditStatusRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"社团信息审核不通过成功");
        }else if(ClubInfoAuditsStatusEnum.NOT_SUBMIT.getCode().equals(auditStatusRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"社团信息驳回成功");
        }
        return new ResponseResult(ResponseStatus.ERROR.getStatus(),"，系统繁忙，请重试");

    }


    /**
     * 删除社团
     */
    @PostMapping("/deleteClubInfo/{culbId}")
    @ApiOperation("删除社团")
    public ResponseResult deleteClubInfo(@ApiParam("社团信息表id") @PathVariable("culbId") String clubId){
        try {
            int result = clubService.deleteClubInfo(clubId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除成功");
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除失败");
        }
    }


    /**
     * 申请加入社团
     * @param clubInfoApplyRequest
     * @return
     */
    @PostMapping("clubInfoApplyShow")
    @ApiOperation("申请加入社团")
    public ResponseResult clubInfoApplyShow(@RequestBody @ApiParam(value="申请加入社团model") @Validated ClubInfoApplyRequest clubInfoApplyRequest){
        try {
            ClubApply clubApply = new ClubApply();
            BeanUtils.copyProperties(clubInfoApplyRequest, clubApply);
            int result =  clubService.clubInfoApplyShow(clubApply);
            if(result > 0){
                return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"社团申请操作成功");
            }
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"社团申请操作无效");
        } catch (BeansException e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
    }



    /**
     * 根据社团id查询社团信息
     *
     * @return
     */
    @GetMapping("queryAuditStatusLogById/{businessId}")
    @ApiOperation("通过id查询审核记录信息")
    public ResponseResult queryAuditStatusLogById(@ApiParam("对应业务表ID") @PathVariable("businessId") String businessId) {
        try {
            Map<String,Object> map=new HashMap<String,Object>();
            List<AuditStatusLog> auditStatusLogList =clubService.queryAuditStatusLogById(businessId);
            map.put("auditStatusLogList",auditStatusLogList);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), map);
        } catch (BeansException e) {
            return new ResponseResult(ResponseStatus.ERROR.getStatus(), "查询失败！");
        }

    }



    /* 根据用户id分页查询社团信息
     * @param userId
     * @return
     */
    @PostMapping("getClubInfoByUserList")
    @ApiOperation("社团用户列表分页查询")
    public ResponseResult getClubInfoByUserList(@RequestBody @ApiParam(value ="社团用户列表分页查询请求体") @Validated ClubInfoPersonalRequest clubInfoPersonalRequest){
        try {
            PageInfo<List<Map<String,Object>>> clubApplyList = clubService.getClubInfoByUserList(clubInfoPersonalRequest);
            return new ResponseResult(com.longmap.szwtl.common.response.ResponseStatus.SUCCESS.getStatus(), clubApplyList);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询社团信息列表失败");
        }
    }



    /**
     * 后台系统社团上下架状态
     * @param clubId
     * @param clubStatus
     * @return
     */
    @PostMapping("/updateStatus/{clubId}/{clubStatus}")
    @ApiOperation("社团上下架状态变更")
    public ResponseResult updateStatus(@ApiParam("社团id") @PathVariable("clubId") String clubId, @ApiParam("上下架状态") @PathVariable("clubStatus") Integer clubStatus){
        try {
            clubService.updateClubStatus(clubId, clubStatus);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
        if(ClubInfoStatus.UP_CLUB_STATUS.getCode().equals(clubStatus)){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"社团信息上架成功");
        }else if(ClubInfoStatus.DOWN_CLUB_STATUS.getCode().equals(clubStatus)){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"社团信息下架成功");
        }
        return new ResponseResult(ResponseStatus.ERROR.getStatus(),"，系统繁忙，请重试");
    }



}

