package com.longmap.szwtl.club.service;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.club.controller.model.request.AuditStatusRequest;
import com.longmap.szwtl.club.controller.model.request.ClubInfoPageRequest;
import com.longmap.szwtl.club.controller.model.request.ClubInfoPersonalRequest;
import com.longmap.szwtl.common.exception.RestRuntimeException;
import com.longmap.szwtl.vo.AuditStatusLog;
import com.longmap.szwtl.vo.ClubApply;
import com.longmap.szwtl.vo.ClubInfo;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;


/**
 * @author liuqm  create on 2019/8/8 15:19
 *  * @description 社团接口
 */
public interface ClubInfoService {


    /**
     * 新增社团申请
     * @param clubInfo 申请内容
     * @return
     */
    public int addClubInfo(ClubInfo clubInfo);

    /**
     * 修改社团信息
     * @param clubInfo
     * @return
     */
    public int updateClubInfo(ClubInfo clubInfo);


    /**
     * 根据社团id查询社团详情
     * @param clubId 社团id
     * @return
     */
    public ClubInfo queryClubInfoByClubId(@Param("clubId") String clubId);



    /**
     * 分页条件查询-获取列表
     * @param
     * @return
     */
    public PageInfo<ClubInfo> getClubInfoList(ClubInfoPageRequest clubInfoPageRequest);


    /**
     * 修改审核状态
     * @param auditStatusRequest
     * @return
     */
    public  int  updateAuditStatus(AuditStatusRequest auditStatusRequest);

    /**
     * 根据社团id删除社团基本信息
     * @param clubId
     * @return
     * @throws RestRuntimeException
     */
    public int deleteClubInfo(String clubId) throws RestRuntimeException;




    /**
     * 申请加入社团申请
     * @param clubApply 申请内容
     * @return
     */
    public int clubInfoApplyShow(ClubApply clubApply);


    /**
     * 根据id查询审核记录信息
     * @param businessId 业务id
     * @return
     */
    public List<AuditStatusLog> queryAuditStatusLogById(@Param("businessId") String businessId);




    /**
     * 社团用户列表分页查询
     * @param clubInfoPersonalRequest
     * @return
     */
    public PageInfo<List<Map<String,Object>>> getClubInfoByUserList(ClubInfoPersonalRequest clubInfoPersonalRequest);


    /**
     * 不分页查询列表
     * @param clubInfo
     * @return
     */
    public  List<ClubInfo> getClubInfoListByWhere(ClubInfo clubInfo);


    /**
     * 后台系统社团上下架状态
     * @param clubId
     * @param clubStatus
     * @return
     * @throws RestRuntimeException
     */
    public int updateClubStatus(String clubId, Integer clubStatus)throws RestRuntimeException;





}
