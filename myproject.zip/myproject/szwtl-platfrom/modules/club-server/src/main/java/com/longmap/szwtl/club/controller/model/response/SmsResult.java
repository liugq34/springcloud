package com.longmap.szwtl.club.controller.model.response;

import com.longmap.szwtl.club.controller.model.response.Body;
import com.longmap.szwtl.club.controller.model.response.Head;
import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * @author: liuqm
 * @create: 2019-08-14 14:20
 **/
@XmlRootElement(name = "response")
@Data
public class SmsResult implements Serializable {

    /**
     * 响应头
     */
    private Head head;

    /**
     * 响应信息
     */
    private Body body;

}
