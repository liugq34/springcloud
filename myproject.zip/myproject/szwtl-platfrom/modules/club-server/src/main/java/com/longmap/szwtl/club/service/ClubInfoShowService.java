package com.longmap.szwtl.club.service;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.club.controller.model.request.*;
import com.longmap.szwtl.common.exception.RestRuntimeException;
import com.longmap.szwtl.vo.ClubInfo;



public interface ClubInfoShowService {



    /**
     * 根据社团id查询社团信息
     * @param clubInfoDetailsQueryRequest 社团id
     * @return
     */
    public ClubInfo queryClubInfoShowById(ClubInfoDetailsQueryRequest clubInfoDetailsQueryRequest);




    /**
     * 社团信息表条件查询-获取列表
     * @param
     * @return
     */
    public PageInfo<ClubInfo> getClubInfoShowList(ClubInfoShowRequest clubInfoShowRequest);




    /**
     * 根据用户id分页查询社团信息
     * @param
     * @return
     */
    public PageInfo<ClubInfo> getClubInfoShowByUserId(ClubInfoApplyQueryRequest clubInfoApplyQueryRequest);


    /**
     * 退出社团
     * @param clubId
     *
     * @return
     * @throws RestRuntimeException
     */
    public int signOutClub(String userId,String clubId) throws RestRuntimeException;



    /**
     * 热门推荐条件查询-获取列表
     * @param
     * @return
     */
    public PageInfo<ClubInfo> getRecommendList(ClubInfoDetailsQueryRequest clubInfoDetailsQueryRequest);







}
