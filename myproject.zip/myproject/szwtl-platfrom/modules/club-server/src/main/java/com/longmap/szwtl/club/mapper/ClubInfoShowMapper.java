package com.longmap.szwtl.club.mapper;


import com.longmap.szwtl.vo.ClubInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;


@Mapper
public interface ClubInfoShowMapper {


    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(String clubId);

    /**
     *
     * @mbg.generated
     */
    int insert(ClubInfo record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(ClubInfo record);

    /**
     *
     * @mbg.generated
     */
    ClubInfo selectByPrimaryKey( String clubId);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(ClubInfo record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(ClubInfo record);


    /**
     * 社团信息分页条件查询
     * @param clubInfo
     * @return
     */
    public List<ClubInfo> getClubInfoShowList(ClubInfo clubInfo);


    /**
     * 根据社团类型推荐社团信息
     * @param clubId
     * @return
     */
    public List<ClubInfo> getRecommendList(@Param("clubId")String  clubId);


    /**
     * 根据用户id分页查询社团信息
     * @param clubInfo
     * @return
     */
    public List<ClubInfo> getClubInfoShowByUserIdList(ClubInfo clubInfo);


    /**
     *根据社团id查询社团信息
     * @mbg.generated
     */
    ClubInfo queryClubInfoShowById(@Param("clubId") String clubId);



}
