package com.longmap.szwtl.club.base.service;

import com.longmap.szwtl.club.base.fallback.IAuthServiceFallbackFactory;
import com.longmap.szwtl.common.response.ResponseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author Created by oushaohui on 2019/8/5 10:29
 * @description
 **/
@FeignClient(name = "auth-server", fallbackFactory = IAuthServiceFallbackFactory.class)
public interface IAuthService {


    /**
     * 获取当前用户信息
     * @return
     */
    @GetMapping(value = "/getUserInfo")
    ResponseResult getUserInfo();
}
