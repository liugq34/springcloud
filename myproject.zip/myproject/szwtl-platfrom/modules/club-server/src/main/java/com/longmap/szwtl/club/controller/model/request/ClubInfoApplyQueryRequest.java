package com.longmap.szwtl.club.controller.model.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;

@Data
@ApiModel("个人中心--用户查询model")
public class ClubInfoApplyQueryRequest extends CommonPage implements Serializable {
    
    /**
     * 用户ID
     */
    @ApiModelProperty("用户ID")
    private String userId;


    /**
     * 社团类型ID
     */
    @ApiModelProperty("社团类型ID")
    private String clubClassId;

}
