package com.longmap.szwtl.club.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.club.base.BaseService;
import com.longmap.szwtl.club.controller.model.request.AuditStatusRequest;
import com.longmap.szwtl.club.controller.model.request.ClubInfoPageRequest;
import com.longmap.szwtl.club.controller.model.request.ClubInfoPersonalRequest;
import com.longmap.szwtl.club.enums.ClubInfoAuditsStatusEnum;
import com.longmap.szwtl.club.mapper.AuditStatusLogMapper;
import com.longmap.szwtl.club.mapper.ClubApplyMapper;
import com.longmap.szwtl.club.mapper.ClubClassInfoMapper;
import com.longmap.szwtl.club.mapper.ClubInfoMapper;
import com.longmap.szwtl.club.service.ClubInfoService;
import com.longmap.szwtl.club.service.SmsService;
import com.longmap.szwtl.club.util.RandomNubUtil;
import com.longmap.szwtl.common.exception.RestRuntimeException;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.pojo.request.EnterpriseAuditRequest;
import com.longmap.szwtl.pojo.response.BaseUserInfo;
import com.longmap.szwtl.util.UUID;
import com.longmap.szwtl.vo.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import java.text.MessageFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

;


/**
 *
 * 社团接口
 * @author liuqm  create on 2019/8/8
 *  * @description 社团
 */
@Service
public class ClubInfoServiceImpl implements ClubInfoService {

    @SuppressWarnings("all")
    @Autowired
    private ClubInfoMapper clubInfoMapper;


    @SuppressWarnings("all")
    @Autowired
    private AuditStatusLogMapper auditStatusLogMapper;


    @SuppressWarnings("all")
    @Autowired
    public ClubApplyMapper clubApplyMapper;

    @SuppressWarnings("all")
    @Autowired
    public ClubClassInfoMapper clubClassInfoMapper;


    @Autowired
    private BaseService baseService;

    @SuppressWarnings("all")
    @Autowired
    private SmsService smsService;


    private RedisTemplate redisTemplate;

    @Value("${sms.type.auditFail}")
    public String auditFailTemplate;


    @Value("${sms.type.auditSuccess}")
    public String auditSuccessTemplate;





    /**
     * 新增社团信息
     * @param clubInfo 申请内容
     * @return
     */
    @Override
    public int addClubInfo(ClubInfo clubInfo) {

        int result  = 0;
        try {
            //UUID 生成主键
            clubInfo.setClubId(UUID.randomUUID());
            // 判断审核状态是否有值,没传值就保存默认值
            if(clubInfo.getAuditStatus()==null || clubInfo.getAuditStatus().equals("")){
                clubInfo.setAuditStatus(ClubInfoAuditsStatusEnum.WAIT_AUDIT.getCode());// 审核状态
            }
           //获取当前用户
            BaseUserInfo baseUserInfo = baseService.getUserInfo();
            clubInfo.setCreateUser(baseUserInfo.getId());
            clubInfo.setCreatedTime(new Date()); // 创建时间
            clubInfo.setModifiedTime(new Date());// 修改时间
            clubInfo.setClubStatus(1);// 上下架状态默认1（下架）
            clubInfo.setEnterpriseid(baseUserInfo.getEnterpriseId());// 企业id
            if(!StringUtils.isEmpty(baseUserInfo.getProvinceId())){
                clubInfo.setProvinceId(baseUserInfo.getProvinceId());
            }
            if(!StringUtils.isEmpty(baseUserInfo.getProvinceName())){
                clubInfo.setProvinceName(baseUserInfo.getProvinceName());
            }

            if(!StringUtils.isEmpty(baseUserInfo.getCityId())){
                clubInfo.setCityId(baseUserInfo.getCityId());
            }
            if(!StringUtils.isEmpty(baseUserInfo.getCityName())){
                clubInfo.setCityName(baseUserInfo.getCityName());
            }
            if(!StringUtils.isEmpty(baseUserInfo.getDistrictId())){
                clubInfo.setDistrictId(baseUserInfo.getDistrictId());
            }
            if(!StringUtils.isEmpty(baseUserInfo.getDistrictName())){
                clubInfo.setDistrictName(baseUserInfo.getDistrictName());
            }
            if(!StringUtils.isEmpty(baseUserInfo.getSubDistrictId())){
                clubInfo.setDistrictName(baseUserInfo.getSubDistrictId());
            }
            if(!StringUtils.isEmpty(baseUserInfo.getSubDistrictName())){
                clubInfo.setSubDistrictName(baseUserInfo.getSubDistrictName());
            }
            // 添加社团信息
            result  = clubInfoMapper.insert(clubInfo);

            // 添加社团类型表
            ClubClassInfo clubClassInfo =new ClubClassInfo();
            clubClassInfo.setClubId(clubInfo.getClubId());
            // 拆分社团类型名称
            String clubClassNmae=clubInfo.getClubClassName();
            String[] split =clubClassNmae.split(",");
            // 拆分社团类型id
            String clubClassId= clubInfo.getClubClassId();
            String[] splitStr =clubClassId.split(",");

            for (int i=0;i<splitStr.length;i++){
                clubClassInfo.setClubClassId(splitStr[i]);
                clubClassInfo.setClubClassName(split[i]);
                clubClassInfo.setId(UUID.randomUUID());
                result =clubClassInfoMapper.insert(clubClassInfo);
            }

            // 添加审核记录
            AuditStatusLog auditStatusLog =new AuditStatusLog();
            auditStatusLog.setId(UUID.randomUUID());
            auditStatusLog.setBusinessId(clubInfo.getClubId());
            auditStatusLog.setCreateUserId(baseUserInfo.getId());
            auditStatusLog.setCreateUserName(baseUserInfo.getAccount());
            auditStatusLog.setAuditStatus(ClubInfoAuditsStatusEnum.NOT_SUBMIT.getCode().longValue());
            auditStatusLog.setCreateTime(new Date());
            auditStatusLogMapper.insert(auditStatusLog);
        }
        catch (Exception e){
            e.printStackTrace();
            throw new RestRuntimeException(ResponseStatus.ERROR.getStatus(),"程序异常");
        }
        return result;

    }


    /**
     * 分页查询社团信息列表
     * @param clubInfoPageRequest
     * @return
     */
    @Override
    public PageInfo<ClubInfo> getClubInfoList(ClubInfoPageRequest clubInfoPageRequest) {

        ClubInfo clubInfo=new ClubInfo();
        if(clubInfoPageRequest.getClubClassId() != null){
            clubInfo.setClubClassId(clubInfoPageRequest.getClubClassId());
        }
        // 区域编码
        if(clubInfoPageRequest.getDistrictId() != null){
            clubInfo.setDistrictId(clubInfoPageRequest.getDistrictId());
        }
        // 招募状态
        if(clubInfoPageRequest.getStatus() != null){
            clubInfo.setStatus(clubInfoPageRequest.getStatus());
        }
        // 审核状态
        if(clubInfoPageRequest.getAuditStatus() != null){
            clubInfo.setAuditStatus(clubInfoPageRequest.getAuditStatus());
        }
        // 社团名称
        if(clubInfoPageRequest.getClubName() != null){
            clubInfo.setClubName(clubInfoPageRequest.getClubName());
        }
        // 判断是企业用户还是管理员
        BaseUserInfo baseUserInfo = baseService.getUserInfo();
        if(baseUserInfo.getRoles().get(0).getRoleCode().equals("VENUE_GUEST") || baseUserInfo.getRoles().get(0).getRoleCode().equals("VENUE_ADMINISTRATOR")||
                baseUserInfo.getRoles().get(0).getRoleCode().equals("ENTERPRISE_ADMINISTRATOR")){
            clubInfo.setEnterpriseid(baseUserInfo.getEnterpriseId());// 企业id
        }
        //
        PageHelper.startPage(clubInfoPageRequest.getPageNum(), clubInfoPageRequest.getPageSize());
        List<ClubInfo> list = clubInfoMapper.getClubInfoList(clubInfo);
        PageInfo page = new PageInfo(list);
        return page;
    }

    /**
     * 根据社团id查询社团信息
     * @param clubId 社团id
     * @return
     */
    @Override
    public ClubInfo queryClubInfoByClubId(String clubId) {

        // 根据社团id查询社团基本信息表
        ClubInfo clubInfo=clubInfoMapper.selectByPrimaryKey(clubId);
        // 根据社团id查询社团类型表
        List<ClubClassInfo> clubClassInfoList=clubClassInfoMapper.selectByClubId(clubId);
        if(clubClassInfoList.size()>0){
            // 拼接社团名称
            String className="";
            // 拼接社团类型
            String ClubClassId="";
            for (ClubClassInfo clubClassInfo : clubClassInfoList){
                className+=clubClassInfo.getClubClassName()+",";
                ClubClassId+=clubClassInfo.getClubClassId()+",";
            }
            className=className.substring(0,className.length()-1);
            clubInfo.setClubClassName(className);
            //
            ClubClassId=ClubClassId.substring(0,ClubClassId.length()-1);
            clubInfo.setClubClassId(ClubClassId);
        }

        return clubInfo;
    }



    /**
     * 修改社团信息
     * @param clubInfo 社团实体类
     * @return
     * @throws RestRuntimeException
     */
    @Override
    public int updateClubInfo(ClubInfo clubInfo) throws RestRuntimeException {
        int result = 0;
        //活动是否存在
        ClubInfo newClubInfo = clubInfoMapper.selectByPrimaryKey(clubInfo.getClubId());
        if(newClubInfo==null ){
            throw new RestRuntimeException(ResponseStatus.STATUS_INCONFORMITY.getStatus(),"该社团已删除");
        }
        //审核通过之后不能修改
        if(newClubInfo.getAuditStatus().equals(ClubInfoAuditsStatusEnum.AUDIT_SUCCESS.getCode())){
            throw new RestRuntimeException(ResponseStatus.STATUS_INCONFORMITY.getStatus(),"通过审核，不能修改");
        }
        // 根据社团id查询社团类型表
        List<ClubClassInfo> clubClassList=clubClassInfoMapper.selectByClubId(clubInfo.getClubId());
        // 删除申请社团类型表
        for(int i=0;i<clubClassList.size();i++){
            result = clubClassInfoMapper.deleteByPrimaryKey(clubClassList.get(i).getClubId());
        }
        // 将修改后的社团类型新增到申请社团类型表中
        ClubClassInfo newClubClassInfo =new ClubClassInfo();
        newClubClassInfo.setClubId(clubInfo.getClubId());
        // 拆分社团名称
        String clubClassNmae=clubInfo.getClubClassName();
        String[] split =clubClassNmae.split(",");
        String clubClassId= clubInfo.getClubClassId();
        String[] splitStr =clubClassId.split(",");
        for (int i=0;i<splitStr.length;i++){
            newClubClassInfo.setClubClassId(splitStr[i]);
            newClubClassInfo.setClubClassName(split[i]);
            newClubClassInfo.setId(UUID.randomUUID());
            result = clubClassInfoMapper.insert(newClubClassInfo);
        }
        clubInfo.setModifiedTime(new Date());
        // 修改社团基本信息
        result =  clubInfoMapper.updateByPrimaryKeySelective(clubInfo);

        //获取当前用户
        BaseUserInfo baseUserInfo = baseService.getUserInfo();
        clubInfo.setCreateUser(baseUserInfo.getId());
        // 添加审核记录
        AuditStatusLog auditStatusLog =new AuditStatusLog();
        auditStatusLog.setId(UUID.randomUUID());
        auditStatusLog.setBusinessId(clubInfo.getClubId());
        auditStatusLog.setCreateUserId(baseUserInfo.getId());
        auditStatusLog.setCreateUserName(baseUserInfo.getAccount());
        // 判断是否是待审核状态
        if(ClubInfoAuditsStatusEnum.WAIT_AUDIT.getCode().equals(clubInfo.getAuditStatus())){
            auditStatusLog.setAuditStatus(ClubInfoAuditsStatusEnum.WAIT_AUDIT.getCode().longValue());
        }
        auditStatusLog.setCreateTime(new Date());
        auditStatusLogMapper.insert(auditStatusLog);

        return result;
    }

    /**
     * 删除社团
     * @param clubId
     * @return
     * @throws RestRuntimeException
     */
    @Override
    public int deleteClubInfo(String clubId) throws RestRuntimeException {
        int result = 0;
        // 删除社团基本信息表
        ClubInfo clubInfo = new ClubInfo();
        clubInfo.setClubId(clubId);
        result = clubInfoMapper.deleteByPrimaryKey(clubId);
        // 删除社团类型表
        ClubClassInfo clubClassInfo =new ClubClassInfo();
        clubClassInfo.setId(clubId);
        result = clubClassInfoMapper.deleteByPrimaryKey(clubId);
        return result;
    }



    /**
     * 修改审核状态
     * @param auditStatusRequest 社团id
     * @return
     */
    @Override
    public int updateAuditStatus(AuditStatusRequest auditStatusRequest) {
        int result = 0;
        try {
            //只有未提交才能提交待审核
            ClubInfo clubInfo = clubInfoMapper.selectByPrimaryKey(auditStatusRequest.getClubId());
            if(clubInfo==null){
                throw new RestRuntimeException(ResponseStatus.STOCK_NULL.getStatus(),"社团信息不存在");
            }
            ClubInfo newClubInfo = new ClubInfo();
            newClubInfo.setClubId(auditStatusRequest.getClubId());
            newClubInfo.setAuditStatus(auditStatusRequest.getAuditStatus());
            newClubInfo.setAuditRemark(auditStatusRequest.getAuditRemark());
            //获取当前用户
            BaseUserInfo baseUserInfo = baseService.getUserInfo();
            newClubInfo.setCreateUser(baseUserInfo.getAccount());
            newClubInfo.setCreateUserId(baseUserInfo.getId());
            //
            result = clubInfoMapper.updateByPrimaryKeySelective(newClubInfo);

            // 添加审核记录
            AuditStatusLog auditStatusLog =new AuditStatusLog();
            auditStatusLog.setId(UUID.randomUUID());
            auditStatusLog.setBusinessId(clubInfo.getClubId());
            auditStatusLog.setCreateUserId(baseUserInfo.getId());
            auditStatusLog.setCreateUserName(baseUserInfo.getAccount());
            auditStatusLog.setCreateTime(new Date());
            //if(ClubInfoAuditsStatusEnum.AUDIT_FAIL.getCode().equals(auditStatusRequest.getAuditStatus())){ //审核不通过
            auditStatusLog.setRollbackReason(auditStatusRequest.getRollbackRason()); // 原因
            auditStatusLog.setModifiedSuggest(auditStatusRequest.getAuditRemark());// 修改建议
            //}
           auditStatusLog.setAuditStatus(auditStatusRequest.getAuditStatus().longValue());
           auditStatusLogMapper.insert(auditStatusLog);

            // 短信审核
            // 审核不通过
            if(ClubInfoAuditsStatusEnum.AUDIT_FAIL.getCode().equals(auditStatusRequest.getAuditStatus())) {
                EnterpriseAuditRequest request = new EnterpriseAuditRequest();
                request.setAccount(clubInfo.getPhone());
                request.setMsg(auditStatusRequest.getAuditRemark());
                request.setType(1);
                String  content;
                Object [] params = new String[]{auditStatusRequest.getAuditRemark()};
                content = MessageFormat.format(auditFailTemplate, params);
               // smsService.sendSms(clubInfo.getPhone(), content); // 暂时注释发短信功能

                // 审核通过
            }else if (ClubInfoAuditsStatusEnum.AUDIT_SUCCESS.getCode().equals(auditStatusRequest.getAuditStatus()) ){
                String password = RandomNubUtil.getStringRandom(8);
                EnterpriseAuditRequest request = new EnterpriseAuditRequest();
                request.setAccount(clubInfo.getPhone());
                request.setPassword(password);
                request.setType(0);
                String content;
                Object [] params = new String[]{clubInfo.getPhone(),password};
                content = MessageFormat.format(auditSuccessTemplate, params);
                //smsService.sendSms(clubInfo.getPhone(), content);

                // 审核通过更改上下架状态为正常
                newClubInfo.setClubStatus(0);
                result = clubInfoMapper.updateByClubStatus(newClubInfo);
            }
        }catch (Exception e){
            e.printStackTrace();
            throw new RestRuntimeException(ResponseStatus.ERROR.getStatus(),"程序出现异常");
        }
        return result;
    }




    /**
     * 申请加入社团
     * @param clubApply 申请内容
     * @return
     */
    @Override
    public int clubInfoApplyShow(ClubApply clubApply) {
        int result  = 0;
        try {
            //查询社团信息表是否存在，
            ClubInfo clubInfo= clubInfoMapper.selectByPrimaryKey(clubApply.getClubId());
            if(clubInfo==null){
                throw new RestRuntimeException(ResponseStatus.STOCK_NULL.getStatus(),"社团信息不存在");
            }
            // 判断招募状态是否满员
            if(clubInfo.getStatus().equals("4")){
                throw new RestRuntimeException(ResponseStatus.STOCK_NULL.getStatus(),"改社团暂不招募");
            }
            //UUID 生成主键
            clubApply.setId(UUID.randomUUID());
            clubApply.setClubId(clubApply.getClubId());
            clubApply.setUserId(clubApply.getUserId());
            //获取当前用户
            BaseUserInfo baseUserInfo = baseService.getUserInfo();
            clubApply.setAccount(baseUserInfo.getAccount()); // 登录账号
            clubApply.setRealname(baseUserInfo.getRealname());// 真实名称
            clubApply.setStatus(1); // 已加入
            clubApply.setCreatedTime(new Date());
            // 新增社团申请信息
            result  = clubApplyMapper.insert(clubApply);
            // 修改社团信息表招募人数进行修改（招募人数-1）
            int recruitmentNum =clubInfo.getRecruitment()-1;
            ClubInfo newClubInfo=new ClubInfo();
            newClubInfo.setClubId(clubApply.getClubId());
            newClubInfo.setRecruitment(recruitmentNum);
            result =clubInfoMapper.updateByPrimaryKeySelective(newClubInfo);
        }
        catch (Exception e){
            e.printStackTrace();
            throw new RestRuntimeException(ResponseStatus.ERROR.getStatus(),"程序异常");
        }
        return result;
    }


    /**
     * 根据id查询审核记录表
     * @param id 审核id
     * @return
     */
    @Override
    public List<AuditStatusLog> queryAuditStatusLogById(String id) {
        return auditStatusLogMapper.selectByBusinessId(id);
    }


    /**
     * 社团用户列表分页查询
     * @param clubInfoPersonalRequest
     * @return
     */
    @Override
    public PageInfo<List<Map<String,Object>>> getClubInfoByUserList(ClubInfoPersonalRequest clubInfoPersonalRequest) {
        ClubApply clubApply=new ClubApply();
        // 用户名称
        if(clubInfoPersonalRequest.getRealname() != null){
            clubApply.setRealname(clubInfoPersonalRequest.getRealname());
        }
        // 用户状态
        clubApply.setStatus(clubApply.getStatus());
        // 社团名称
        if(clubInfoPersonalRequest.getClubName() != null){
            clubApply.setClubName(clubInfoPersonalRequest.getClubName());
        }
        PageHelper.startPage(clubInfoPersonalRequest.getPageNum(), clubInfoPersonalRequest.getPageSize());
        List<Map<String,Object>> list = clubApplyMapper.getClubInfoByUserList(clubApply);
        PageInfo page = new PageInfo(list);
        return page;
    }

    /**
     * 不分页查询列表
     * @param clubInfo
     * @return
     */
     public  List<ClubInfo> getClubInfoListByWhere(ClubInfo clubInfo){
         clubInfo.setAuditStatus(ClubInfoAuditsStatusEnum.AUDIT_SUCCESS.getCode());
        return clubInfoMapper.getClubInfoList(clubInfo);
     }


    /**
     * 上下架状态变更
     * @param clubId
     * @param clubStatus
     * @return
     */
    @Override
    @Transactional
    public int updateClubStatus(String clubId, Integer clubStatus)throws RestRuntimeException{
        int result = 0;
        //只有未提交才能提交待审核
        ClubInfo clubInfo = clubInfoMapper.selectByPrimaryKey(clubId);
        if(clubInfo==null){
            throw new RestRuntimeException(ResponseStatus.STOCK_NULL.getStatus(),"社团不存在！");
        }
        ClubInfo newClubInfo = new ClubInfo();
        newClubInfo.setClubId(clubId);
        newClubInfo.setClubStatus(clubStatus);
        result = clubInfoMapper.updateByClubStatus(newClubInfo);
        return  result;
    }



}
