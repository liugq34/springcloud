package com.longmap.szwtl.club.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("申请加入社团model")
public class ClubInfoApplyRequest {

    /**
     * 社团ID
     */
    @ApiModelProperty("社团ID")
    private String clubId;



    /**
     * 用户ID
     */
    @ApiModelProperty("用户ID")
    private String userId;



}
