package com.longmap.szwtl.club.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("分页")
public class CommonPage implements Serializable {

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;
}
