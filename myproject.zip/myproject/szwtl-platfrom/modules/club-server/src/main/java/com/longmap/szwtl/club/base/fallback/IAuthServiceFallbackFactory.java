package com.longmap.szwtl.club.base.fallback;


import com.longmap.szwtl.club.base.service.IAuthService;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;

import feign.hystrix.FallbackFactory;
import org.springframework.stereotype.Component;

/**
 * @author Created by liuqm on 2019/8/15 10:31
 * @description
 **/
@Component
public class IAuthServiceFallbackFactory implements FallbackFactory<IAuthService> {
    @Override
    public IAuthService create(Throwable cause) {
        cause.printStackTrace();
        return new IAuthService() {
            @Override
            public ResponseResult getUserInfo() {
                ResponseResult responseResult = new ResponseResult();
                responseResult.setStatus(ResponseStatus.ERROR.getStatus());
                responseResult.setMessage(ResponseStatus.ERROR.getMessage());
                return responseResult;
            }
        };
    }
}
