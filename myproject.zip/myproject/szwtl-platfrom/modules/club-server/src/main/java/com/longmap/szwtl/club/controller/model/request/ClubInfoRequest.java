package com.longmap.szwtl.club.controller.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
import java.util.Date;

@Data
@ApiModel("后台新增申请model")
public class ClubInfoRequest implements Serializable {


    /**
     * 社团ID
     *
     */
    @ApiModelProperty(value="社团ID 新增不填")
    private String clubId;


    /**
     * 社团名称
     */
    @ApiModelProperty("社团名称")
    private String clubName;


    /**
     * 社团类别（1.音乐、2.舞蹈、3.戏剧、4.曲艺、5.书画、6.影视、7.志愿者、8.健身、9.其他）
     */
    @ApiModelProperty("社团类别")
    private String clubClassId;




    /**
     * 社团类型名称
     */
    @ApiModelProperty("社团类型名称")
    private String clubClassName;



    /**
     * 招募状态（1.最新发布、2.人气 3.招募中、4.满员）
     */
    @ApiModelProperty("招募状态")
    private Integer status;

    /**
     * 招募时间
     */

    @ApiModelProperty("招募时间")
    private String recruitmentTime;


    /**
     * 招募人数
     */
    @ApiModelProperty("招募人数")
    private Integer recruitment;



    /**
     * 团队所在地
     */
    @ApiModelProperty("团队所在地")
    private String address;

    /**
     * 经度
     */
    @ApiModelProperty("经度")
    private String longitude;


    /**
     * 经度
     */
    @ApiModelProperty("纬度")
    private String latitude;

    /**
     * 申请手机号
     */
    @ApiModelProperty("申请手机号")
    private String phone;


    /**
     * 招募要求
     */
    @ApiModelProperty("招募要求")
    private String recruitmentRequirements;


    /**
     * 社团风采
     */
    @ApiModelProperty("社团风采")
    private String communityElegance;


    /**
     * 社团介绍
     */
    @ApiModelProperty("社团介绍")
    private String communityIntroduction;



    /**
     * 成立时间
     */
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("成立时间")
    private Date establishmentTime;


    /**
     * 横图（滚动图片）
     */
    @ApiModelProperty("横图")
    private String pictureHorizontal;

    /**
     * 竖图（滚动图片）
     */
    @ApiModelProperty("竖图")
    private String pictureVertical;

    /**
     * 原图（滚动图片）
     */
    @ApiModelProperty("原图")
    private String picture;

    /**
     * 已招募人员
     */
    @ApiModelProperty("已招募人员")
    private Integer alreadyNum;



    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseid;

    /**
     * 省编码
     */
    @ApiModelProperty("省编码")
    private String provinceId;

    /**
     * 省名称
     */
    @ApiModelProperty("省名称")
    private String provinceName;

    /**
     * 市编码
     */
    @ApiModelProperty("市编码")
    private String cityId;

    /**
     * 市名称
     */
    @ApiModelProperty("市名称")
    private String cityName;

    /**
     * 区域编码
     */
    @ApiModelProperty("区域编码")
    private String districtId;

    /**
     * 区域名称
     */
    @ApiModelProperty("区域名称")
    private String districtName;

    /**
     * 街道编码
     */
    @ApiModelProperty("街道编码")
    private String subDistrictId;

    /**
     * 街道名称
     */
    @ApiModelProperty("街道名称")
    private String subDistrictName;


    @ApiModelProperty("审核状态")
    private Integer auditStatus;

}
