package com.longmap.szwtl.club.controller.model.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
@ApiModel("修改审核状态model")
public class AuditStatusRequest {

    /**
     * 社团id
     */
    @ApiModelProperty("社团id")
    private String clubId;

    /**
     * 审核状态
     */
    @ApiModelProperty("审核状态")
    private Integer auditStatus;


    /**
     * 审核建议
     */
    @ApiModelProperty("审核建议")
    private String auditRemark;


    /**
     * 审核原因
     */
    @ApiModelProperty("审核原因")
    private String rollbackRason;


}
