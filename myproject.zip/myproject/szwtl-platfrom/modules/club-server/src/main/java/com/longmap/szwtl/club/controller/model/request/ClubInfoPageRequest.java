package com.longmap.szwtl.club.controller.model.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;

@Data
@ApiModel("后台分页查询社团信息model")
public class ClubInfoPageRequest extends CommonPage implements Serializable {


    /**
     * 区域编码
     */
    @ApiModelProperty("区域编码")
    private String districtId;

    /**
     * 社团类别
     */
    @ApiModelProperty("社团类别Id")
    private String  clubClassId ;


    /**
     * 社团状态（1 最新发布，2.人气，3 招募中）
     */
    private Integer status;


    @ApiModelProperty("审核状态")
    private Integer auditStatus;


    /**
     * 社团名称
     */
    @ApiModelProperty("社团名称")
    private String clubName;




}
