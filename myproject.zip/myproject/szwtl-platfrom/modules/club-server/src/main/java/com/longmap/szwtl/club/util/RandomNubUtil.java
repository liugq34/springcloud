package com.longmap.szwtl.club.util;

import java.util.Random;

/**
 * @author: yaohw
 * @create: 2019-07-30 15:16
 **/
public class RandomNubUtil {

    /**
     * 获取随机6位数
     * @return
     */
    public static String getSixNub(){
        int random=(int)((Math.random()*9+1)*100000);
        return ""+random;
    }

    /**
     * 获取随机字符串
     * @param length 字符串长度
     * @return java.lang.String
     */
    public static String getStringRandom(int length) {
        String val = "";
        Random random = new Random();
        //length为几位密码
        for(int i = 0; i < length; i++) {
            String charOrNum = random.nextInt(2) % 2 == 0 ? "char" : "num";
            //输出字母还是数字
            if( "char".equalsIgnoreCase(charOrNum) ) {
                //输出是大写字母还是小写字母
                int temp = random.nextInt(2) % 2 == 0 ? 65 : 97;
                val += (char)(random.nextInt(26) + temp);
            } else if( "num".equalsIgnoreCase(charOrNum) ) {
                val += String.valueOf(random.nextInt(10));
            }
        }
        return val;
    }
}
