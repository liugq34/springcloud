package com.longmap.szwtl.club.mapper;

import com.longmap.szwtl.club.controller.model.request.ClubInfoDetailsQueryRequest;
import com.longmap.szwtl.vo.ClubApply;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;
import java.util.Map;


@Mapper
public interface ClubApplyMapper {
    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(String id);


    /**
     *
     * @mbg.generated
     */
    int insert(ClubApply record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(ClubApply record);

    /**
     *
     * 根据社团id查询社团申请信息
     * @mbg.generated
     */
    ClubApply selectByPrimaryKey(@Param("clubId") String clubId);


    /**
     * 根据用户id查询社团申请信息
     * @param userId
     * @return
     */
    List<ClubApply> queryClubApplyByUserId(@Param("userId")String userId);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(ClubApply record);

    /**
     * 根据社团id和用户id查询社团信息
     * @param clubInfoDetailsQueryRequest
     * @return
     */
    ClubApply selectByClubIdAndUserId(ClubInfoDetailsQueryRequest clubInfoDetailsQueryRequest);

    /**
     * 根据社团id和用户id删除社团信息
     * @param clubId
     * @param userId
     * @return
     */
    int deleteByClubIdAndUserId(@Param("clubId")String clubId,@Param("userId")String userId);

    /**
     * 修改状态
     * @param record
     * @return
     */
    int updateByStatus(ClubApply record);



    /**
     * 社团用户列表分页查询
     * @param clubApply
     * @return
     */
    public List<Map<String,Object>> getClubInfoByUserList(ClubApply clubApply);

}