package com.longmap.szwtl.club.controller.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;
import java.util.Date;


@Data
@ApiModel("社团用户列表返回model")
public class ClubInfoApplyListRequest {


    private String clubId;
    private String applyId;
    private String clubName;
    private String realName;
    private String status;
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
    private Date createdTime;


}
