package com.longmap.szwtl.club.controller.model.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;

@Data
@ApiModel("社团用户列表查询model")
public class ClubInfoPersonalRequest extends CommonPage implements Serializable {
    /**
     * 真实姓名
     */
    @ApiModelProperty("真实姓名")
    private String realname;



    /**
     * 社团名称
     */
    @ApiModelProperty("社团名称")
    private String clubName;





}
