package com.longmap.szwtl.club.controller.model.request;


import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import java.io.Serializable;

@Data
@ApiModel("详情查询社团信息-model")
public class ClubInfoQueryRequest extends CommonPage implements Serializable {

    /**
     * 社团类别
     */
    @ApiModelProperty("社团类别Id")
    private String  clubClassId ;


    /**
     * 用户状态（1 申请加入，2.未加入，3 退团）
     */
    private Integer status;



    /**
     * 用户id
     */
    @ApiModelProperty("用户id")
    private String userId;




    /**
     * 区域编码
     */
    @ApiModelProperty("区域编码")
    private String districtId;




}
