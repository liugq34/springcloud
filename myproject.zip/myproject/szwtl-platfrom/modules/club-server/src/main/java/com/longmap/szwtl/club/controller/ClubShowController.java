package com.longmap.szwtl.club.controller;


import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.club.controller.model.request.*;
import com.longmap.szwtl.club.service.ClubInfoService;
import com.longmap.szwtl.club.service.ClubInfoShowService;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.vo.ClubInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuqm  create b 2019/8/13 15:19
 * @description 社团接口
 **/
@RestController
@Api(tags = "社团展示接口")
@RequestMapping("showClub")
public class ClubShowController {


    @Autowired
    private ClubInfoShowService clubInfoShowService;
    @Autowired
    ClubInfoService clubInfoService;



    /**
     * 通过社团id查询社团详情
     * @return
     */
    @GetMapping("queryClubInfoShowById")
    @ApiOperation("通过id查询社团信息")
    public ResponseResult queryClubInfoShowById(ClubInfoDetailsQueryRequest clubInfoDetailsQueryRequest){

        try{
            Map<String,Object> map=new HashMap<String,Object>();
            // 根据社团id查询社团信息
            ClubInfo clubInfo =clubInfoShowService.queryClubInfoShowById(clubInfoDetailsQueryRequest);
            // 根据社团类型推荐社团
            PageInfo<ClubInfo> xgList = clubInfoShowService.getRecommendList(clubInfoDetailsQueryRequest);
            map.put("clubInfo",clubInfo);
            map.put("xgList",xgList);

            return new ResponseResult(com.longmap.szwtl.common.response.ResponseStatus.SUCCESS.getStatus(),  map);

        }catch (BeansException e){
            return new ResponseResult(com.longmap.szwtl.common.response.ResponseStatus.ERROR.getStatus(),"查询失败！");
        }

    }


    /* 分页查询社团信息列表
     * @param clubInfoShowRequest
     * @return
     */
    @PostMapping("getClubShowList")
    @ApiOperation("分页展示社团列表")
    public ResponseResult getClubShowList(@RequestBody @ApiParam(value = "查询社团信息列表请求体")
                                          @Validated ClubInfoShowRequest clubInfoShowRequest){
        try {
            PageInfo<ClubInfo> list = clubInfoShowService.getClubInfoShowList(clubInfoShowRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<ClubInfo>(list));
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询社团信息列表失败");
        }
    }


    /* 根据用户id分页查询社团信息
     * @param userId
     * @return
     */
    @PostMapping("getClubInfoShowByUserId")
    @ApiOperation("根据用户id分页查询社团信息")
    public ResponseResult getClubInfoShowByUserId(@RequestBody @ApiParam(value ="查询个人中心列表请求体") @Validated ClubInfoApplyQueryRequest clubInfoApplyQueryRequest){
        try {
            PageInfo<ClubInfo> list = clubInfoShowService.getClubInfoShowByUserId(clubInfoApplyQueryRequest);
            return new ResponseResult(com.longmap.szwtl.common.response.ResponseStatus.SUCCESS.getStatus(), new IPageList<ClubInfo>(list));
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询社团信息列表失败");
        }
    }

    /**
     * 退出社团
     */
    @PostMapping("/signOutClub/{userId}/{clubId}")
    @ApiOperation("退出社团")
    public ResponseResult signOutClub(@ApiParam("用户id") @PathVariable("userId") String userId,@ApiParam("社团id") @PathVariable("clubId") String clubId){
        try {
            int result = clubInfoShowService.signOutClub(userId,clubId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"退出成功");
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"退出失败");
        }
    }

    /* 不分页查询社团列表
     * @param clubInfoShowRequest
     * @return
     */
    @PostMapping("getClubInfoListByWhere")
    @ApiOperation("不分页查询社团列表")
    public ResponseResult getClubInfoListByWhere(@RequestBody @ApiParam(value = "查询社团信息列表请求体")@Validated ClubInfoShowRequest clubInfoShowRequest){
        ClubInfo clubInfo = new ClubInfo();
        BeanUtils.copyProperties(clubInfoShowRequest, clubInfo);
        List<ClubInfo> list = clubInfoService.getClubInfoListByWhere(clubInfo);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),list);
    }

}
