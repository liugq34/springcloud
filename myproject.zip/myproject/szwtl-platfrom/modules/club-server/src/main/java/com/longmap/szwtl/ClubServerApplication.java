package com.longmap.szwtl;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @author Created by oushaohui on 2019/8/8 14:50
 * @description 社团服务
 **/
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@MapperScan("com.longmap.szwtl.mapper")
public class ClubServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClubServerApplication.class,args);
    }
}
