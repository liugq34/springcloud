package com.longmap.szwtl.club.mapper;

import com.longmap.szwtl.vo.ClubApply;
import com.longmap.szwtl.vo.ClubInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ClubInfoMapper {
    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(String clubId);

    /**
     *
     * @mbg.generated
     */
    int insert(ClubInfo record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(ClubInfo record);

    /**
     *根据社团id查询社团信息
     * @mbg.generated
     */
    ClubInfo selectByPrimaryKey(@Param("clubId") String clubId);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(ClubInfo record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(ClubInfo record);


    /**
     * 分页条件查询--列表查询
     * @param clubInfo
     * @return
     */
    public List<ClubInfo> getClubInfoList(ClubInfo clubInfo);


    /**
     *修改社团状态
     * @mbg.generated
     */
    public int updateByStatus(ClubInfo record);



    /**
     *修改招募人数
     * @mbg.generated
     */
    public  int updateByRecruitmentNum(ClubInfo record);




    /**
     *修改上下架状态
     * @mbg.generated
     */
    public  int updateByClubStatus(ClubInfo record);


}