package com.longmap.szwtl.club.enums;

public enum ClubInfoStatus {
    UP_CLUB_STATUS(0,"正常"),
    DOWN_CLUB_STATUS(1,"下架"),
    ;

    private Integer code;
    private String mesaage;

    ClubInfoStatus(Integer code, String mesaage) {
        this.code = code;
        this.mesaage = mesaage;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMesaage() {
        return mesaage;
    }

    public void setMesaage(String mesaage) {
        this.mesaage = mesaage;
    }
}
