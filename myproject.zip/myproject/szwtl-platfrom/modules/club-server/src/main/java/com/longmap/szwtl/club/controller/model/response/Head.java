package com.longmap.szwtl.club.controller.model.response;

import lombok.Data;

/**
 * @author: liuqm
 * @create: 2019-08-14 14:20
 **/
@Data
public class Head {
    /**
     * 响应码
     */
    private String code;

    /**
     * 响应信息
     */
    private String message;
}