package com.longmap.szwtl.club.service;


import com.longmap.szwtl.club.base.fallback.IAuthServiceFallbackFactory;
import com.longmap.szwtl.common.response.ResponseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 验证服务
 * @author: liuqm
 * @create: 2019-08-15 11:00
 **/
@FeignClient(name = "sms-server", fallbackFactory = IAuthServiceFallbackFactory.class)
public interface SmsService {

    /**
     * 发送短信验证码
     * @param mobile 手机号码
     * @param content 短信内容
     * @return
     */
    @PostMapping(value = "/sendsms")
    ResponseResult sendSms(@RequestParam("mobile") String mobile, @RequestParam("content") String content);

}
