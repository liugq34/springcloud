package com.longmap.szwtl.club.mapper;

import com.longmap.szwtl.vo.AuditStatusLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface AuditStatusLogMapper {
    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(String id);

    /**
     *
     * @mbg.generated
     */
    int insert(AuditStatusLog record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(AuditStatusLog record);

    /**
     *根据businessId查询审核记录信息
     * @mbg.generated
     */
    List<AuditStatusLog> selectByBusinessId(@Param("businessId") String businessId);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(AuditStatusLog record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(AuditStatusLog record);
}