package com.longmap.szwtl.club.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;



@Data
@ApiModel("详情查询-model")
public class ClubInfoDetailsQueryRequest  {

    /**
     * 社团ID
     */
    @ApiModelProperty("社团ID")
    private String clubId;



    /**
     * 用户ID
     */
    @ApiModelProperty("用户ID")
    private String userId;








}
