package com.longmap.szwtl.club.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.club.controller.model.request.*;
import com.longmap.szwtl.club.mapper.ClubApplyMapper;
import com.longmap.szwtl.club.mapper.ClubClassInfoMapper;
import com.longmap.szwtl.club.mapper.ClubInfoMapper;
import com.longmap.szwtl.club.service.ClubInfoShowService;
import com.longmap.szwtl.common.exception.RestRuntimeException;
import com.longmap.szwtl.club.mapper.ClubInfoShowMapper;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.vo.ClubApply;
import com.longmap.szwtl.vo.ClubClassInfo;
import com.longmap.szwtl.vo.ClubInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;



/**
 *社团展示接口
 */
@Service
public class ClubInfoShowServiceImpl implements ClubInfoShowService {

    @SuppressWarnings("all")
    @Autowired
    public  ClubInfoShowMapper clubInfoShowMapper;


    @SuppressWarnings("all")
    @Autowired
    public ClubApplyMapper clubApplyMapper;


    @SuppressWarnings("all")
    @Autowired
    private ClubInfoMapper clubInfoMapper;


    @SuppressWarnings("all")
    @Autowired
    private ClubClassInfoMapper clubClassInfoMapper;


    /**
     * 根据社团id查询社团信息
     * @param clubInfoDetailsQueryRequest 社团id
     * @return
     */
    @Override
    public ClubInfo queryClubInfoShowById(ClubInfoDetailsQueryRequest clubInfoDetailsQueryRequest) {

        // 根据社团id查询社团基本信息表
        ClubInfo clubInfo=clubInfoShowMapper.queryClubInfoShowById(clubInfoDetailsQueryRequest.getClubId());
        // 根据社团id查询社团类型表
        List<ClubClassInfo> clubClassInfoList=clubClassInfoMapper.selectByClubId(clubInfoDetailsQueryRequest.getClubId());
        if(clubClassInfoList.size()>0){
            // 拼接社团名称
            String className="";
            // 拼接社团类型
            String ClubClassId="";
            for (ClubClassInfo clubClassInfo : clubClassInfoList){
                className+=clubClassInfo.getClubClassName()+",";
                ClubClassId+=clubClassInfo.getClubClassId()+",";
            }
            className=className.substring(0,className.length()-1);
            clubInfo.setClubClassName(className);

            ClubClassId=ClubClassId.substring(0,ClubClassId.length()-1);
            clubInfo.setClubClassId(ClubClassId);
        }
        // 判断用户id是否为空
        if(clubInfoDetailsQueryRequest.getUserId()!=null){
            // 根据社团id和用户id查询社团申请表
            ClubApply clubApply=clubApplyMapper.selectByClubIdAndUserId(clubInfoDetailsQueryRequest);
            // 当社团信息表存在该记录时，返回用户状态
            if(clubApply!=null){
                clubInfo.setUserStatus(clubApply.getStatus());
                clubInfo.setUserId(clubApply.getUserId());
            }
        }
        return clubInfo;
    }

    /**
     * 社团信息分页查询
     * @param clubInfoShowRequest
     * @return
     */
    @Override
    public PageInfo<ClubInfo> getClubInfoShowList(ClubInfoShowRequest clubInfoShowRequest) {

        ClubInfo clubInfo=new ClubInfo();
        // 区域编码
        if(clubInfoShowRequest.getDistrictId() != null){
            clubInfo.setDistrictId(clubInfoShowRequest.getDistrictId());
        }
        // 社团类型
        if(clubInfoShowRequest.getClubClassId() != null){
            clubInfo.setClubClassId(clubInfoShowRequest.getClubClassId());
        }
        // 用户状态
        if(clubInfoShowRequest.getStatus() != null){
            clubInfo.setStatus(clubInfoShowRequest.getStatus());
        }
        // 社团名称
        if(clubInfoShowRequest.getClubName() != null){
            clubInfo.setClubName(clubInfoShowRequest.getClubName());
        }
        PageHelper.startPage(clubInfoShowRequest.getPageNum(), clubInfoShowRequest.getPageSize());
        List<ClubInfo> list = clubInfoShowMapper.getClubInfoShowList(clubInfo);
        PageInfo page = new PageInfo(list);
        return page;
    }

    /**
     * 根据用户id分页查询社团信息
     * @param clubInfoApplyQueryRequest
     * @return
     */
    @Override
    public PageInfo<ClubInfo> getClubInfoShowByUserId(ClubInfoApplyQueryRequest clubInfoApplyQueryRequest) {
        ClubInfo clubInfo=new ClubInfo();
        // 区域编码
        if(clubInfoApplyQueryRequest.getClubClassId() != null){
            clubInfo.setClubClassId(clubInfoApplyQueryRequest.getClubClassId());
        }
        // 用户id
        if(clubInfoApplyQueryRequest.getUserId() != null){
            clubInfo.setUserId(clubInfoApplyQueryRequest.getUserId());
        }
        PageHelper.startPage(clubInfoApplyQueryRequest.getPageNum(), clubInfoApplyQueryRequest.getPageSize());
        // 根据用户id分页查询社团信息
        List<ClubInfo> list = clubInfoShowMapper.getClubInfoShowByUserIdList(clubInfo);
        PageInfo page = new PageInfo(list);
        return page;
    }

    /**
     * 退出社团
     * @param clubId 社团id
     * @return
     * @throws RestRuntimeException
     */
    @Override
    public int signOutClub(String userId,String clubId) throws RestRuntimeException {
        int result = 0;
        try{
            //判断社团人员信息是否存在
            List<ClubApply> clubApplyList = clubApplyMapper.queryClubApplyByUserId(userId);
            if(clubApplyList.size()<0 ){
                throw new RestRuntimeException(ResponseStatus.STATUS_INCONFORMITY.getStatus(),"当前记录不存在！");
            }
            // 退出社团
            for(int i=0;i<clubApplyList.size();i++){
                result = clubApplyMapper.deleteByClubIdAndUserId(clubId,userId);
            }
            //查询社团信息表是否存在，
            ClubInfo clubInfo= clubInfoMapper.selectByPrimaryKey(clubId);
            if(clubInfo==null){
                throw new RestRuntimeException(ResponseStatus.STOCK_NULL.getStatus(),"社团信息不存在");
            }
            // 修改社团信息表招募人数进行修改（招募人数+1）
            int recruitmentNum =clubInfo.getRecruitment()+1;
            ClubInfo newClubInfo=new ClubInfo();
            newClubInfo.setClubId(clubId);
            newClubInfo.setRecruitment(recruitmentNum);
            result =clubInfoMapper.updateByRecruitmentNum(newClubInfo);
            // 判断招募状态是否满员
            if(clubInfo.getStatus()==4){
                ClubInfo club=new ClubInfo();
                club.setClubId(clubId);
                club.setStatus(3);// 招募状态修改成招募中
                result =clubInfoMapper.updateByStatus(club);
            }
        }catch (Exception e){
            e.printStackTrace();
            throw new RestRuntimeException(ResponseStatus.ERROR.getStatus(),"程序异常");
        }
        return result;
    }

    /**
     * 根据社团类型标签推荐热门信息分页查询
     * @param clubInfoDetailsQueryRequest
     * @return
     */
    @Override
    public PageInfo<ClubInfo> getRecommendList(ClubInfoDetailsQueryRequest clubInfoDetailsQueryRequest) {
       PageHelper.startPage(1, 4);
       List<ClubInfo> list = clubInfoShowMapper.getRecommendList(clubInfoDetailsQueryRequest.getClubId());
       PageInfo page = new PageInfo(list);
       return page;
    }

}
