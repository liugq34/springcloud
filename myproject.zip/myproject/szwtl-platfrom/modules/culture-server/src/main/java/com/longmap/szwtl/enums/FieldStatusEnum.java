package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 16:17 2019/8/16
 * @description
 */
public enum FieldStatusEnum {

    NORMOL_MANUAL(1,"正常"),
    FORBID(2,"禁止")
    ;
    private int code;
    private String message;

    FieldStatusEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
