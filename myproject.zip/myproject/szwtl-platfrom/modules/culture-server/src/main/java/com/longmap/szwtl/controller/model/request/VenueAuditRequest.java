package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author luor
 * @date created in 17:48 2019/8/14
 * @description
 */
@Data
@ApiModel("场馆请求参数")
public class VenueAuditRequest {


    @ApiModelProperty("主键ID(新增不填)")
    private String venueId;

    @ApiModelProperty("审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)")
    private Integer auditStatus;

    @ApiModelProperty("回退原因")
    private String rollbackReason;

    @ApiModelProperty("修改建议")
    private String modifiedSuggest;
}
