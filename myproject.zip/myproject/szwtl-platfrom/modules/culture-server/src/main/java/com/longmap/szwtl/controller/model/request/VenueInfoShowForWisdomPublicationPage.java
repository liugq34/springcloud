package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 10:23 2019/9/3
 * @description
 */
@Data
@ApiModel("场馆信息分页")
public class VenueInfoShowForWisdomPublicationPage implements Serializable {

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;
}
