package com.longmap.szwtl.controller;

import com.longmap.szwtl.base.service.IAuthService;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.service.UserServerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luor
 * @date created in 14:36 2019/7/31
 * @description feign 调用外部服务接口 测试
 */
@RestController
@RequestMapping("/feign")
public class FeignController {

    @Autowired
    private UserServerService userServerService;

    @Autowired
    private IAuthService AuthServicei;

    /**
     * 获取区域列表
     * @return
     * */
    @GetMapping("/getAreasList")
    public ResponseResult getAreasList(){
        return userServerService.getAllAreasTree();
    }

    /**
     * test
     * @return
     */
    @GetMapping("/test")
    public ResponseResult test(){
        return AuthServicei.getUserInfo();
    }

}
