package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.*;
import com.longmap.szwtl.controller.model.response.TVenueInfoResponse;
import com.longmap.szwtl.service.VenueGoodInfoService;
import com.longmap.szwtl.service.VenueInfoShowService;
import com.longmap.szwtl.vo.TActivityInfo;
import com.longmap.szwtl.vo.TVenueGoodInfo;
import com.longmap.szwtl.vo.TVenueInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author luor
 * @date created in 11:18 2019/8/13
 * @description
 */

@RestController
@Api(tags = "场馆信息查询接口 不需要access_token")
@RequestMapping("/venueInfoShowNoToken")
public class VenueInfoShowNoTokenController {

    @Autowired
    private VenueInfoShowService venueInfoShowService;
    @Autowired
    private VenueGoodInfoService VenueGoodInfoService;

    /**
     * 场馆查看热门推荐列表
     * @param tVenueInfoPage
     * @return
     */
    @GetMapping("getTVenueInfoListByStarrating")
    @ApiOperation("场馆查看热门推荐列表")
    public ResponseResult getTVenueInfoListByStarrating(@ApiParam(value = "分页排序信息") @Validated TVenueInfoPage tVenueInfoPage){
        try {
            PageInfo<TVenueInfo> list = venueInfoShowService.getTVenueInfoListByStarrating(tVenueInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TVenueInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆推荐活动列表失败");
        }
    }

    @GetMapping("/getVenueInfoList")
    @ApiOperation("查询场馆列表")
    public ResponseResult getVenueInfoList(@ApiParam(value = "查询场馆列表请求体") VenueInfoShowRequest venueInfo,
                                           @ApiParam(value = "分页排序信息") @Validated TVenueInfoPage tVenueInfoPage){
        try {
            venueInfo.setVisitType(1); //游客身份设定
            PageInfo<TVenueInfo> list = venueInfoShowService.selectVenueInfoList(venueInfo,tVenueInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TVenueInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆列表失败");
        }
    }

    @GetMapping("getVenueInfo")
    @ApiOperation("查询场馆详情")
    public ResponseResult getVenueInfo(@ApiParam("场馆ID") @RequestParam(value = "venueId") String venueId){
        try {
            TVenueInfoResponse tVenueInfoResponse = venueInfoShowService.selectVenueInfo(venueId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tVenueInfoResponse);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆列表失败");
        }
    }


    /**
     * 用于分享服务调用接口，查询场馆列表,没有分页
     * @param venueInfo
     * @return
     */
    @ApiOperation("用于分享服务调用接口，查询场馆列表")
    @PostMapping("/getVenueInfoListToShareServer")
    public ResponseResult getVenueInfoListToShareServer(@ApiParam(value = "查询场馆列表请求体") @Validated VenueInfoShowRequest venueInfo){
        try {
            List<TVenueInfo> tVenueInfoList = venueInfoShowService.selectVenueInfoListNoPages(venueInfo);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tVenueInfoList);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆信息失败");
        }

    }


    @GetMapping("/selectVenueInfoListAndVenueInfoSportitems")
    @ApiOperation("查询场馆列表，智慧刊物")
    public ResponseResult selectVenueInfoListAndVenueInfoSportitems(@ApiParam(value = "查询场馆列表请求体") VenueInfoShowForWisdomPublicationRequest venueInfoShowForWisdomPublicationRequest,
                                           @ApiParam(value = "分页排序信息")VenueInfoShowForWisdomPublicationPage venueInfoShowForWisdomPublicationPage){
        try {
            venueInfoShowForWisdomPublicationRequest.setVisitType(1); //游客身份设定
            PageInfo<TVenueInfo> list = venueInfoShowService.selectVenueInfoListAndVenueInfoSportitems(venueInfoShowForWisdomPublicationRequest,venueInfoShowForWisdomPublicationPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TVenueInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆列表失败");
        }
    }

}
