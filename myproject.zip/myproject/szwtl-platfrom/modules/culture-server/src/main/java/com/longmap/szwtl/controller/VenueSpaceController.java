package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueSpaceRequest;
import com.longmap.szwtl.controller.model.request.TVenueSpaceUpdateRequest;
import com.longmap.szwtl.service.TVenueSpaceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author luor
 * @date created in 19:55 2019/8/26
 * @description 场馆场地信息
 */
@RestController
@Api(tags = "场馆场地信息")
@RequestMapping("/venueSpace")
public class VenueSpaceController {

    @Autowired
    private TVenueSpaceService tVenueSpaceService;

    /**
     * 添加场地
     * @param tVenueSpaceRequest
     * @return
     */
    @ApiOperation("添加场地")
    @PostMapping("/addVenueSpace")
    public ResponseResult addVenueSpace(@ApiParam("添加请求参数") @RequestBody TVenueSpaceRequest tVenueSpaceRequest){
        tVenueSpaceService.addVenueSpace(tVenueSpaceRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 修改场地
     * @param tVenueSpaceUpdateRequest
     * @return
     */
    @ApiOperation("修改场地")
    @PostMapping("/updateVenueSpace")
    public ResponseResult updateVenueSpace(@ApiParam("修改请求参数") @RequestBody TVenueSpaceUpdateRequest tVenueSpaceUpdateRequest){
        tVenueSpaceService.updateVenueSpace(tVenueSpaceUpdateRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

}
