package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@ApiModel("购买商品model")
public class TAivityOrderRequest implements Serializable {

    /**
     * 商品id
     **/
    @ApiModelProperty("商品id")
    @NotBlank(message = "商品id不能为空")
    private String activityId;

    /**
     * 买家名称
     **/
    @ApiModelProperty("买家名称")
    @NotBlank(message = "买家名称不能为空")
    private String buyerNick;

    /**
     * 买家手机号
     **/
    @ApiModelProperty("买家手机号")
    @NotBlank(message = "买家手机号不能为空")
    private String buyerContact;

    /**
     * 买家备注
     **/
    @ApiModelProperty("买家备注")
    private String buyerMemo;

    /**
     * 买家身份证号
     **/
    @ApiModelProperty("买家身份证号")
    @NotBlank(message = "买家身份证号不能为空")
    private String buyerID;

    /**
     * 取票方式
     **/
    @ApiModelProperty("取票方式")
    @NotNull(message = "数量不能为空")
    private Long accessMode;

    /**
     * 数量
     **/
    @ApiModelProperty("数量不能为空")
    @NotNull(message = "数量不能为空")
    private Long num;

    /**
     * 订单类型
     **/
    @ApiModelProperty("订单类型：（1：文化场馆订单；2：体育场馆订单；3：文化活动；4：体育活动）")
    @NotNull(message = "订单类型不能为空")
    private Long orderType;

    /**
     * 支付方式
     **/
    @ApiModelProperty("支付方式：（1：支付宝；2：微信）")
    @NotNull(message = "支付方式不能为空")
    private Long paymentType;
}
