package com.longmap.szwtl.controller.model.response;

import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author luor
 * @date created in 15:14 2019/9/3
 * @description
 */
@Data
@ApiModel("体育场馆每天场地场号下的商品数据封装")
public class TVenueGoodInfoForGoodShowResponse implements Serializable {

    /**场地ID*/
    private String TvenueSpaceId;
    /**场地名称*/
    private String TvenueSpaceName;
    /**场号ID*/
    private String TvenueSpaceNoId;
    /**场号名称*/
    private String TvenueSpaceNoName;
    /**场号NO*/
    private Long venueSpaceNoName;

    /**开始时间*/
    private Long startTime;

    /**结束时间*/
    private Long endTime;

    /**售价*/
    private BigDecimal saleprice;

    /***总数量*/
    private Long totalnum;

    /**可预订数量*/
    private Long remainnum;

    /**已预定数量*/
    private Long reservednum;

    /**状态 1.正常 2.禁止*/
    private Integer status;
}
