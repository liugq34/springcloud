package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 15:19 2019/8/21
 * @description 运动项目分页参数
 */
@Data
@ApiModel("运动项目分页参数")
public class TSportItemShowPage implements Serializable {

    @ApiModelProperty("排序方式(1:默认; 2:排序字段 正序 3.排序字段 倒序")
    private Integer sequence = 1;

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;
}
