package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author luor
 * @date created in 11:27 2019/8/26
 * @description
 */
@Data
@ApiModel("体育场馆项目请求参数")
public class TVenueSportitemRequest implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("场馆项目主键，用于修改场馆项目")
    private String venueSportitemId;

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseId;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 运动项目code
     */
    @ApiModelProperty("运动项目code")
    private String sportItemCode;

    /**
     * 运动项目名称
     */
    @ApiModelProperty("运动项目名称")
    private String sportItemName;

    /**
     * 使用类型 1、按步长，2、按早晚，3、按天
     */
    @ApiModelProperty("使用类型 1、按步长，2、按早晚，3、按天")
    private Integer occupyType;

    /**
     * 步长
     */
    @ApiModelProperty("步长")
    private BigDecimal step;

    /**
     * 提前退订时间，单位：小时
     */
    @ApiModelProperty("提前退订时间，单位：小时")
    private Long refundtime;

    /**
     * 室内or室外
     */
    @ApiModelProperty("室内or室外 1.室内 2.室外")
    private Integer inoutdoor;

    /**
     * 是否有灯光
     */
    @ApiModelProperty("是否有灯光 1.有 0.没有")
    private Integer havelight;

    /**
     * 地板类型
     */
    @ApiModelProperty("地板类型")
    private String floorType;

    /**
     * 工作日开始营业时间
     */
    @ApiModelProperty("工作日开始营业时间")
    private String weekdayStartTime;

    /**
     * 工作日结束营业时间
     */
    @ApiModelProperty("工作日结束营业时间")
    private String weekdayEndTime;

    /**
     * 周末开始营业时间
     */
    @ApiModelProperty("周末开始营业时间")
    private String weekendStartTime;

    /**
     * 周末结束营业时间
     */
    @ApiModelProperty("周末结束营业时间")
    private String weekendEndTime;

    /**
     * SZWTL.T_VENUE_SPORTITEM
     */
    private static final long serialVersionUID = 1L;

}
