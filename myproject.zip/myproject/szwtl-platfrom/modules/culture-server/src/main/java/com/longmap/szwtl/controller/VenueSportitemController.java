package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueSportitemRequest;
import com.longmap.szwtl.controller.model.request.TVenueSportitemStatusRequest;
import com.longmap.szwtl.service.VenueSportitemService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luor
 * @date created in 11:23 2019/8/26
 * @description 体育场馆体育项目部分
 */
@RestController
@Api(tags = "体育场馆体育项目部分，后台管理")
@RequestMapping("/tvenueSportitem")
public class VenueSportitemController {

    @Autowired
    private VenueSportitemService venueSportitemService;


    /**
     * 添加体育场馆项目
     * @param tVenueSportitemRequest
     * @return
     */
    @ApiOperation("添加体育场馆项目")
    @PostMapping("/addVenueSportitem")
    public ResponseResult addVenueSportitem(@ApiParam("添加请求参数") @RequestBody
                                                    TVenueSportitemRequest tVenueSportitemRequest){
            venueSportitemService.addVenueSportitem(tVenueSportitemRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 修改体育场馆项目
     * @param tVenueSportitemRequest
     * @return
     */
    @ApiOperation("修改体育场馆项目")
    @PostMapping("/updateVenueSportitem")
    public ResponseResult updateVenueSportitem(@ApiParam("修改请求参数") @RequestBody
                                                       TVenueSportitemRequest tVenueSportitemRequest){
        venueSportitemService.updateVenueSportitem(tVenueSportitemRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 修改体育场馆项目状态（删除状态、上下架状态）
     * @param tVenueSportitemStatusRequest
     * @return
     */
    @ApiOperation("修改体育场馆项目状态（删除状态、上下架状态）")
    @PostMapping("/updateVenueSportitemStatus")
    public ResponseResult updateVenueSportitemStatus(@ApiParam("修改状态请求参数") @RequestBody
                                                             TVenueSportitemStatusRequest tVenueSportitemStatusRequest){
        venueSportitemService.updateVenueSportitemStatus(tVenueSportitemStatusRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }
}
