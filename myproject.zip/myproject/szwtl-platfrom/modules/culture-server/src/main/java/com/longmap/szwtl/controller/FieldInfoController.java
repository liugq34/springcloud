package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TFieldPage;
import com.longmap.szwtl.controller.model.request.TFieldRequest;
import com.longmap.szwtl.controller.model.request.TFieldShowRequest;
import com.longmap.szwtl.controller.model.request.TFieldStatusRequest;
import com.longmap.szwtl.service.FieldInfoService;
import com.longmap.szwtl.vo.TField;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author luor
 * @date created in 14:52 2019/8/16
 * @description 场馆活动室
 */
@RestController
@RequestMapping("/fieldInfo")
@Api(tags = "后台操作场馆活动室")
public class FieldInfoController {

    @Autowired
    private FieldInfoService fieldInfoService;

    /**
     * 后台添加活动室
     * @param tFieldRequest
     * @return
     */
    @ApiOperation("后台添加活动室")
    @PostMapping("/addFieldInfo")
    public ResponseResult addFieldInfo(@ApiParam("添加活动室请求参数") @RequestBody @Validated TFieldRequest tFieldRequest){
            fieldInfoService.addField(tFieldRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"添加成功！");
    }

    /**
     * 后台修改活动室
     * @param tFieldRequest
     * @return
     */
    @ApiOperation("后台修改活动室")
    @PostMapping("/updateFieldInfo")
    public ResponseResult updateFieldInfo(@ApiParam("修改活动室请求参数") @RequestBody @Validated TFieldRequest tFieldRequest){
        fieldInfoService.updateFieldInfo(tFieldRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"修改成功！");
    }

    /**
     * 场馆活动室变更状态
     * @param tFieldStatusRequest
     * @return
     */
    @ApiOperation("场馆活动室变更状态")
    @PostMapping("/updateFieldStatus")
    public ResponseResult updateFieldStatus(@ApiParam("活动室变更状态请求参数") @RequestBody TFieldStatusRequest tFieldStatusRequest){
        try {
            fieldInfoService.updateFieldStatus(tFieldStatusRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"变更状态成功！");
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"变更状态失败！");
        }
    }

    /**
     * 活动室查询分页
     * @param tFieldShowRequest
     * @param tFieldPage
     * @return
     */
    @ApiOperation("活动室查询分页")
    @GetMapping("/getFieldList")
    public ResponseResult getFieldList(@ApiParam("活动室查询请求参数") TFieldShowRequest tFieldShowRequest,
                                       @ApiParam("活动室查询分页参数") TFieldPage tFieldPage){
        try {
            PageInfo<TField> list =  fieldInfoService.selectTfieldList(tFieldShowRequest,tFieldPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),new IPageList<TField>(list));
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"查询活动室失败！");
        }

    }

    /**
     * 删除活动室
     * @param fieldId
     * @param deltag
     * @return
     */
    @ApiOperation("删除活动室")
    @PostMapping("/deleteField/{fieldId}/{deltag}")
    public ResponseResult deleteField(@ApiParam("活动室ID") @PathVariable("fieldId") String fieldId,
                                      @ApiParam("删除标志 0.未删除 1.删除")  @PathVariable("deltag") Integer deltag){
        fieldInfoService.deleteField(fieldId,deltag);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除成功");
    }
}
