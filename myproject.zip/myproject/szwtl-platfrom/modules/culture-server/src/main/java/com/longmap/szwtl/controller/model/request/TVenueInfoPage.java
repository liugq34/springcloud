package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 11:44 2019/8/21
 * @description
 */
@Data
@ApiModel("场馆信息分页")
public class TVenueInfoPage implements Serializable {

    @ApiModelProperty("排序方式(1:默认; 2:开馆时间; 3:最新发布; 4:收藏最高) ,不用于智能热门推荐")
    private Integer sequence = 1;

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;

    @ApiModelProperty("场馆类型")
    private Integer venueType;
}
