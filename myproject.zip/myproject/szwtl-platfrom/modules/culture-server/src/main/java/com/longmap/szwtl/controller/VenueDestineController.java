package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.exception.RestRuntimeException;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueDestineAddRequest;
import com.longmap.szwtl.controller.model.request.TVenueDestineRequest;
import com.longmap.szwtl.service.VenueDestineService;
import com.longmap.szwtl.service.VenueInfoService;
import com.longmap.szwtl.util.NumberUtil;
import com.longmap.szwtl.vo.TActivityInfo;
import com.longmap.szwtl.vo.TVenueDestine;
import com.longmap.szwtl.vo.TVenueInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author luor
 * @date created in 9:23 2019/7/30
 * @description 场馆预约信息
 */
@RestController
@RequestMapping("venueDestine")
@Api(tags = "后台操作（增加、修改、删除、修改状态）场馆预约信息")
public class VenueDestineController {

        @Autowired
        private VenueDestineService venueDestineService;
        @Autowired
        private VenueInfoService venueInfoService;

    /**
     * 后台添加场馆预约信息
     * @param tVenueDestineAddRequest
     * @return
     */
    @PostMapping("/addVenueDestine")
    @ApiOperation("后台添加场馆预约信息")
    public ResponseResult addVenueDestine(@ApiParam("预约场馆添加信息model") @RequestBody @Validated TVenueDestineAddRequest tVenueDestineAddRequest){
            //添加
            venueDestineService.addVenueDestine(tVenueDestineAddRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"添加成功");
       }

    /**
     * 后台修改场馆预约信息
     * @param tVenueDestineRequest
     * @return
     */
    @PostMapping("/updateVenueDestine")
    @ApiOperation("后台修改场馆预约信息")
    public ResponseResult updateVenueDestine(@ApiParam("预约场馆修改信息model") @RequestBody
                                                 @Validated TVenueDestineRequest tVenueDestineRequest){
        venueDestineService.updateVenueDestine(tVenueDestineRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"修改成功");
    }

    /**
     * 逻辑删除场馆预约信息
     * @param id
     * @return

    @PostMapping("/deleteVenueInfo/{id}/{delete_tag}")
    @ApiOperation("逻辑删除场馆预约信息")
    public ResponseResult deleteVenueInfo(@ApiParam("场馆预约id") @PathVariable("id") String id,
                                          @ApiParam("删除标志") @PathVariable("delete_tag") Integer delete_tag){
            venueDestineService.deletevenueDestine(id,delete_tag);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除成功");
    } */

    /**
     * 修改预订情况(预定状态)
     * @param
     * @return
     */
    @GetMapping("/updateDestineStatus/{id}/{destineStatus}")
    @ApiOperation("修改预订情况(预定状态)")
    public ResponseResult updateDestineStatus(@ApiParam("预定信息id") @PathVariable("id") String id, @ApiParam("预定状态") @PathVariable("destineStatus")  Integer destineStatus){
            venueDestineService.updateDestineStatus(id,destineStatus);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"修改成功");
    }

    /**
     * 修改预订情况列表(预定状态)
     * @param
     * @return
     */
    @GetMapping("/updateDestineStatusList")
    @ApiOperation("修改预订情况(预定状态)列表")
    public ResponseResult updateDestineStatusList(@ApiParam("预定信息id") @RequestParam("id") String[] id, @ApiParam("预定人") @RequestParam("destineId") String destineId, @ApiParam("预定状态") @RequestParam("destineStatus")  Integer destineStatus){
            venueDestineService.updateDestine(id,destineId,destineStatus);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"修改成功");
    }

    /***
     * 场馆预定减库存
     * @param venueId
     * @param venueDestineId
     * @param num
     * @return
     */
    @GetMapping("/reduceStock")
    @ApiOperation("场馆预定减库存")
    public ResponseResult reduceStock(@ApiParam("请求减库存venueId") @RequestParam("venueId") String venueId,
                                      @ApiParam("请求减库存venueDestineId") @RequestParam("venueDestineId") String[] venueDestineId,
                                      @ApiParam("请求减库存num") @RequestParam("num") Long num){

        venueInfoService.reduceStock(venueId,venueDestineId,num);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"成功减库存");

    }


}
