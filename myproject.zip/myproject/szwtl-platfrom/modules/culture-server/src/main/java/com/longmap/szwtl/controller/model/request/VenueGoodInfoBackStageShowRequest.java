package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 10:08 2019/9/5
 * @description
 */
@Data
@ApiModel("体育场馆商品展示请求参数,后台展示")
public class VenueGoodInfoBackStageShowRequest implements Serializable {

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 场馆项目ID
     */
    @ApiModelProperty("场馆项目ID")
    private String venueItemId;

    /**
     * 使用日期
     */
    @ApiModelProperty("使用日期")
    private String useDate;


}
