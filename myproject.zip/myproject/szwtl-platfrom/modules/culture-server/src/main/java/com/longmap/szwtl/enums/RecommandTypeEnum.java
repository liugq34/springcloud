package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 16:06 2019/7/25
 * @description 热度
 */
public enum RecommandTypeEnum {

    RECOMMAND(1,"推荐"),
    NOTRECOMMAND(0,"默认"),
    ;
    private Integer code;
    private String message;

    RecommandTypeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
