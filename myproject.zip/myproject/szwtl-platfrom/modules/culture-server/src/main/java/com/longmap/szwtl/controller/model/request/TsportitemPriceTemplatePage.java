package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 19:31 2019/8/27
 * @description
 */
@Data
@ApiModel("体育场馆价格模板分页参数")
public class TsportitemPriceTemplatePage implements Serializable {

    @ApiModelProperty("排序方式(1:默认; 2:创建时间正序; 3:创建时间倒序;)")
    private Integer sequence = 1;

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;

}
