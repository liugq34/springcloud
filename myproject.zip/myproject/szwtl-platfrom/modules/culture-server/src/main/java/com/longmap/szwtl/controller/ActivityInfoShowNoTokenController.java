package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TActivitInfoPage;
import com.longmap.szwtl.controller.model.request.TActivityInfoShowRequest;
import com.longmap.szwtl.controller.model.response.TActivityInfoResponse;
import com.longmap.szwtl.service.ActivityInfoShowService;
import com.longmap.szwtl.vo.TActivityInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author luor
 * @date created in 11:14 2019/8/13
 * @description 活动展示查询接口 不需要access_token
 */
@RestController
@Api(tags = "活动展示查询接口 不需要access_token")
@RequestMapping("activityInfoShowNoToken")
public class ActivityInfoShowNoTokenController {

    @Autowired
    private ActivityInfoShowService activityInfoShowService;

    /**
     * 未登录用户（游客）查看热门推荐列表
     * @param tActivitInfoPage
     * @return
     */
    @GetMapping("getnologinUserActivityList")
    @ApiOperation("未登录用户（游客）查看热门推荐列表")
    public ResponseResult getnologinUserActivityList(@ApiParam(value = "分页排序信息") @Validated TActivitInfoPage tActivitInfoPage){
        try {
            PageInfo<TActivityInfo> list = activityInfoShowService.nologinUserActivityList(tActivitInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TActivityInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询推荐活动列表失败");
        }
    }

    /**
     * 首页分页查询活动列表
     * @param tActivityInfo
     * @return
     */
    @GetMapping("getActivityInfoList")
    @ApiOperation("首页查询活动列表")
    public ResponseResult getActivityInfoList(@ApiParam(value = "查询活动列表请求体") @Validated TActivityInfoShowRequest tActivityInfo, @ApiParam(value = "分页排序信息") @Validated TActivitInfoPage TActivitInfoPage){
        try {
            tActivityInfo.setVisitType(1);
            PageInfo<TActivityInfo> list = activityInfoShowService.selectActivityInfoList(tActivityInfo,TActivitInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TActivityInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询活动列表失败");
        }
    }

    /**
     * 首页预定查询活动接口
     * @param activityId
     * @return
     */
    @GetMapping("/getActivityInfo/{activityId}")
    @ApiOperation("首页查询活动信息详情")
    public ResponseResult getActivityInfo(@ApiParam("活动ID") @PathVariable("activityId") String activityId){
        try {
            TActivityInfoResponse tActivityInfoResponse = activityInfoShowService.dispalyActivityDetail(activityId,2);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tActivityInfoResponse);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询活动信息失败");
        }

    }


    /**
     * 用于分享服务调用接口，查询活动列表,没有分页
     * @param tActivityInfo
     * @return
     */
    @ApiOperation("用于分享服务调用接口，查询活动列表")
    @PostMapping("/getActivityInfoListToShareServer")
    public ResponseResult getActivityInfoListToShareServer(@ApiParam(value = "查询活动列表请求体") @Validated TActivityInfoShowRequest tActivityInfo){
        try {
            List<TActivityInfo> tActivityInfoList = activityInfoShowService.selectActivityInfoListNoPages(tActivityInfo);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tActivityInfoList);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询活动信息失败");
        }

    }

}
