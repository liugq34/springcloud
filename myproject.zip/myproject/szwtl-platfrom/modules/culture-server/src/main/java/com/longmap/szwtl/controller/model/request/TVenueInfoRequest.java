package com.longmap.szwtl.controller.model.request;

import com.longmap.szwtl.common.validator.DateFormatByPattern;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 15:45 2019/7/26
 * @description 场馆页面请求model
 */
@Data
@ApiModel("场馆页面请求model")
public class TVenueInfoRequest implements Serializable {

    /**
     * 主键ID(新增不填)
     */
    @ApiModelProperty("主键ID(新增不填)")
    private String venueId;

    /**
     * 审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)
     */
    @ApiModelProperty("审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)")
    private Integer auditStatus;

    /**
     * 原图
     */
    @ApiModelProperty("原图")
    private String picture;

    /**
     * 横图  13:7
     */
    @ApiModelProperty("横图 13:7")
    private String pictureHorizontal;

    /**
     * 竖图  5:7
     */
    @ApiModelProperty("竖图 5:7")
    private String pictureVertical;

    /**
     * 场馆名称
     */
    @ApiModelProperty("场馆名称")
    @NotBlank(message = "场馆名称不能为空")
    private String venueName;

    /**
     * 场馆类型
     */
    @ApiModelProperty("场馆类型")
    @NotNull(message = "场馆类型不能为空")
    private Integer venueType;

    /**
     * 场馆类别
     */
    @ApiModelProperty("场馆类别")
    @NotNull(message = "场馆类别不能为空")
    private Integer venueClass;

    /**
     * 所在区
     */
    @ApiModelProperty("场馆所在区")
    //@NotBlank(message = "场馆所在区不能为空")
    private String location;

    /**
     * 街道
     */
    @ApiModelProperty("场馆所在街道")
    //@NotBlank(message = "场馆所在街道不能为空")
    private String street;

    /**
     * 场馆地点
     */
    @ApiModelProperty("场馆所在场馆地点")
    //@NotBlank(message = "场馆所在场馆地点不能为空")
    private String address;

    /**
     * 经度
     */
    @ApiModelProperty("经度")
    private String longitude;

    /**
     * 纬度
     */
    @ApiModelProperty("纬度")
    private String latitude;

    /**
     * 联系人
     */
    @ApiModelProperty("联系人")
    private String linkman;

    /**
     * 联系方式
     */
    @ApiModelProperty("联系方式")
    private String phone;

    /**
     * 温馨提示
     */
    @ApiModelProperty("温馨提示")
    private String warmPoint;

    /**
     * 开放时间
     */
    @ApiModelProperty("开放时间")
    private String openTime;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseId;

    /**
     * 是否可以预定（0.不可预定，1.可以预定）
     */
    @ApiModelProperty("是否可以预定（0.不可预定，1.可以预定）")
    private Integer reserveStatus;

    /**
     * 场馆详情
     */
    @ApiModelProperty("场馆详情")
    private String introduce;



    /**
     * 省编号
     */
    @ApiModelProperty("省编号")
    private String provinceId;

    /**
     * 省名称
     */
    @ApiModelProperty("省名称")
    private String provinceName;

    /**
     * 市编号
     */
    @ApiModelProperty("市编号")
    private String cityId;

    /**
     * 市名称
     */
    @ApiModelProperty("市名称")
    private String cityName;

    /**
     * 区域编号
     */
    @ApiModelProperty("区域编号")
    private String districtId;

    /**
     * 区域名称
     */
    @ApiModelProperty("区域名称")
    private String districtName;

    /**
     * 街道编号
     */
    @ApiModelProperty("街道编号")
    private String subDistrictId;

    /**
     * 街道名称
     */
    @ApiModelProperty("街道名称")
    private String subDistrictName;

    /**
     * 机构代码
     */
    @ApiModelProperty("机构代码")
    private String institutionCode;

    /**
     * 单位性质
     */
    @ApiModelProperty("单位性质")
    private String unitNature;

    /**
     * 法人代表
     */
    @ApiModelProperty("法人代表")
    private String legalRepresentative;

    /**
     * 法人代表联系电话
     */
    @ApiModelProperty("法人代表联系电话")
    private String legalRepresentativePhone;

    /**
     * 负责人
     */
    @ApiModelProperty("负责人")
    private String personInCharge;

    /**
     * 负责人电话
     */
    @ApiModelProperty("负责人电话")
    private String personInChargePhone;

    /**
     * 主管部门
     */
    @ApiModelProperty("主管部门")
    private Integer competentDepartmentType;

    /**
     * 设施面积
     */
    @ApiModelProperty("设施面积")
    private String facilityArea;

    /**
     * 建成时间
     */
    @ApiModelProperty("建成时间")
    private String completionTime;

    /**
     * 用地面积
     */
    @ApiModelProperty("用地面积")
    private String landArea;

    /**
     * 建筑面积
     */
    @ApiModelProperty("建筑面积")
    private String builtUpArea;

    /**
     * 场地面积
     */
    @ApiModelProperty("场地面积")
    private String siteArea;

    /**
     * 运营模式
     */
    @ApiModelProperty("运营模式")
    private String operationalModel;

    /**
     * 经费来源
     */
    @ApiModelProperty("经费来源")
    private String sourcesFunds;

    /**
     * 员工人数
     */
    @ApiModelProperty("员工人数")
    private String employeesNum;

    /**
     * 场馆简介
     */
    @ApiModelProperty("场馆简介")
    private String briefIntroduction;

    /**
     * T_VENUE_INFO
     */
    private static final long serialVersionUID = 1L;
}
