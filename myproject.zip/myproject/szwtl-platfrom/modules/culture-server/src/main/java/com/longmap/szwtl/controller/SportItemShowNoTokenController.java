package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TSportItemShowPage;
import com.longmap.szwtl.controller.model.request.TSportItemShowRequest;
import com.longmap.szwtl.service.SportItemService;
import com.longmap.szwtl.vo.TSportItem;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luor
 * @date created in 10:57 2019/9/3
 * @description
 */
@Api(tags = "运动项目接口，查询没有token")
@RestController
@RequestMapping("/sportItemShowNoToken")
public class SportItemShowNoTokenController {

    @Autowired
    private SportItemService sportItemService;


    /**
     * 查询运动项目列表,分页
     * @param tSportItemShowRequest
     * @param TSportItemShowPage
     * @return
     */
    @ApiOperation("查询运动项目列表,分页")
    @GetMapping("/getSportItemList")
    public ResponseResult getSportItemList(@ApiParam("查询列表请求参数对象") TSportItemShowRequest tSportItemShowRequest,
                                           @ApiParam("查询列表请求参数对象") TSportItemShowPage TSportItemShowPage){
            PageInfo<TSportItem> list = sportItemService.selectSportItemList(tSportItemShowRequest,TSportItemShowPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TSportItem>(list));
    }
}
