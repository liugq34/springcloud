package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TsportitemPriceTemplatePage;
import com.longmap.szwtl.controller.model.request.TsportitemPriceTemplateRequest;
import com.longmap.szwtl.controller.model.request.TsportitemPriceTemplateShowRequest;
import com.longmap.szwtl.service.SportitemPriceTemplateService;
import com.longmap.szwtl.vo.TSportitemPriceTemplate;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author luor
 * @date created in 16:30 2019/8/27
 * @description
 */
@RestController
@Api(tags = "体育场馆价格模板")
@RequestMapping("sportitemPriceTemplate")
public class SportitemPriceTemplateController {

    @Autowired
    private SportitemPriceTemplateService sportitemPriceTemplateService;

    /**
     * 体育场馆价格模板添加
     * @param tSportitemPriceTemplateRequest
     * @return
     */
    @ApiOperation("体育场馆价格模板添加")
    @PostMapping("/addSportitemPriceTemplate")
    public ResponseResult addSportitemPriceTemplate(@ApiParam("价格模板添加参数") @RequestBody TsportitemPriceTemplateRequest tSportitemPriceTemplateRequest){
        sportitemPriceTemplateService.addSportitemPriceTemplate(tSportitemPriceTemplateRequest);
        return  new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 体育场馆价格目标修改
     * @param tSportitemPriceTemplateRequest
     * @return
     */
    @ApiOperation("体育场馆价格目标修改")
    @PostMapping("/updateSportitemPriceTemplate")
    public ResponseResult updateSportitemPriceTemplate(@ApiParam("价格模板修改参数") @RequestBody TsportitemPriceTemplateRequest tSportitemPriceTemplateRequest){
        sportitemPriceTemplateService.updateSportitemPriceTemplate(tSportitemPriceTemplateRequest);
        return  new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 查询列表
     * @param tsportitemPriceTemplateShowRequest
     * @param tsportitemPriceTemplatePage
     * @return
     */
    @ApiOperation("体育场馆价格模板查询列表")
    @GetMapping("/getSportitemPriceTemplateList")
    public ResponseResult getSportitemPriceTemplateList(@ApiParam("查询条件参数") TsportitemPriceTemplateShowRequest tsportitemPriceTemplateShowRequest,
                                                        @ApiParam("分页参数") TsportitemPriceTemplatePage tsportitemPriceTemplatePage){
        PageInfo<TSportitemPriceTemplate> list =  sportitemPriceTemplateService.selectTSportitemPriceTemplateList(tsportitemPriceTemplateShowRequest,tsportitemPriceTemplatePage);
        return  new ResponseResult(ResponseStatus.SUCCESS.getStatus(),new IPageList<TSportitemPriceTemplate>(list));
    }

}
