package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.annotations.ApiOperation;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author luor
 * @date created in 10:06 2019/8/19
 * @description
 */
@Data
@ApiModel("自定义新增场馆申请model")
public class TVenueApplyCustomRequest implements Serializable {

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    @NotBlank(message = "场馆ID不能为空")
    private String venueId;

    /**
     * 活动室ID
     */
    @ApiModelProperty("活动室ID")
    @NotBlank(message = "活动室ID不能为空")
    private String fieldId;

    /**
     * 预订信息ID
     */
    @ApiModelProperty("预订信息ID，用于自定义场馆，拼接例如：first,secend,third")
    @NotBlank(message = "预订信息ID不能为空")
    private String destineId;

    /**
     * 自定义合并预定名称(用于自定义添加名称)
     */
    @ApiModelProperty("自定义合并预定名称(用于自定义添加名称)")
    private String destineCustomname;

    /**
     * 申请人名称
     */
    @ApiModelProperty("申请人名称")
    @NotBlank(message = "申请人名称不能为空")
    private String applyName;

    /**
     * 申请人联系方式
     */
    @ApiModelProperty("申请人联系方式")
    @NotBlank(message = "申请人联系方式不能为空")
    private String applyPhone;

    /**
     * 场地用途
     */
    @ApiModelProperty("场地用途(1:排练; 2:演出, 3:比赛; 4:沙龙; 5:讲座; 6:其他文化活动)")
    private Integer siteUse;

    /**
     * 申请说明
     */
    @ApiModelProperty("申请说明")
    private String description;

    /**
     * 申请类型(1:单个申请; 2:自定义申请)
     */
    @ApiModelProperty("申请类型(1:单个申请; 2:自定义申请)")
    private Integer applyType;

    /**
     * 申请来源(1:门户; 2:微信; 3:小程序)
     */
    @ApiModelProperty("申请来源(1:门户; 2:微信; 3:小程序)")
    private Integer applySource;
}
