package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 15:04 2019/8/29
 * @description 是否发送
 */
public enum SendStatusEnum {
    ISSEND(1,"发送"),
    NOTSEND(0,"未发送"),
    ;
    private Integer code;
    private String message;

    SendStatusEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
