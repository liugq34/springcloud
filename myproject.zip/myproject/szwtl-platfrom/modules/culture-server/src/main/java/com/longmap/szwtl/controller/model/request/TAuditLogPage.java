package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 9:45 2019/8/13
 * @description
 */
@Data
@ApiModel("审核日志")
public class TAuditLogPage implements Serializable {

    @ApiModelProperty("排序方式, 1.默认 2.按照添加时间")
    private Integer sequence = 1;

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;

}
