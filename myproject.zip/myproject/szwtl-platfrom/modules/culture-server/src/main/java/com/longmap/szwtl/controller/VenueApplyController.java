package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueApplyAuditRequest;
import com.longmap.szwtl.controller.model.request.TVenueApplyCustomRequest;
import com.longmap.szwtl.controller.model.request.TVenueApplyRequest;
import com.longmap.szwtl.controller.model.request.TVenueDestineRequest;
import com.longmap.szwtl.service.VenueApplyService;
import com.longmap.szwtl.vo.TVenueApply;
import com.longmap.szwtl.vo.TVenueComment;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author lenovo
 */
@RestController
@Api(tags = "文化场馆使用申请接口")
@RequestMapping("venueApply")
public class VenueApplyController {

    @Autowired
    private VenueApplyService venueApplyService;

    @PostMapping("addVenueApply")
    @ApiOperation("新增,修改场馆申请")
    public ResponseResult addVenueApply(@ApiParam("申请场馆添加、修改信息model") @Validated @RequestBody TVenueApplyRequest tVenueApplyRequest){

        TVenueApply tVenueApply = new TVenueApply();
        BeanUtils.copyProperties(tVenueApplyRequest, tVenueApply);

        int result =  venueApplyService.addVenueApply(tVenueApply);

        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆申请操作成功");

    }


    /**
     * 申请场馆自定义申请
     * @param tVenueApplyCustomRequest
     * @return
     */
    @PostMapping("addCustomizeVenueApply")
    @ApiOperation("申请场馆自定义申请")
    public ResponseResult addVenueApplyByCustom(@ApiParam("申请场馆自定义申请请求model") @Validated @RequestBody TVenueApplyCustomRequest tVenueApplyCustomRequest){
        venueApplyService.addVenueApplyByCustom(tVenueApplyCustomRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆申请操作成功");
    }

    @PostMapping("auditVenueApply")
    @ApiOperation("修改审核状态")
    public ResponseResult auditVenueApply(@ApiParam("审核请求model") @Validated @RequestBody TVenueApplyAuditRequest tVenueApplyAuditRequest){
        int result = venueApplyService.auditVenueApply(tVenueApplyAuditRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"审核状态修改成功");
    }

    @PostMapping("deleteVenueApply/{id}/{delFlag}")
    @ApiOperation("删除申请")
    public ResponseResult deleteVenueApply(@ApiParam("申请id") @PathVariable("id") String id, @ApiParam("删除状态(0:正常; 1:已删除)") @PathVariable("delFlag") Integer delFlag){
        int result = venueApplyService.deleteVenueApply(id,delFlag);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除成功");
    }



}
