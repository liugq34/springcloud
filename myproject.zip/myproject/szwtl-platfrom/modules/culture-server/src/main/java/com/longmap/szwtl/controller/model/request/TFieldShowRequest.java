package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 18:04 2019/8/21
 * @description 活动室查询列表请求参数
 */
@Data
@ApiModel("活动室查询列表请求参数")
public class TFieldShowRequest implements Serializable {

    /**
     * 场馆活动室名称
     */
    @ApiModelProperty("场馆活动室名称, 模糊查询")
    private String fieldName;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID,查询该场馆下的活动室")
    private String venueId;

    /**
     * 1.正常 2.禁止
     */
    @ApiModelProperty("1.正常 2.禁止")
    private Integer fieldStatus;

    /**
     * 活动室状态 1.手动审核 2.自动审核
     */
    @ApiModelProperty("活动室状态 1.手动审核 2.自动审核")
    private Integer auditType;

    /**
     * 场馆活动室编号
     */
    @ApiModelProperty("场馆活动室编号")
    private String fieldNum;

    /**
     * 类别ID
     */
    @ApiModelProperty("类别ID,场馆VenueClass字段")
    private Integer fieldTypeId;

    /**
     * 活动室功能用途
     */
    @ApiModelProperty("活动室功能用途,模糊查询")
    private String fieldFunction;

}
