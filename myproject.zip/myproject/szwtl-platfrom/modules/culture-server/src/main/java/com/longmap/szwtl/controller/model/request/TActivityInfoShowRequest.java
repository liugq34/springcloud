package com.longmap.szwtl.controller.model.request;

import com.longmap.szwtl.common.validator.DateFormatByPattern;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("查询活动信息")
public class TActivityInfoShowRequest implements Serializable {

    /**
     * 活动名称
     */
    @ApiModelProperty("活动名称，模糊查询")
    private String activityName;

    /**
     * 活动类型
     */
    @ApiModelProperty("活动类型")
    private Integer activityType;

    /**
     * 活动类别
     */
    @ApiModelProperty("活动类别")
    private Integer activityClass;

    /**
     * 活动类别 查询多条
     */
    @ApiModelProperty("活动类别，查询多条 拼接 1,2,3")
    private String activityClasss;

    /**
     * 所在区
     */
    @ApiModelProperty("所在区")
    private String districtId;

    @ApiModelProperty("开始日期大于等于")
    @DateFormatByPattern(pattern = "yyyy-MM-dd")
    private String beginDateGreater;

    @ApiModelProperty("开始日期小于等于")
    @DateFormatByPattern(pattern = "yyyy-MM-dd")
    private String beginDateLess ;

    /**
     * 开始日期(格式:yyyy-MM-dd)
     */
    @ApiModelProperty("开始日期 格式:yyyy-MM-dd")
    @DateFormatByPattern(pattern = "yyyy-MM-dd")
    private String beginDate;

    /**
     * 结束日期(格式:yyyy-MM-dd)
     */
    @ApiModelProperty("结束日期 格式:yyyy-MM-dd")
    @DateFormatByPattern(pattern = "yyyy-MM-dd")
    private String endDate;

    /**
     * 是否需要预定0.不需要 1.需要
     */
    @ApiModelProperty("是否需要预定0.不需要 1.需要")
    private Integer reserveStatus;

    /**
     * 审核状态如果不传值，查询所有状态
     */
    @ApiModelProperty("审核状态如果不传值，查询所有状态，1:未提交; 2:未审核; 3:审核通过; 4:审核未通过")
    private Integer auditStatus;

    private Integer visitType; //访问方式   1.游客  2.登入

    /**
     * 活动状态(0:正常; 1:下架)
     */
    @ApiModelProperty("活动状态(0:正常; 1:下架)")
    private Integer status;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID，活动选择场馆")
    private String venueId;

    /**
     * 企业id
     */
    @ApiModelProperty("企业id，活动选择场馆企业")
    private String enterpriseId;

    /**
     * 预定日期(格式:yyyy-MM-dd)
     */
    @ApiModelProperty("预定日期(格式:yyyy-MM-dd)")
    private String reserveBedate;

}
