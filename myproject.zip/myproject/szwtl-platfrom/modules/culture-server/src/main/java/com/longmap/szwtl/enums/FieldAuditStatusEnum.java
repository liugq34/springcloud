package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 17:25 2019/8/22
 * @description
 */
public enum  FieldAuditStatusEnum {

    NORMOL_MANUAL(1,"手动审核"),
    NORMOL_AUTOMATIC(2,"自动审核")
    ;
    private int code;
    private String message;

    FieldAuditStatusEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
