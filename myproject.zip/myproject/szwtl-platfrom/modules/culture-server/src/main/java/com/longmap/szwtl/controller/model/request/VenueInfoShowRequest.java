package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("查询场馆信息")
public class VenueInfoShowRequest implements Serializable {

    /**
     * 场馆名称
     */
    @ApiModelProperty("场馆名称")
    private String venueName;

    /**
     * 场馆类型
     */
    @ApiModelProperty("场馆类型")
    private Integer venueType;

    /**
     * 场馆类别
     */
    @ApiModelProperty("场馆类别")
    private Integer venueClass;

    /**
     * 所在区
     */
    @ApiModelProperty("所在区ID")
    private String districtId;

    /**
     * 审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)
     */
    @ApiModelProperty("审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)")
    private Integer auditStatus;

    /**
     * 场馆状态(0:正常; 1:下架)
     */
    @ApiModelProperty("场馆状态(0:正常; 1:下架)")
    private Integer status;

    @ApiModelProperty(hidden = true)
    private Integer visitType; //访问方式 1.游客 2.登入者

}
