package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 15:16 2019/8/21
 * @description 运动项目查询请求参数
 */
@Data
@ApiModel("运动项目查询请求参数")
public class TSportItemShowRequest implements Serializable {

    /**
     * 运动项目编号
     */
    @ApiModelProperty("运动项目编号")
    private String sportItemCode;

    /**
     * 运动项目名称
     */
    @ApiModelProperty("运动项目名称，用于模糊查询")
    private String sportItemName;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止")
    private Integer status;

    /**
     * SZWTL.T_SPORT_ITEM
     */
    private static final long serialVersionUID = 1L;


}
