package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TSportItemRequest;
import com.longmap.szwtl.controller.model.request.TSportItemShowPage;
import com.longmap.szwtl.controller.model.request.TSportItemShowRequest;
import com.longmap.szwtl.enums.TSportItemEnum;
import com.longmap.szwtl.service.SportItemService;
import com.longmap.szwtl.vo.TSportItem;
import com.longmap.szwtl.vo.TVenueInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author luor
 * @date created in 15:28 2019/8/21
 * @description 运动项目
 */
@Api(tags = "运动项目接口，运动项目的增加，修改，查询")
@RestController
@RequestMapping("/sportItem")
public class SportItemController {

    @Autowired
    private SportItemService sportItemService;

    /**
     * 运动项目添加
     * @param tSportItemRequest
     * @return
     */
    @ApiOperation("运动项目添加")
    @PostMapping("addSportItem")
    public ResponseResult addSportItem(@ApiParam("运动项目请求model") @RequestBody TSportItemRequest
                                               tSportItemRequest){
        try {
            int result = sportItemService.addSportItem(tSportItemRequest);
            if(result>0){
                return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"添加成功");
            }
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"添加失败");
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"操作失败：请联系管理员");
        }
    }

    /**
     * 运动项目修改
     * @param tSportItemRequest
     * @return
     */
    @ApiOperation("运动项目修改")
    @PostMapping("/updateSportItem")
    public ResponseResult updateSportItem(@ApiParam("运动项目请求model") @RequestBody TSportItemRequest
                                                  tSportItemRequest){
        try {
            int result = sportItemService.updateSportItem(tSportItemRequest);
            if(result > 0){
                return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "修改成功");
            }
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "修改失败");
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "操作失败，请联系管理员");
        }
    }

    /**
     * 查询运动项目列表,非分页用于页面展示tab
     * @param tSportItemShowRequest
     * @return
     */
    @ApiOperation("查询运动项目列表,非分页用于页面展示tab")
    @GetMapping("/getSportItemListNoPages")
    public ResponseResult getSportItemListNoPages(@ApiParam("查询列表请求参数对象") TSportItemShowRequest tSportItemShowRequest){
        try {
            List<TSportItem> list = sportItemService.selectSportItemListNoPages(tSportItemShowRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), list);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询运动项目列表失败");
        }
    }

    /**
     * 查询运动项目列表,分页
     * @param tSportItemShowRequest
     * @param TSportItemShowPage
     * @return
     */
    @ApiOperation("查询运动项目列表,分页")
    @GetMapping("/getSportItemList")
    public ResponseResult getSportItemList(@ApiParam("查询列表请求参数对象") TSportItemShowRequest tSportItemShowRequest,
            @ApiParam("查询列表请求参数对象") TSportItemShowPage TSportItemShowPage){
        try {
            PageInfo<TSportItem> list = sportItemService.selectSportItemList(tSportItemShowRequest,TSportItemShowPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TSportItem>(list));
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询运动项目列表失败");
        }
    }


    /**
     * 运动项目修改状态
     * @param sportItemId
     * @param status
     * @return
     */
    @ApiOperation("运动项目修改状态")
    @PostMapping("/updateSportItemStatus/{sportItemId}/{status}")
    public ResponseResult updateSportItemStatus(@ApiParam("运动项目主键ID")  @PathVariable("sportItemId") String sportItemId,
                                                @ApiParam("运动项目状态 1.正常 2.禁止") @PathVariable Integer status){
        try {
            int result = sportItemService.updateSportItemStatus(sportItemId,status);
            if(result > 0){
                if(TSportItemEnum.NORMAL.getCode().equals(status)){
                    return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "项目"+TSportItemEnum.NORMAL.getMessage());
                }else if(TSportItemEnum.FORBID.getCode().equals(status)){
                    return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "项目"+TSportItemEnum.FORBID.getMessage());
                }
            }
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "修改失败");
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), "操作失败，请联系管理员");
        }
    }


    /**
     * 测试运动项目添加
     * @param tSportItemRequest
     * @return

    @ApiOperation("测试运动项目添加")
    @PostMapping("/addTest")
    public ResponseResult addTest(@ApiParam("运动项目请求model") @RequestBody TSportItemRequest
                                               tSportItemRequest){
            sportItemService.addSportItem(tSportItemRequest);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"添加成功");
        }*/
}
