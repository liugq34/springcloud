package com.longmap.szwtl.controller.model.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 10:32 2019/8/29
 * @description
 */
@Data
public class TVenueInfoForTabResponse implements Serializable {

    /**
     * 主键ID
     */
    private String venueId;

    /**
     * 原图
     */
    @ApiModelProperty("原图")
    private String picture;

    /**
     * 横图  13:7
     */
    @ApiModelProperty("横图 13:7")
    private String pictureHorizontal;

    /**
     * 竖图  5:7
     */
    @ApiModelProperty("竖图 5:7")
    private String pictureVertical;

    /**
     * 场馆名称
     */
    private String venueName;

    /**
     * 场馆地点
     */
    private String address;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 省编号
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编号
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编号
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道编号
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * SZWTL.T_VENUE_INFO
     */
    private static final long serialVersionUID = 1L;
}
