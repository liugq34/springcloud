package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 10:21 2019/8/28
 * @description
 */
@Data
@ApiModel("体育场馆商品添加参数")
public class VenueGoodInfoRequest implements Serializable {

    /**
     * 商品名称
     */
    @ApiModelProperty("商品名称")
    private String goodName;

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseId;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 场馆项目ID
     */
    @ApiModelProperty("场馆项目ID")
    private String venueItemId;

    /**
     * 场馆场地ID
     */
    @ApiModelProperty("场馆场地ID, 可以勾选该项目下场地一个或者多个")
    private String venueGroundtypeId;

    /**
     * 开始时间段
     */
    @ApiModelProperty("开始时间段")
    private String startDate;

    /**
     * 结束时间段
     */
    @ApiModelProperty("结束时间段")
    private String endDate;

    /**
     * 选择的价格模板
     */
    @ApiModelProperty("选择的价格模板")
    private String priceTemplateId;

}
