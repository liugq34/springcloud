package com.longmap.szwtl.base.service;

import com.longmap.szwtl.base.fallback.IAuthServiceFallbackFactory;
import com.longmap.szwtl.common.response.ResponseResult;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author Created by oushaohui on 2019/8/5 10:29
 * @description
 **/
@FeignClient(name = "auth-server", fallbackFactory = IAuthServiceFallbackFactory.class)
public interface IAuthService {
    // 配置的调用的接口
    @GetMapping(value = "/getUserInfo")
    ResponseResult getUserInfo();
}
