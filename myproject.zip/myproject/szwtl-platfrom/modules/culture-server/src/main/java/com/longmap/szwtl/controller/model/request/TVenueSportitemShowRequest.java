package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 15:35 2019/8/26
 * @description
 */
@Data
@ApiModel("查询参数")
public class TVenueSportitemShowRequest implements Serializable {

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

}
