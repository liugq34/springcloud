package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author luor
 * @date created in 19:22 2019/8/27
 * @description
 */
@Data
@ApiModel("体育场馆价格模板")
public class TsportitemPriceTemplateShowRequest implements Serializable {

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseId;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 场馆运动项目ID
     */
    @ApiModelProperty("场馆运动项目ID")
    private String venueSportitemId;

    /**
     * 价格模板名称
     */
    @ApiModelProperty("价格模板名称,模糊查询")
    private String priceTemplateName;

    /**
     * 创建人ID
     */
    @ApiModelProperty("创建人ID")
    private String createByUser;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止")
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    @ApiModelProperty("删除标志 0.未删除 1.删除")
    private Integer delFlag;


}
