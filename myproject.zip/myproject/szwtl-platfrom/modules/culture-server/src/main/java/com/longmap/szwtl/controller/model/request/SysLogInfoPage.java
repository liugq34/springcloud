package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("系统日志分页")
public class SysLogInfoPage implements Serializable {

    @ApiModelProperty("排序方式")
    private Integer sequence = 1;

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;

}
