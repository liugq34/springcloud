package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueSportitemPage;
import com.longmap.szwtl.controller.model.request.TVenueSportitemShowRequest;
import com.longmap.szwtl.service.VenueSportitemService;
import com.longmap.szwtl.vo.TVenueSportitem;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author luor
 * @date created in 15:50 2019/8/26
 * @description
 */
@RestController
@Api(tags = "体育场馆体育项目部分，展示页面")
@RequestMapping("/tvenueSportitemShow")
public class VenueSportitemShowController {

    @Autowired
    private VenueSportitemService venueSportitemService;

    /**
     * 查询列表(分页)
     * @param TVenueSportitemShowRequest
     * @param TVenueSportitemPage
     * @return
     */
    @ApiOperation("场馆项目查询列表")
    @GetMapping("/getVenueSportitemList")
    public ResponseResult getVenueSportitemList(@ApiParam("查询请求参数") TVenueSportitemShowRequest TVenueSportitemShowRequest,
                                                @ApiParam("查询分页参数") TVenueSportitemPage TVenueSportitemPage){
        PageInfo<TVenueSportitem> list = venueSportitemService.selectTVenueSportitemList(TVenueSportitemShowRequest,TVenueSportitemPage);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),new IPageList<TVenueSportitem>(list));
    }

    /**
     * 查询列表(非分页)
     * @param TVenueSportitemShowRequest
     * @return
     */
    @ApiOperation("场馆项目查询列表,用于下拉列表")
    @GetMapping("/getVenueSportitemListNoPages")
    public ResponseResult getVenueSportitemListNoPages(@ApiParam("查询请求参数") TVenueSportitemShowRequest TVenueSportitemShowRequest){
        List<TVenueSportitem> list = venueSportitemService.getVenueSportitemListNoPages(TVenueSportitemShowRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),list);
    }


    /**
     * 场馆下所有项目、场地 场号数据的封装
     * @param TVenueSportitemShowRequest
     * @return
     */
    @ApiOperation("场馆下所有项目、场地 场号数据的封装")
    @GetMapping("/getVenueSportitemsListAboutSpaceAndSpaceNo")
    public ResponseResult getVenueSportitemsListAboutSpaceAndSpaceNo(TVenueSportitemShowRequest TVenueSportitemShowRequest){
        List<TVenueSportitem> list = venueSportitemService.selectVenueSportitemList(TVenueSportitemShowRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),list);
    }

}
