package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 18:20 2019/8/29
 * @description
 */
@Data
@ApiModel("场号请求参数")
public class VenueSpaceNoRequest implements Serializable {

    /**
     * 场号编号 MAX +1 编号
     */
    @ApiModelProperty("场号编号 MAX编号 +1 编号")
    private Long venueSpaceNoName;

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseId;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 场馆项目ID
     */
    @ApiModelProperty("场馆项目ID")
    private String venueSportitemId;

    /**
     * 场馆场地ID
     */
    @ApiModelProperty("场馆场地ID")
    private String venueSpaceId;

    /**
     * 场馆场地名称
     */
    @ApiModelProperty("场馆场地名称")
    private String venueSpaceName;

    /**
     * 运动项目编号
     */
    @ApiModelProperty("运动项目编号")
    private String sportItemCode;

    /**
     * 运行同时预定人数
     */
    @ApiModelProperty("运行同时预定人数")
    private Integer maxReservePeople;

    /**
     * 场号名称
     */
    @ApiModelProperty("场号名称，页面添加")
    private String venueSpaceNoSign;

    /**
     * SZWTL.T_VENUE_SPACE_NO
     */
    private static final long serialVersionUID = 1L;

}
