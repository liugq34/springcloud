package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 18:06 2019/8/21
 * @description 活动室分页参数
 */
@Data
@ApiModel("活动室分页参数")
public class TFieldPage implements Serializable {

    @ApiModelProperty("排序方式, 1.默认")
    private Integer sequence = 1;

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;
}
