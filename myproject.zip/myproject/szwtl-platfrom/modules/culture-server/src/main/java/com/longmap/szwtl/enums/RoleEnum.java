package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 16:21 2019/8/9
 * @description 系统划分角色
 * 角色：ADMIN（管理员）、
 * ADMINISTRATOR（市管理员）、
 * DISTRICT_ADMINISTRATOR（区管理员）、
 * SUBDISTRICT_ADMINISTRATOR（街道管理员）、
 * ENTERPRISE_ADMINISTRATOR（企业管理员）、
 * VENUE_ADMINISTRATOR（场馆管理员）、
 * VENUE_GUEST（场馆普通用户）、
 * GUEST
 */
public enum RoleEnum {

    ADMIN(1,"ADMIN"),
    ADMINISTRATOR(2,"ADMINISTRATOR"),
    DISTRICT_ADMINISTRATOR(3,"DISTRICT_ADMINISTRATOR"),
    SUBDISTRICT_ADMINISTRATOR(4,"SUBDISTRICT_ADMINISTRATOR"),
    ENTERPRISE_ADMINISTRATOR(5,"ENTERPRISE_ADMINISTRATOR"),
    VENUE_ADMINISTRATOR(6,"VENUE_ADMINISTRATOR"),
    VENUE_GUEST(7,"VENUE_GUEST"),
    GUEST(8,"GUEST"),
    ;

    private Integer code;
    private String message;

    RoleEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
