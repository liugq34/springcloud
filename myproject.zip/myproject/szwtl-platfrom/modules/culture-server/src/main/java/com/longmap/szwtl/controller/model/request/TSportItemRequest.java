package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author luor
 * @date created in 14:50 2019/8/21
 * @description
 */
@Data
@ApiModel("运动项目请求model")
public class TSportItemRequest implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("主键，添加接口不需要传值")
    private String sportItemId;

    /**
     * 运动项目名称
     */
    @ApiModelProperty("运动项目名称")
    @NotBlank(message = "运动项目名称不能为空")
    private String sportItemName;

    /**
     * 运动项目图标
     */
    @ApiModelProperty("运动项目图标")
    private String sportItemIcon;

    /**
     * 排序
     */
    @ApiModelProperty("排序,信息排序,数字小的排在前面 例如： 1 2 3")
    private Integer sort;
}
