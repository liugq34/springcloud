package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TActivitInfoPage;
import com.longmap.szwtl.controller.model.request.TActivityInfoShowRequest;
import com.longmap.szwtl.controller.model.response.TActivityInfoResponse;
import com.longmap.szwtl.service.ActivityInfoShowService;
import com.longmap.szwtl.vo.TActivityInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Api(tags = "活动展示查询接口 需要access_token")
@RequestMapping("activityInfoShow")
public class ActivityInfoShowController {

    @Autowired
    private ActivityInfoShowService activityInfoShowService;

    /**
     * 分页查询活动列表
     * @param tActivityInfo
     * @return
     */
    @GetMapping("getActivityInfoList")
    @ApiOperation("后台查询活动列表")
    public ResponseResult getActivityInfoList(@ApiParam(value = "查询活动列表请求体") @Validated TActivityInfoShowRequest tActivityInfo, @ApiParam(value = "分页排序信息") @Validated TActivitInfoPage TActivitInfoPage){
        try {
            tActivityInfo.setVisitType(2);
            PageInfo<TActivityInfo> list = activityInfoShowService.selectActivityInfoList(tActivityInfo,TActivitInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TActivityInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询活动列表失败");
        }


    }

    /**
     * 后台预定查询活动接口
     * @param activityId
     * @return
     */
    @GetMapping("/getActivityInfo/{activityId}")
    @ApiOperation("查询活动信息详情")
    public ResponseResult getActivityInfo(@ApiParam("活动ID") @PathVariable("activityId") String activityId){
        try {
            TActivityInfoResponse tActivityInfoResponse = activityInfoShowService.dispalyActivityDetail(activityId,1);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tActivityInfoResponse);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询活动信息失败");
        }

    }


    /**
     * 分页查询热门推荐列表【过期接口】
     * @param TActivitInfoPage
     * @return

    @GetMapping("getHotRecommandList")
    @ApiOperation("查询活动列表")
    public ResponseResult getHotRecommandList(@ApiParam(value = "分页排序信息") @Validated TActivitInfoPage TActivitInfoPage){
        try {
            PageInfo<TActivityInfo> list = activityInfoShowService.selectActivityInfoListForHotRecommand(TActivitInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TActivityInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询推荐活动列表失败");
        }
    }*/

    /**
     * 登入用户查看热门推荐
     * @param tActivitInfoPage
     * @return
     */
    @GetMapping("/getloginUserActivityListByTag")
    @ApiOperation("登入用户查看热门推荐列表")
    public ResponseResult getloginUserActivityListByTag(@ApiParam(value = "分页排序信息") @Validated TActivitInfoPage tActivitInfoPage){
        try {
            PageInfo<TActivityInfo> list = activityInfoShowService.loginUserShowActivityByTag(tActivitInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TActivityInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询推荐活动列表失败");
        }
    }


    /**
     * 用于订单服务接口调用
     * @param activityId
     * @return
     */
    @GetMapping("/getActivityInfoForOrderService/{activityId}")
    @ApiOperation("用于订单服务接口调用")
    public ResponseResult getActivityInfoForOrderService(@ApiParam("活动ID") @PathVariable("activityId") String activityId){
        try {
            TActivityInfo tActivityInfo = activityInfoShowService.displayActivityDetailForOrderService(activityId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tActivityInfo);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询活动信息失败");
        }

    }


}
