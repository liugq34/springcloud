package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueInfoRequest;
import com.longmap.szwtl.controller.model.request.VenueAuditRequest;
import com.longmap.szwtl.enums.ActivityStatus;
import com.longmap.szwtl.enums.VenueInfoAuditStatusEnum;
import com.longmap.szwtl.enums.VenueInfoEnum;
import com.longmap.szwtl.service.VenueInfoService;
import com.longmap.szwtl.vo.TActivityInfo;
import com.longmap.szwtl.vo.TVenueInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author luor
 * @date created in 15:41 2019/7/26
 * @description 场馆信息 controller
 */
@RestController
@RequestMapping("/venueInfo")
@Api(tags = "场馆信息控制层")
public class VenueInfoController {

    @Autowired
    private VenueInfoService venueInfoService;

    /**
     * 后台添加、修改场馆信息
     * @param tVenueInfoRequest
     * @return
     */
    @PostMapping("/addVenueInfo")
    @ApiOperation("后台系统添加、修改场馆信息")
    public ResponseResult addVenueInfo(@ApiParam("场馆、修改信息model") @Validated @RequestBody TVenueInfoRequest tVenueInfoRequest){

        /**transter*/
        TVenueInfo tVenueInfo = new TVenueInfo();
        BeanUtils.copyProperties(tVenueInfoRequest, tVenueInfo);
        try {
            //添加
            if(StringUtils.isEmpty(tVenueInfo.getVenueId())){
                int result = venueInfoService.addVenueInfo(tVenueInfo);
                //成功
                if(result>0){
                    return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"添加成功");
                }else {
                    return new ResponseResult(ResponseStatus.ERROR.getStatus(),"添加失败");
                }
                //修改
            }else {
                int result = venueInfoService.updateVenueInfo(tVenueInfo);
                //成功
                if(result>0){
                    return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"修改成功");
                }else {
                    return new ResponseResult(ResponseStatus.ERROR.getStatus(),"修改失败");
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }

    }

    /**
     * 逻辑删除场馆信息
     * @param venueId
     * @return
     */
    @PostMapping("deleteVenueInfo/{venueId}/{delete_tag}")
    @ApiOperation("后台系统逻辑删除场馆信息")
    public ResponseResult deleteVenueInfo(@ApiParam("场馆id") @PathVariable("venueId") String venueId,
                                          @ApiParam("删除标志") @PathVariable("delete_tag") Integer delete_tag){
            try {
                venueInfoService.deleteVenueInfo(venueId,delete_tag);
            }catch (Exception e){
                e.printStackTrace();
                return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
            }
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除成功");
    }


    /**
     * 推荐热门（过期）
     * @param venueId 场馆id
     * @param recommandType 热门类型 1.手动推荐
     * @return

    @ApiOperation("后台系统推荐热门")
    @PostMapping("/recommandbyHand")
    public ResponseResult recommandbyHand(@ApiParam("场馆id") @RequestParam String venueId, @ApiParam("推荐热门") @RequestParam Integer recommandType){
        try {
            venueInfoService.recommandbyHand(venueId, recommandType);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"推荐热门失败");
        }
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"推荐热门成功");
    } */

    /**
     * 浏览场馆自动增长热度（过期）
     * @param venueId 场馆id
     * @return

    @PostMapping("/hotchange")
    @ApiOperation("浏览活动自动增长热度")
    public ResponseResult hotchange(@ApiParam("场馆id") @RequestParam String venueId){
        try {
            venueInfoService.hotchange(venueId);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"热度增长异常");
        }
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"热度增长");
    }*/

    /**
     * 后台系统场馆审核状态变更
     * @param venueAuditRequest
     * @return
     */
    @PostMapping("/updateAuditStatus")
    @ApiOperation("场馆审核状态变更")
   public ResponseResult updateAuditStatus(@ApiParam("场馆model") @RequestBody VenueAuditRequest venueAuditRequest){
        try {
            venueInfoService.updateAuditStatus(venueAuditRequest);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
        if(VenueInfoAuditStatusEnum.WAIT_AUDIT.getCode().equals(venueAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息提交待审核成功");
        }else if(VenueInfoAuditStatusEnum.AUDIT_SUCCESS.getCode().equals(venueAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息审核通过成功");
        }else if(VenueInfoAuditStatusEnum.AUDIT_FAIL.getCode().equals(venueAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息审核不通过成功");
        }else if(VenueInfoAuditStatusEnum.NOT_SUBMIT.getCode().equals(venueAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息驳回成功");
        }
        return new ResponseResult(ResponseStatus.ERROR.getStatus(),"，系统繁忙，请重试");
   }


    /**
     * 后台系统场馆上下架状态
     * @param venueId
     * @param status
     * @return
     */
    @PostMapping("/updateStatus/{venueId}/{status}")
    @ApiOperation("场馆上下架状态变更")
    public ResponseResult updateStatus(@ApiParam("场馆id") @PathVariable("venueId") String venueId, @ApiParam("场馆状态") @PathVariable("status") Integer status){
        try {
            venueInfoService.updateStatus(venueId, status);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
        if(VenueInfoEnum.UP_STATUS.getCode().equals(status)){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息上架成功");
        }else if(VenueInfoEnum.DOWN_STATUS.getCode().equals(status)){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息下架成功");
        }
        return new ResponseResult(ResponseStatus.ERROR.getStatus(),"，系统繁忙，请重试");
    }

}
