package com.longmap.szwtl.controller.model.request;

import com.longmap.szwtl.common.validator.DateFormatByPattern;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author luor
 * @date created in 9:30 2019/7/30
 * @description 场馆预约信息
 */
@Data
@ApiModel("场馆修改预约信息model")
public class TVenueDestineRequest implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("主键ID,如果是多个的话拼接")
    private String id;

    /**
     * 开始时间(格式:HH:mm)
     */
    @ApiModelProperty("开始时间(格式:HH:mm)")
    private String beginTime;

    /**
     * 结束时间(格式:HH:mm)
     */
    @ApiModelProperty("结束时间(格式:HH:mm)")
    private String endTime;

    /**
     * 预定价格
     */
    @ApiModelProperty("预定价格")
    private BigDecimal ticketFee;


    /**
     * 预定人数
     */
    @ApiModelProperty("预定人数")
    private Long reservePeople;

    /**
     * 场地状态(0:正常; 1:下架)
     */
    @ApiModelProperty("场地状态(0:正常; 1:下架)")
    private Integer status;

    /**
     * 删除状态(0:正常; 1:已删除)
     */
    @ApiModelProperty("删除状态(0:正常; 1:已删除)")
    private Integer delFlag;

}
