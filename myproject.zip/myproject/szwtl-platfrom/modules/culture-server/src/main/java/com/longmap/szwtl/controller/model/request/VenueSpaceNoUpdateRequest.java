package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 19:31 2019/8/29
 * @description
 */
@Data
@ApiModel("场号修改请求参数")
public class VenueSpaceNoUpdateRequest implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("主键ID")
    private String venueSpaceNoId;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止")
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    @ApiModelProperty("删除标志 0.未删除 1.删除")
    private Integer delFlag;

    /**
     * 场号名称
     */
    @ApiModelProperty("场号名称")
    private String venueSpaceNoSign;

}
