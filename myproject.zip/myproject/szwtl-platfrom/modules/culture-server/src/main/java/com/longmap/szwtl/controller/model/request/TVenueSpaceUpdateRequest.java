package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 18:08 2019/8/29
 * @description
 */
@Data
@ApiModel("场地修改请求信息")
public class TVenueSpaceUpdateRequest implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("主键ID,修改的时候使用")
    private String venueSpaceId;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止")
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    @ApiModelProperty("删除标志 0.未删除 1.删除")
    private Integer delFlag;

}
