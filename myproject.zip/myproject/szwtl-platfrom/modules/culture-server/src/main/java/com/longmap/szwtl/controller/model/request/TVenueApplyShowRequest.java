package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("场馆申请查询条件model")
public class TVenueApplyShowRequest implements Serializable{

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 申请企业ID
     */
    @ApiModelProperty("申请企业ID")
    private String applyEnterpriseId;

    /**
     * 申请人ID
     */
    @ApiModelProperty("申请人ID")
    private String applyUser;

    /**
     * 申请人名称
     */
    @ApiModelProperty("申请人名称")
    private String applyName;

    /**
     * 申请人联系方式
     */
    @ApiModelProperty("申请人联系方式")
    private String applyPhone;

    /**
     * 预定日期(开始)
     */
    @ApiModelProperty("预定日期(开始) 格式:yyyy-MM-dd")
    private String applyBedate;

    /**
     * 预定日期(结束)
     */
    @ApiModelProperty("预定日期(结束) 格式:yyyy-MM-dd")
    private String applyEndate;

    /**
     * 省编码
     */
    @ApiModelProperty("省编码")
    private Long provinceId;

    /**
     * 市编码
     */
    @ApiModelProperty("市编码")
    private Long cityId;

    /**
     * 区域编码
     */
    @ApiModelProperty("区域编码")
    private Long districtId;

    /**
     * 街道编码
     */
    @ApiModelProperty("街道编码")
    private Long subDistrictId;

    /**
     * 审核状态
     */
    @ApiModelProperty("审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)")
    private Integer auditStatus;

    /**
     * 申请来源(1:门户; 2:微信; 3:小程序)
     */
    @ApiModelProperty("申请来源(1:门户; 2:微信; 3:小程序)")
    private Integer applySource;
}
