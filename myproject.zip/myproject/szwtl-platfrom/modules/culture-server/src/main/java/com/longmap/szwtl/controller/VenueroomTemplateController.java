package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.*;
import com.longmap.szwtl.service.VenueroomTemplateService;
import com.longmap.szwtl.vo.TVenueroomTemplate;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author luor
 * @date created in 17:47 2019/8/23
 * @description 预定信息模板
 */
@RestController
@Api(tags = "文化场馆预定信息模板的操作接口，用于系统后台")
@RequestMapping("/venueroomTemplate")
public class VenueroomTemplateController {

    @Autowired
    private VenueroomTemplateService VenueroomTemplateService;

    /**
     * 添加模板
     * @param tVenueroomTemplateRequest
     * @return
     */
    @ApiOperation("添加场馆预定信息模板")
    @PostMapping("/addVenueRoomTemplate")
    public ResponseResult addVenueRoomTemplate(@ApiParam("添加模板参数") @RequestBody @Validated
            TVenueroomTemplateRequest tVenueroomTemplateRequest){
        VenueroomTemplateService.addVenueroomTemplate(tVenueroomTemplateRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }


    /**
     *  修改场馆预定信息模板
     * @param tVenueroomTemplateRequest
     * @return
     */
    @ApiOperation("修改场馆预定信息模板")
    @PostMapping("/updateVenueRoomTemplate")
    public ResponseResult updateVenueRoomTemplate(@ApiParam("修改模板参数") @RequestBody @Validated
                                                              TVenueroomTemplateRequest tVenueroomTemplateRequest){
        VenueroomTemplateService.updateVenueroomTemplate(tVenueroomTemplateRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 场馆预定信息模板删除状态
     * @param tVenueroomTemplateStatusRequest
     * @return
     */
    @ApiOperation("场馆预定信息模板删除状态")
    @PostMapping("/updateVenueRoomTemplateStatus")
    public ResponseResult updateVenueRoomTemplateStatus(@ApiParam("修改模板状态参数") @RequestBody
            TVenueroomTemplateStatusRequest tVenueroomTemplateStatusRequest){
        VenueroomTemplateService.updateVenueroomTemplateStatus(tVenueroomTemplateStatusRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 文化场馆预定模板查询
     * @param tVenueroomTemplatePage
     * @return
     */
    @ApiOperation("查询分页")
    @GetMapping("/getTVenueroomTemplateList")
    public ResponseResult getTVenueroomTemplateList(@ApiParam("查询分页排序参数") TVenueroomTemplatePage tVenueroomTemplatePage){
        PageInfo<TVenueroomTemplate> list = VenueroomTemplateService.selectTVenueroomTemplateRequestList(tVenueroomTemplatePage);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),new IPageList<TVenueroomTemplate>(list));
    }

}
