package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author luor
 * @date created in 9:10 2019/8/28
 * @description
 */
@ApiModel("价格模板参数")
@Data
public class TsportitemPriceTemplateRequest  implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("主键ID，用于修改模板的时候添加")
    private String priceTemplateId;

    /**
     * 企业ID
     */
    @ApiModelProperty(" 企业ID")
    private String enterpriseId;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 场馆运动项目ID
     */
    @ApiModelProperty("场馆运动项目ID，用于添加的时候勾选，修改不用填写")
    private String venueSportitemId;

    /**
     * 场馆项目名称
     */
    @ApiModelProperty("场馆运动项目名称")
    private String venueSportitemName;

    /**
     * 价格模板名称
     */
    @ApiModelProperty("价格模板名称")
    private String priceTemplateName;

    /**
     * 工作日早上价格
     */
    @ApiModelProperty("工作日早上价格")
    private BigDecimal weekdayDayprice;

    /**
     * 工作日早上截至时间
     */
    @ApiModelProperty("工作日早上截至时间")
    private String weekdayDayendTime;

    /**
     * 工作日下午价格
     */
    @ApiModelProperty("工作日下午价格")
    private BigDecimal weekdayNightprice;

    /**
     * 周末早上价格
     */
    @ApiModelProperty("周末早上价格")
    private BigDecimal weekendDayprice;

    /**
     * 周末早上截至时间
     */
    @ApiModelProperty("周末早上截至时间")
    private String weekendDayendTime;

    /**
     * 周末下午价格
     */
    @ApiModelProperty("周末下午价格")
    private BigDecimal weekendNightprice;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止,用于修改状态")
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    @ApiModelProperty("删除标志 0.未删除 1.删除，用于修改状态")
    private Integer delFlag;

    /**
     * SZWTL.T_SPORTITEM_PRICE_TEMPLATE
     */
    private static final long serialVersionUID = 1L;
}
