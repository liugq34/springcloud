package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TActivityCommentPage;
import com.longmap.szwtl.controller.model.request.TActivityCommentRequest;
import com.longmap.szwtl.controller.model.request.TVenueCommentRequest;
import com.longmap.szwtl.controller.model.request.TvenueCommentPage;
import com.longmap.szwtl.service.VenueCommentService;
import com.longmap.szwtl.vo.TActivityComment;
import com.longmap.szwtl.vo.TVenueComment;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luor
 * @date created in 16:36 2019/8/2
 * @description 场馆评论
 */
@RestController
@Api(tags = "场馆评论")
@RequestMapping("/venueComment")
public class VenueCommentController {

    @Autowired
    private VenueCommentService venueCommentService;

    /**
     * 场馆添加评论
     * @param tVenueCommentRequest
     * @return
     */
    @ApiOperation("场馆添加评论")
    @PostMapping("/addVenueComment")
    public ResponseResult addVenueComment(@ApiParam("评论请求参数model") @Validated
                                                     TVenueCommentRequest tVenueCommentRequest){
        try {
            /**transter*/
            TVenueComment tVenueComment = new TVenueComment();
            BeanUtils.copyProperties(tVenueCommentRequest, tVenueComment);
            venueCommentService.addTvenueComment(tVenueComment);
        } catch (BeansException e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"评论成功");
    }

    /**
     *场馆评论制定活动查询
     * @return
     */
    @ApiOperation("场馆评论制定活动查询")
    @GetMapping("/getVenueCommentList")
    public ResponseResult getVenueCommentList(@ApiParam("活动评论分页model") TvenueCommentPage tvenueCommentPage,
                                                  @ApiParam("活动ID") String venueid){
        try {
            PageInfo<TVenueComment> pageList = venueCommentService.selectTActivityCommentByActivityinfoid(
                    tvenueCommentPage, venueid);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"查询成功", new IPageList<TVenueComment>(pageList));

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
    }

}
