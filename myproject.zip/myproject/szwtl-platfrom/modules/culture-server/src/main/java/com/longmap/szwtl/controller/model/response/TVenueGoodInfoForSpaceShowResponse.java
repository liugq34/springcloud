package com.longmap.szwtl.controller.model.response;

import com.longmap.szwtl.vo.TVenueGoodInfo;
import io.swagger.annotations.ApiModel;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * @author luor
 * @date created in 20:47 2019/8/30
 * @description
 */
@Data
@ApiModel("体育场馆每天场地场号数据封装")
public class TVenueGoodInfoForSpaceShowResponse implements Serializable {

            /**场地ID*/
            private String TvenueSpaceId;
            /**场地名称*/
            private String TvenueSpaceName;
            /**场号ID*/
            private String TvenueSpaceNoId;
            /**场号名称*/
            private String TvenueSpaceNoName;
            /**场号NO*/
            private Long venueSpaceNoName;
            /**商品列表*/
            private List<TVenueGoodInfo> tVenueGoodInfoForGoodShowResponseList;
}
