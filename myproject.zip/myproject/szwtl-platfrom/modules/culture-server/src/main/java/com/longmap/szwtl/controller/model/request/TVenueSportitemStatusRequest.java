package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 14:51 2019/8/26
 * @description
 */
@Data
@ApiModel("体育项目状态")
public class TVenueSportitemStatusRequest implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("场馆项目主键")
    private String venueSportitemId;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止")
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    @ApiModelProperty("删除标志 0.未删除 1.删除")
    private Integer delFlag;

}
