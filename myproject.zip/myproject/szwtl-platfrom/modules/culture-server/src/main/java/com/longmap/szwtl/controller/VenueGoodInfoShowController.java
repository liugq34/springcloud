package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.VenueGoodInfoBackStageShowRequest;
import com.longmap.szwtl.controller.model.request.VenueGoodInfoShowRequest;
import com.longmap.szwtl.controller.model.response.TVenueGoodInfoByUseDateResponse;
import com.longmap.szwtl.service.VenueGoodInfoService;
import com.longmap.szwtl.vo.TVenueGoodInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author luor
 * @date created in 19:35 2019/9/3
 * @description
 */
@Api(tags = "体育场馆商品展示 需要access_token")
@RestController
@RequestMapping("/venueGoodInfoShow")
public class VenueGoodInfoShowController {

    @Autowired
    private VenueGoodInfoService venueGoodInfoService;

    @ApiOperation("通过商品id查询详情")
    @GetMapping("getVenueGoodInfoDetail")
    public ResponseResult getVenueGoodInfoDetail(@ApiParam("商品id") @RequestParam(value = "goodId") String goodId){
        TVenueGoodInfo venueGoodInfoDetail = venueGoodInfoService.getVenueGoodInfoDetail(goodId);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),venueGoodInfoDetail);
    }

    /**
     * 项目下（天数）所有场地 场号 商品数据的封装
     * @param venueGoodInfoBackStageShowRequest
     * @return
     */
    @ApiOperation("后台，项目下（天数）所有场地 场号 商品数据的封装")
    @GetMapping("/selectVenueGoodInfoBackStageList")
    public ResponseResult selectVenueGoodInfoBackStageList(@ApiParam("查询请求参数") VenueGoodInfoBackStageShowRequest venueGoodInfoBackStageShowRequest){
        List<TVenueGoodInfoByUseDateResponse> list = venueGoodInfoService.selectVenueGoodInfoBackStageList(venueGoodInfoBackStageShowRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), list);
    }

}
