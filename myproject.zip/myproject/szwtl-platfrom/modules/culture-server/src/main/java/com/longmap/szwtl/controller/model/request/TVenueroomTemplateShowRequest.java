package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author luor
 * @date created in 20:15 2019/8/23
 * @description
 */
@Data
@ApiModel("场馆预定模板查询请求参数")
public class TVenueroomTemplateShowRequest implements Serializable {

    /**
     * 模板号
     */
    @ApiModelProperty("模板号")
    private String tempId;


}
