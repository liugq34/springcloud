package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 15:16 2019/8/28
 * @description
 */
public enum OccupyTypeEnum {

    STEP(1,"按步长"),
    DAYANDNIGHT(2,"按早晚"),
    DAY(3,"按天"),
    ;

    private Integer code;
    private String message;

    OccupyTypeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
