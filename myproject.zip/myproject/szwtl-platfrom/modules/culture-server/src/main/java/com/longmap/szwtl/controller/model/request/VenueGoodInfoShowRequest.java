package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 16:38 2019/8/30
 * @description
 */
@Data
@ApiModel("体育场馆商品展示请求参数")
public class VenueGoodInfoShowRequest implements Serializable {

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 场馆项目ID
     */
    @ApiModelProperty("场馆项目ID")
    private String venueItemId;

}
