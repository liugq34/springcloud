package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 14:18 2019/8/26
 * @description 正常 禁止
 */
public enum ApplyTypeEnum {
    ALONE_TYPE(1,"单个申请"),
    CUSTOMIZE_TYPE(2,"自定义申请"),
    ;
    private Integer code;
    private String message;

    ApplyTypeEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
