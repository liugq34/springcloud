package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.VenueGoodInfoRequest;
import com.longmap.szwtl.controller.model.request.VenueGoodInfoUpdateRequest;
import com.longmap.szwtl.service.VenueGoodInfoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

/**
 * @author luor
 * @date created in 10:04 2019/8/28
 * @description
 */
@RestController
@Api(tags = "体育场馆生成商品")
@RequestMapping("venueGoodInfo")
public class VenueGoodInfoController {

    @Autowired
    private VenueGoodInfoService venueGoodInfoService;

    /**
     * 添加体育场馆商品
     * @return
     */
    @ApiOperation("添加体育场馆商品")
    @PostMapping("/addVenueGood")
    public ResponseResult addVenueGoodInfo(@ApiParam("添加体育商品参数") VenueGoodInfoRequest venueGoodInfoRequest){
        String result = venueGoodInfoService.addVenueGoodInfo(venueGoodInfoRequest);
        if(StringUtils.isEmpty(result)){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
        }else {
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage(),"未处理日期:"+result);
        }
    }

    /**
     * 修改体育商品参数
     * @param venueGoodInfoUpdateRequest
     * @return
     */
    @ApiOperation("修改体育商品参数")
    @PostMapping("/updateVenueGoodInfo")
    public ResponseResult updateVenueGoodInfo(@ApiParam("修改体育商品参数") @RequestBody VenueGoodInfoUpdateRequest venueGoodInfoUpdateRequest){
        venueGoodInfoService.updateVenueGoodInfo(venueGoodInfoUpdateRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }


    /**
     * 体育场馆商品减库存
     * @return
     */
    @ApiOperation("体育场馆商品减库存")
    @PostMapping("/reduceStockForSportVenue")
    public ResponseResult reduceStockForSportVenue(@ApiParam("请求减库存venueId") @RequestParam("venueId") String venueId,
                                                   @ApiParam("请求减库存venueGoodId") @RequestParam("venueGoodId") String[] venueGoodId,
                                                   @ApiParam("请求减库存num") @RequestParam("num") Long num){
        venueGoodInfoService.reduceStockForSportVenue(venueId,venueGoodId,num);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

}
