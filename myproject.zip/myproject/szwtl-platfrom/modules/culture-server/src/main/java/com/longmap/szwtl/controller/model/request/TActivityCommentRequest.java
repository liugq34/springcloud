package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 15:31 2019/7/30
 * @description
 */
@Data
@ApiModel("活动评论请求参数model")
public class TActivityCommentRequest implements Serializable {

    /**
     * 活动ID
     */
    @ApiModelProperty("活动ID")
    @NotBlank(message = "活动ID不能为空")
    private String activityinfoid;

    /**
     * 是否匿名（0.否1.是）
     */
    @ApiModelProperty("是否匿名（0.否1.是）")
    private Long anonymous;

    /**
     * 评价（1.一星 2.二星 ...5.五星）
     */
    @ApiModelProperty("评价（1.一星 2.二星 ...5.五星）")
    @NotBlank(message = "星评不能为空")
    private Long starrating;

    /**
     * 评论内容
     */
    @ApiModelProperty("评论内容")
    private String content;

    /**
     * 图片路径
     */
    @ApiModelProperty("图片路径")
    private String picturepath;
}
