package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.exception.RestRuntimeException;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TActivityCommentPage;
import com.longmap.szwtl.controller.model.request.TActivityCommentRequest;
import com.longmap.szwtl.service.TActivityCommentService;
import com.longmap.szwtl.vo.TActivityComment;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luor
 * @date created in 15:27 2019/7/30
 * @description
 */
@RestController
@Api(tags = "活动评论")
@RequestMapping("/activityComment")
public class ActivityCommentController {

    @Autowired
    private TActivityCommentService tActivityCommentService;

    /**
     * 添加评论（打分）
     * @param tActivityCommentRequest
     *
     * @return
     */
    @ApiOperation("添加评论")
    @PostMapping("/addActivityComment")
    public ResponseResult addActivityComment(@ApiParam("评论请求参数model") @Validated
            TActivityCommentRequest tActivityCommentRequest) throws RestRuntimeException {
        try {
            /**transter*/
            TActivityComment tActivityComment = new TActivityComment();
            BeanUtils.copyProperties(tActivityCommentRequest, tActivityComment);
           tActivityCommentService.addTactivityComment(tActivityComment);
        } catch (BeansException e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"评论成功");
    }

    /**
     *评论制定活动查询
     * @return
     */
    @ApiOperation("评论制定活动查询")
    @GetMapping("/getTActivityCommentList")
    public ResponseResult getTActivityCommentList(@ApiParam("活动评论分页model") TActivityCommentPage tActivityCommentPage,
                                                  @ApiParam("活动ID") String activityinfoid){
        try {
            PageInfo<TActivityComment> pageList = tActivityCommentService.selectTActivityCommentByActivityinfoid(
                     tActivityCommentPage, activityinfoid);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"查询成功", new IPageList<TActivityComment>(pageList));

        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
    }

}
