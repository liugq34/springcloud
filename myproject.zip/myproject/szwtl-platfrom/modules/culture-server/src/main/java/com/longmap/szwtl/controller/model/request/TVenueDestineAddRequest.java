package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 16:42 2019/8/16
 * @description
 */
@Data
@ApiModel("场馆预约后台添加请求参数")
public class TVenueDestineAddRequest implements Serializable {

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID,指定的场馆")
    private String venueId;

    /**
     * 场馆活动室主键ID
     */
    @ApiModelProperty("场馆活动室主键ID,指定的场馆下的活动室")
    private String fieldId;

    /**
     * 场馆活动室发布预定开始日期
     */
    @ApiModelProperty("场馆活动室发布预定开始日期 例如 2019-12-26")
    private String beginDate;

    /**
     * 场馆活动室发布预定结束日期
     */
    @ApiModelProperty("场馆活动室发布预定开始日期 例如 2019-12-29")
    private String endDate;

    /**
     * 活动室开放时间段
     */
    @ApiModelProperty("发布时间段，最后拼接成 例如： 8:30-12:20,2:00-3:00,3:30-5:30 ")
    private String openTimeSection;

}
