package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueSportitemShowRequest;
import com.longmap.szwtl.service.VenueSportitemService;
import com.longmap.szwtl.vo.TVenueSportitem;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author luor
 * @date created in 9:54 2019/9/6
 * @description
 */
@RestController
@Api(tags = "体育场馆体育项目部分，首页展示页面，不需要token")
@RequestMapping("/tvenueSportitemShowNoToken")
public class VenueSportitemShowNoTockenController {

    @Autowired
    private VenueSportitemService venueSportitemService;

    /**
     * 查询列表(非分页)
     * @param TVenueSportitemShowRequest
     * @return
     */
    @ApiOperation("指定场馆项目查询列表")
    @GetMapping("/getVenueSportitemListNoPages")
    public ResponseResult getVenueSportitemListNoPages(@ApiParam("查询请求参数") TVenueSportitemShowRequest TVenueSportitemShowRequest){
        List<TVenueSportitem> list = venueSportitemService.getVenueSportitemListNoPages(TVenueSportitemShowRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),list);
    }
}
