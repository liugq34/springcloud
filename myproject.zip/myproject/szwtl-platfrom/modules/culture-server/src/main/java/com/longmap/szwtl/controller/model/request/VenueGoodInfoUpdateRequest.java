package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author luor
 * @date created in 11:39 2019/8/29
 * @description
 */
@Data
@ApiModel("修改请求参数")
public class VenueGoodInfoUpdateRequest implements Serializable {

    /**
     * 主键ID
     */
    @ApiModelProperty("主键ID，如果修改多个用逗号分开例如：1,2")
    private String goodId;

    /**
     * 商品名称
     */
    @ApiModelProperty("商品名称")
    private String goodName;

    /**
     * 售价
     */
    @ApiModelProperty("售价")
    private BigDecimal saleprice;

    /**
     * 总数量
     */
    @ApiModelProperty("总数量")
    private Long totalnum;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止")
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    @ApiModelProperty("删除标志 0.未删除 1.删除")
    private Integer delflag;

}
