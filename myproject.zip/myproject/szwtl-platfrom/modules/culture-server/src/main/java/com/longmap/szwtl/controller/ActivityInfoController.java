package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.exception.RestRuntimeException;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.ActivityInfoAuditRequest;
import com.longmap.szwtl.controller.model.request.TActivityInfosVo;
import com.longmap.szwtl.enums.ActivityAuditStatusEnum;
import com.longmap.szwtl.enums.ActivityStatus;
import com.longmap.szwtl.service.ActivityInfoService;
import com.longmap.szwtl.service.RedisService;
import com.longmap.szwtl.vo.TActivityInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author luor
 * @date created in 17:34 2019/7/22
 * @descriptioni
 */
@RestController
@RequestMapping("activityInfo")
@Api(tags = "活动表增删改，用于后台业务员操作")
public class ActivityInfoController {

    @Autowired
    private ActivityInfoService activityInfoService;

    /**
     * 通过id查询
     * @return
     */
    @GetMapping("queryById")
    @ApiOperation("通过id查询")
    public TActivityInfo queryById(@ApiParam("活动表id") String activityId){
        return activityInfoService.queryTActivityInfo(activityId);
    }

    /**
     * 后台添加、修改活动信息表
     * @param tActivityInfosVo
     * @return
     */
    @PostMapping("addTActivityInfo")
    @ApiOperation("后台系统添加、修改活动信息表")
    public ResponseResult addTActivityInfo(@ApiParam("添加、修改活动实体") @Validated @RequestBody TActivityInfosVo tActivityInfosVo){
        /***传参验证
        if(bindingResult.hasErrors()){
            if(bindingResult.hasErrors()){
                for (ObjectError error : bindingResult.getAllErrors()){
                    throw new ActivityInfoException(2,error.getDefaultMessage());
                }
            }
        }*/

        /**transter*/
        TActivityInfo tActivityInfo = new TActivityInfo();
        BeanUtils.copyProperties(tActivityInfosVo, tActivityInfo);

        try {
            //添加
            if(StringUtils.isEmpty(tActivityInfo.getActivityId())){
                int result = activityInfoService.addActivity(tActivityInfo);
                //成功
                if(result>0){
                    return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"添加成功");
                }else {
                    return new ResponseResult(ResponseStatus.ERROR.getStatus(),"添加失败");
                }
                //修改
            }else {
                int result = activityInfoService.updateActivityInfo(tActivityInfo);
                //成功
                if(result>0){
                    return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"修改成功");
                }else {
                    return new ResponseResult(ResponseStatus.ERROR.getStatus(),"修改失败");
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败");
        }
    }


    /**
     * 后台系统逻辑删除
     */
    @PostMapping("/deleteActivityInfo/{activityId}/{delete_tag}")
    @ApiOperation("删除活动")
    public ResponseResult deleteActivityInfo(@ApiParam("活动信息表id") @PathVariable("activityId") String activityId,
                                             @ApiParam("删除标志")   @PathVariable("delete_tag") Integer delete_tag){
        try {
            int result = activityInfoService.updateDeleteTag(activityId,delete_tag);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除成功");
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"删除失败");
        }
    }

    /**
     * 后台系统推荐热门
     * @param activityId 活动id
     * @param recommandType 热门类型 1.手动推荐
     * @return
     */
    @ApiOperation("推荐热门")
    @PostMapping("/recommandbyHand")
    public ResponseResult recommandbyHand(@ApiParam("活动id") @RequestParam String activityId, @ApiParam("推荐热门") @RequestParam Integer recommandType){
        try {
            activityInfoService.recommandbyHand(activityId, recommandType);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"推荐热门失败");
        }
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"推荐热门成功");
    }

    /**
     * 浏览活动自动增长热度
     * @param activityId 活动id
     * @return
     */
    @PostMapping("/hotchange")
    @ApiOperation("浏览活动自动增长热度")
    public ResponseResult hotchange(@ApiParam("活动id") @RequestParam String activityId){
        try {
            activityInfoService.hotchange(activityId);
        } catch (Exception e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"热度增长异常");
        }
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"热度增长");
    }

    /**
     * 后台系统活动审核状态变更
     * @param activityInfoAuditRequest
     * @return
     */
    @PostMapping("/updateAuditStatus")
    @ApiOperation("活动审核状态变更")
    public ResponseResult updateAuditStatus(@ApiParam("活动审核请求参数") @RequestBody ActivityInfoAuditRequest activityInfoAuditRequest){
        try {
            activityInfoService.updateAuditStatus(activityInfoAuditRequest);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
        if(ActivityAuditStatusEnum.WAIT_AUDIT.getCode().equals(activityInfoAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息提交待审核成功");
        }else if(ActivityAuditStatusEnum.AUDIT_SUCCESS.getCode().equals(activityInfoAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息审核通过成功");
        }else if(ActivityAuditStatusEnum.AUDIT_FAIL.getCode().equals(activityInfoAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息审核不通过成功");
        }else if(ActivityAuditStatusEnum.NOT_SUBMIT.getCode().equals(activityInfoAuditRequest.getAuditStatus())){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"场馆信息驳回成功");
        }
        return new ResponseResult(ResponseStatus.ERROR.getStatus(),"，系统繁忙，请重试");
    }

    /**
     * 后台系统活动上下架状态
     * @param activityId
     * @param status
     * @return
     */
    @PostMapping("/updateStatus/{activityId}/{status}")
    @ApiOperation("活动上下架状态变更")
    public ResponseResult updateStatus(@ApiParam("活动id") @PathVariable("activityId") String activityId, @ApiParam("活动状态") @PathVariable("status") Integer status){
        try {
            activityInfoService.updateStatus(activityId, status);
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"操作失败："+e.getLocalizedMessage());
        }
        if(ActivityStatus.UP_STATUS.getCode().equals(status)){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"活动信息上架成功");
        }else if(ActivityStatus.DOWN_STATUS.getCode().equals(status)){
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"活动信息下架成功");
        }
        return new ResponseResult(ResponseStatus.ERROR.getStatus(),"，系统繁忙，请重试");
    }

    /**
     * 活动减库存
     * @return
     */
    @GetMapping("/reduceStock")
    @ApiOperation("活动减库存")
    public ResponseResult reduceStock(@ApiParam("请求减库存model") @RequestParam("activityId") String activityId, @ApiParam("请求减库存model") @RequestParam("num") Integer num){
        try {
            TActivityInfo tActivityInfoForReducStock = new TActivityInfo();
            tActivityInfoForReducStock.setActivityId(activityId);
            tActivityInfoForReducStock.setTicketRemainder(num);
            activityInfoService.reduceStock(tActivityInfoForReducStock);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),"成功减库存");
        } catch (RestRuntimeException e) {
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"，操作失败："+e.getLocalizedMessage());
        }

    }
}
