package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiParam;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 9:48 2019/8/13
 * @description
 */
@Data
@ApiModel("审核日志请求参数")
public class TAuditLogRequest implements Serializable {

    /**
     * 对应业务表ID
     */
    @ApiParam("对应业务表ID")
    private String businessId;

}
