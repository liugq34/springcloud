package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author luor
 * @date created in 17:53 2019/8/23
 * @description
 */
@Data
@ApiModel("页面新增修改请求参数model")
public class TVenueroomTemplateRequest implements Serializable {

    /**
     * 模板号
     */
    @ApiModelProperty("模板号,修改需要传值")
    private String tempId;

    /**
     * 模板名称
     */
    @ApiModelProperty("模板名称")
    @NotBlank(message = "模板名称不能为空")
    private String tempName;

    /**
     * 开始时间
     */
    @ApiModelProperty("开始时间,时间段 例如：9:00-10:00，14:00-16:00 ")
    @NotNull(message = "开始时间不能为空")
    private String startTime;

}
