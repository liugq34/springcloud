package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
@Data
@ApiModel("申请审核model")
public class TVenueApplyAuditRequest implements Serializable{

    /**
     * id
     **/
    @ApiModelProperty("id")
    @NotBlank(message = "id不能为空")
    private String id;

    /**
     * id
     **/
    @ApiModelProperty("活动审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)")
    @NotNull(message = "审核状态不能为空")
    private Integer auditStatus;

    /**
     * 回退原因(审核不通过填写)
     **/
    @ApiModelProperty("回退原因(审核不通过填写)")
    private String rollbackReason;

    /**
     * 修改建议(审核不通过填写)
     **/
    @ApiModelProperty("修改建议(审核不通过填写)")
    private String modifiedSuggest;
}
