package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 14:41 2019/8/19
 * @description
 */
public enum  CanReserve {

        CAN_RESERVE(1,"可以预订"),
        CANT_DESTINE(0,"不能预定"),
        ;
        private Integer code;
        private String message;

    CanReserve(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
