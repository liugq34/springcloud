package com.longmap.szwtl.controller.model.response;

import com.longmap.szwtl.vo.TAuditLog;
import com.longmap.szwtl.vo.TField;
import com.longmap.szwtl.vo.TVenueDestine;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author luor
 * @date created in 9:48 2019/8/9
 * @description
 */
@Data
public class TVenueInfoResponse {

    /**
     * 场馆Id
     */
    private String venueId;

    /**
     * 原图
     */
    @ApiModelProperty("原图")
    private String picture;

    /**
     * 横图  13:7
     */
    @ApiModelProperty("横图 13:7")
    private String pictureHorizontal;

    /**
     * 竖图  5:7
     */
    @ApiModelProperty("竖图 5:7")
    private String pictureVertical;

    /**
     * 场馆名称
     */
    private String venueName;

    /**
     * 场馆类型
     */
    private Integer venueType;

    /**
     * 场馆类别
     */
    private Integer venueClass;

    /**
     * 场馆地点
     */
    private String address;

    /**
     * 经度
     */
    private String longitude;

    /**
     * 维度
     */
    private String latitude;

    /**
     * 联系人
     */
    private String linkman;

    /**
     * 联系方式
     */
    private String phone;

    /**
     * 温馨提示
     */
    private String warmPoint;

    /**
     * 开放时间
     */
    private String openTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 场馆状态(0:正常; 1:下架)
     */
    private Integer status;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 是否可以预定（0.不可预定，1.可以预定）
     */
    private Integer reserveStatus;

    /**
     * 省编号
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编号
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编号
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道编号
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 场馆详情
     */
    private String introduce;


    /**
     * 场馆审核日志记录
     */
    private List<TAuditLog> tAuditLogList;

    /**
     * 场馆活动室
     */
    private List<TField> tFielList;

    /**
     * 机构代码
     */
    private String institutionCode;

    /**
     * 单位性质
     */
    private String unitNature;

    /**
     * 法人代表
     */
    private String legalRepresentative;

    /**
     * 法人代表联系电话
     */
    private String legalRepresentativePhone;

    /**
     * 负责人
     */
    private String personInCharge;

    /**
     * 负责人电话
     */
    private String personInChargePhone;

    /**
     * 主管部门
     */
    private Integer competentDepartmentType;

    /**
     * 设施面积
     */
    private String facilityArea;

    /**
     * 建成时间
     */
    private String completionTime;

    /**
     * 用地面积
     */
    private String landArea;

    /**
     * 建筑面积
     */
    private String builtUpArea;

    /**
     * 场地面积
     */
    private String siteArea;

    /**
     * 运营模式
     */
    private String operationalModel;

    /**
     * 经费来源
     */
    private String sourcesFunds;

    /**
     * 员工人数
     */
    private String employeesNum;

    /**
     * 场馆简介
     */
    private String briefIntroduction;
}
