package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TVenueApplyRequest;
import com.longmap.szwtl.controller.model.request.TVenueApplyShowRequest;
import com.longmap.szwtl.controller.model.request.TvenueCommentPage;
import com.longmap.szwtl.service.VenueApplyService;
import com.longmap.szwtl.service.VenueApplyShowService;
import com.longmap.szwtl.vo.TActivityInfo;
import com.longmap.szwtl.vo.TVenueApply;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * @author lenovo
 */
@RestController
@Api(tags = "文化场馆使用申请查询接口")
@RequestMapping("venueApplyShow")
public class VenueApplyShowController {

    @Autowired
    private VenueApplyShowService venueApplyShowService;

    @GetMapping("getVenueApply/{id}")
    @ApiOperation("查询申请信息详情")
    public ResponseResult getVenueApply(@ApiParam("申请id") @PathVariable("id") String id){
        TVenueApply tVenueApply = venueApplyShowService.getVenueApply(id);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tVenueApply);

    }


    @GetMapping("getVenueApplyList")
    @ApiOperation("查询申请信息列表")
    public ResponseResult getVenueApplyList(@ApiParam("申请场馆信息查询条件model") @Validated TVenueApplyShowRequest tVenueApplyShowRequest, TvenueCommentPage tvenueCommentPage){
        PageInfo<TVenueApply> list = venueApplyShowService.getVenueApplyList(tVenueApplyShowRequest,tvenueCommentPage);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TVenueApply>(list));
    }


}
