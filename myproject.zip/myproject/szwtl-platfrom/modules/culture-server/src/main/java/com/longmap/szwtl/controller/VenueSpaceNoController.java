package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.VenueSpaceNoRequest;
import com.longmap.szwtl.controller.model.request.VenueSpaceNoUpdateRequest;
import com.longmap.szwtl.service.VenueSpaceNoService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author luor
 * @date created in 19:22 2019/8/29
 * @description
 */
@RestController
@Api(tags = "场馆号")
@RequestMapping("/venueSpaceNo")
public class VenueSpaceNoController {

    @Autowired
    private VenueSpaceNoService venueSpaceNoService;

    /***
     * 添加场号
     * @param venueSpaceNoRequest
     * @return
     */
    @ApiOperation("添加场号")
    @PostMapping("/addVenueSpaceNo")
    public ResponseResult addVenueSpaceNo(@ApiParam("场号请求参数") @RequestBody VenueSpaceNoRequest venueSpaceNoRequest){
        venueSpaceNoService.addVenueSpaceNo(venueSpaceNoRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    /**
     * 修改场号
     * @param venueSpaceNoUpdateRequest
     * @return
     */
    @ApiOperation("修改场号")
    @PostMapping("/updateVenueSpaceNo")
    public ResponseResult updateVenueSpaceNo(@ApiParam("场号请求参数") @RequestBody VenueSpaceNoUpdateRequest venueSpaceNoUpdateRequest){
        venueSpaceNoService.updateVenueSpaceNo(venueSpaceNoUpdateRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }

    @ApiOperation("查询场号详情")
    @PostMapping("/getTVenueSpaceNoDetail")
    public ResponseResult getTVenueSpaceNoDetail(@ApiParam("venueSpaceNoId") @RequestParam(value = "venueSpaceNoId") String venueSpaceNoId){
        venueSpaceNoService.getTVenueSpaceNoById(venueSpaceNoId);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),ResponseStatus.SUCCESS.getMessage());
    }
}
