package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@ApiModel("购买商品model")
public class VenueOrderRequest implements Serializable {

    /**
     * 场馆id
     **/
    @ApiModelProperty("场馆id")
    @NotBlank(message = "场馆id不能为空")
    private String venueId;

    /**
     * 预定日期id
     **/
    @ApiModelProperty("预定日期id")
    @NotBlank(message = "预定日期id不能为空")
    private String destIneId;

    /**
     * 订单类型
     **/
    @ApiModelProperty("订单类型(1:文化场馆 2:体育场馆)")
    @NotNull(message = "订单类型不能为空")
    private Long orderType;

    /**
     * 支付类型
     **/
    @ApiModelProperty("支付方式：（1：支付宝；2：微信）")
    private Long entType;

    /**
     * 预订人数
     **/
    @ApiModelProperty("预订人数")
    @NotNull(message = "预订人数不能为空")
    private Long num;

    /**
     * 买家id
     **/
    @ApiModelProperty("买家id(空)")
    private String buyerId;

    /**
     * 买家名称
     **/
    @ApiModelProperty("买家名称(空)")
    private String buyerNick;

    /**
     * 买家手机号
     **/
    @ApiModelProperty("买家手机号(空)")
    private String buyerContact;

    /**
     * 买家备注
     **/
    @ApiModelProperty("买家备注")
    private String buyerMemo;

    /**
     * 订单标识
     **/
    @ApiModelProperty("0:页面零售订单 1:场馆申请订单")
    private Integer mark;

    /**
     * 订单来源(1:门户; 2:微信; 3:小程序)
     */
    @ApiModelProperty("订单来源(1:门户; 2:微信; 3:小程序)")
    private Long orderSource;

    /**
     * 申请id
     **/
    @ApiModelProperty("申请id")
    private String applyId;
}
