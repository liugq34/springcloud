package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.TActivitInfoPage;
import com.longmap.szwtl.controller.model.request.TActivityInfoShowRequest;
import com.longmap.szwtl.controller.model.request.TAuditLogPage;
import com.longmap.szwtl.controller.model.request.TAuditLogRequest;
import com.longmap.szwtl.service.TAuditLogService;
import com.longmap.szwtl.vo.TActivityInfo;
import com.longmap.szwtl.vo.TAuditLog;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luor
 * @date created in 11:04 2019/8/13
 * @description 审核日志需要 access_token
 */
@RestController
@Api(tags = "审核日志 需要 access_token")
@RequestMapping("/auditLog")
public class AuditLogController {

    @Autowired
    private TAuditLogService tAuditLogService;

    @GetMapping("getAuditLogListPages")
    @ApiOperation("查询审核日志列表")
    public ResponseResult getAuditLogListPages(
            @ApiParam(value = "查询审核日志列表请求体") TAuditLogRequest tAuditLogRequest,
            @ApiParam(value = "分页排序信息") @Validated TAuditLogPage tAuditLogPage){
        try {
            PageInfo<TAuditLog> list = tAuditLogService.selectAuditLogList(tAuditLogRequest, tAuditLogPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TAuditLog>(list));
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询审核日志列表失败");
        }
    }
}
