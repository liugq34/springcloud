package com.longmap.szwtl.base;

import com.alibaba.fastjson.JSON;
import com.longmap.szwtl.base.service.IAuthService;
import com.longmap.szwtl.common.pojo.RoleForActivityObj;
import com.longmap.szwtl.common.pojo.RoleObj;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.enums.RoleEnum;
import com.longmap.szwtl.pojo.response.BaseRole;
import com.longmap.szwtl.pojo.response.BaseUserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author Created by luor on 2019/8/5 10:33
 * @description
 **/
@Component
public class BaseService {
    @Autowired
    private IAuthService iAuthService;

    /**
     * 获取当前登入用户信息
     * @return
     */
    public BaseUserInfo getUserInfo() {
        ResponseResult responseResult = iAuthService.getUserInfo();
        BaseUserInfo baseUserInfo = null;
        if (ResponseStatus.SUCCESS.getStatus().equals(responseResult.getStatus())) {
           // baseUserInfo = JSON.parseObject(responseResult.getData().toString(), BaseUserInfo.class);
            baseUserInfo = JSON.parseObject(JSON.toJSON(responseResult.getData()).toString(), BaseUserInfo.class);
            System.out.println(baseUserInfo);
        }
        return baseUserInfo;
    }


    /**
     * 根据当前登入用户角色分配数据权限活动
     * @return
     */
    public RoleForActivityObj jointSqlForActiviy(){
        RoleForActivityObj roleObj = new RoleForActivityObj();
        //获取当前用户
        BaseUserInfo baseUserInfo = getUserInfo();
        List<BaseRole> roleList = baseUserInfo.getRoles();
        if(roleList != null && roleList.size()!= 0){
            for (BaseRole baseRole: roleList) { //查询需要排序
                if( baseRole.getRoleCode().equals(RoleEnum.ADMIN.getMessage())){
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.ADMINISTRATOR.getMessage())){
                    roleObj.setCityId(baseUserInfo.getCityId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.DISTRICT_ADMINISTRATOR.getMessage())){
                    roleObj.setDistrictId(baseUserInfo.getDistrictId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.SUBDISTRICT_ADMINISTRATOR.getMessage())){
                    roleObj.setSubDistrictId(baseUserInfo.getSubDistrictId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.ENTERPRISE_ADMINISTRATOR.getMessage())){
                    roleObj.setCreateUserEnterpriseId(baseUserInfo.getEnterpriseId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.VENUE_ADMINISTRATOR.getMessage())){
                    roleObj.setCreateUserVenueId(baseUserInfo.getStoreId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.VENUE_GUEST.getMessage())){
                    roleObj.setCreateUserVenueId(baseUserInfo.getStoreId());
                    //roleObj.setCreateUserId(baseUserInfo.getId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.GUEST.getMessage())){
                    roleObj.setCreateUserId(baseUserInfo.getId());
                    break;
                }
            }
        }
        return roleObj;
    }

    /**
     * 根据当前登入用户角色分配数据权限场馆
     * @return
     */
    public RoleObj jointSql(){
        RoleObj roleObj = new RoleObj();
        //获取当前用户
        BaseUserInfo baseUserInfo = getUserInfo();
        List<BaseRole> roleList = baseUserInfo.getRoles();
        if(roleList != null && roleList.size()!= 0){
            for (BaseRole baseRole: roleList) { //查询需要排序
                if( baseRole.getRoleCode().equals(RoleEnum.ADMIN.getMessage())){
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.ADMINISTRATOR.getMessage())){
                    roleObj.setCityId(baseUserInfo.getCityId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.DISTRICT_ADMINISTRATOR.getMessage())){
                    roleObj.setDistrictId(baseUserInfo.getDistrictId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.SUBDISTRICT_ADMINISTRATOR.getMessage())){
                    //stringBuffer.append(" ADN  SUB_DISTRICT_ID = ‘").append(baseUserInfo.getSubDistrictId()).append("' ");
                    roleObj.setSubDistrictId(baseUserInfo.getSubDistrictId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.ENTERPRISE_ADMINISTRATOR.getMessage())){
                    roleObj.setEnterpriseId(baseUserInfo.getEnterpriseId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.VENUE_ADMINISTRATOR.getMessage())){
                    roleObj.setStoreId(baseUserInfo.getStoreId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.VENUE_GUEST.getMessage())){
                    roleObj.setStoreId(baseUserInfo.getStoreId());
                    //roleObj.setCreateUserId(baseUserInfo.getId());
                    break;
                }
                if( baseRole.getRoleCode().equals(RoleEnum.GUEST.getMessage())){
                    roleObj.setCreateUserId(baseUserInfo.getId());
                    break;
                }
            }
        }
        return roleObj;
    }
}
