package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.*;
import com.longmap.szwtl.controller.model.response.TVenueInfoForTabResponse;
import com.longmap.szwtl.controller.model.response.TVenueInfoResponse;
import com.longmap.szwtl.service.TAuditLogService;
import com.longmap.szwtl.service.VenueInfoShowService;
import com.longmap.szwtl.vo.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@Api(tags = "场馆信息查询接口 需要access_token")
@RequestMapping("/venueInfoShow")
public class VenueInfoShowController {

    @Autowired
    private VenueInfoShowService venueInfoShowService;

    /**
     * 查询场馆列表
     * @param venueInfo
     * @param tVenueInfoPage
     * @return
     */
    @GetMapping("/getVenueInfoList")
    @ApiOperation("查询场馆列表")
    public ResponseResult getVenueInfoList(@ApiParam(value = "查询场馆列表请求体") VenueInfoShowRequest venueInfo,
                                           @ApiParam(value = "分页排序信息") @Validated TVenueInfoPage tVenueInfoPage){
        try {
            venueInfo.setVisitType(2); //登入者身份设定
            PageInfo<TVenueInfo> list = venueInfoShowService.selectVenueInfoList(venueInfo,tVenueInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TVenueInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆列表失败");
        }
    }

    /**
     * 查询场馆详情
     * @param venueId
     * @return
     */
    @GetMapping("getVenueInfo")
    @ApiOperation("查询场馆详情")
    public ResponseResult getVenueInfo(@ApiParam("场馆ID") @RequestParam(value = "venueId") String venueId){
        try {
            TVenueInfoResponse tVenueInfoResponse = venueInfoShowService.selectVenueInfo(venueId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tVenueInfoResponse);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆列表失败");
        }
    }

    /**
     * 查询场馆详情,只查询场馆
     * @param venueId
     * @return
     */
    @GetMapping("getVenueInfoOnlyVenue")
    @ApiOperation("查询场馆详情,只查询场馆")
    public ResponseResult getVenueInfoOnlyVenue(@ApiParam("场馆ID") @RequestParam(value = "venueId") String venueId){
        try {
            TVenueInfo tVenueInfo = venueInfoShowService.getVenueInfoOnlyVenue(venueId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tVenueInfo);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆列表失败");
        }
    }

    /**
     * 前台 后台查询预定列表
     * @param venueId
     * @return
     */
    @GetMapping("getVenueDestineList/{venueId}/{fieldId}")
    @ApiOperation("前台 后台查询预定列表(展示表格预定图)")
    public ResponseResult getVenueDestineList(@ApiParam("场馆ID") @PathVariable(value = "venueId") String venueId
          ,@ApiParam("活动室ID") @PathVariable(value = "fieldId") String fieldId){
        try {
            TField tField = venueInfoShowService.selectVenueDestineList(venueId, fieldId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tField);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆预定列表失败");
        }
    }

    /**
     * 查询相关活动
     * @param venueId
     * @return
     */
    @GetMapping("getRelatedActivity/{venueId}")
    @ApiOperation("查询相关活动")
    public ResponseResult getRelatedActivity(@ApiParam("场馆ID") @PathVariable(value = "venueId") String venueId){
        try {
            List<TActivityInfo> list = venueInfoShowService.selectRelatedActivity(venueId);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),list);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询相关活动失败");
        }
    }

    /**
     * 查询预订信息
     * @param id
     * @return
     */
    @GetMapping("getVenueDestine")
    @ApiOperation("查询预订信息")
    public ResponseResult getVenueDestine(@ApiParam("预定ID") @RequestParam(value = "id") String id){
        try {
            TVenueDestine tVenueDestine = venueInfoShowService.selectVenueDestine(id);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(),tVenueDestine);
        }catch (Exception e){
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询预订信息失败");
        }
    }

    /**
     * 场馆查看热门推荐列表
     * @param tVenueInfoPage
     * @return
     */
    @GetMapping("getTVenueInfoListByStarrating")
    @ApiOperation("场馆查看热门推荐列表")
    public ResponseResult getTVenueInfoListByStarrating(@ApiParam(value = "分页排序信息") @Validated TVenueInfoPage tVenueInfoPage){
        try {
            PageInfo<TVenueInfo> list = venueInfoShowService.getTVenueInfoListByStarrating(tVenueInfoPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TVenueInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆推荐活动列表失败");
        }
    }


    /**
     * 场馆下拉框展示,用于查询所有
     * @param tVenueInfoForTabRequest
     * @return
     */
    @ApiOperation("场馆下拉框展示,用于查询所有")
    @GetMapping("/getAllListForAll")
     public ResponseResult getAllListForAll(@ApiParam("请求参数") TVenueInfoForTabRequest tVenueInfoForTabRequest){
        tVenueInfoForTabRequest.setBit(1);
        List<TVenueInfoForTabResponse> list =  venueInfoShowService.getTvenueInfoList(tVenueInfoForTabRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), list);
     }

    /**
     * 场馆下拉框展示,用于企业管理员查询企业下场馆
     * @param tVenueInfoForTabRequest
     * @return
     */
    @ApiOperation("场馆下拉框展示,用于企业管理员查询企业下场馆")
    @GetMapping("/getAllListForEnter")
    public ResponseResult getAllListForEnter(@ApiParam("请求参数")TVenueInfoForTabRequest tVenueInfoForTabRequest){
        tVenueInfoForTabRequest.setBit(2);
        List<TVenueInfoForTabResponse> list =  venueInfoShowService.getTvenueInfoList(tVenueInfoForTabRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), list);
    }

    /**
     * 查询场馆列表
     * @param venueInfoShowForWisdomPublicationRequest
     * @param venueInfoShowForWisdomPublicationPage
     * @return
     */
    @GetMapping("/selectVenueInfoListAndVenueInfoSportitems")
    @ApiOperation("查询场馆列表，智慧刊物")
    public ResponseResult selectVenueInfoListAndVenueInfoSportitems(@ApiParam(value = "查询场馆列表请求体") VenueInfoShowForWisdomPublicationRequest venueInfoShowForWisdomPublicationRequest,
                                                                    @ApiParam(value = "分页排序信息") VenueInfoShowForWisdomPublicationPage venueInfoShowForWisdomPublicationPage){
        try {
            venueInfoShowForWisdomPublicationRequest.setVisitType(2); //登入者身份设定
            PageInfo<TVenueInfo> list = venueInfoShowService.selectVenueInfoListAndVenueInfoSportitems(venueInfoShowForWisdomPublicationRequest,venueInfoShowForWisdomPublicationPage);
            return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<TVenueInfo>(list));
        }catch (Exception e){
            e.printStackTrace();
            return new ResponseResult(ResponseStatus.ERROR.getStatus(),"查询场馆列表失败");
        }
    }
}
