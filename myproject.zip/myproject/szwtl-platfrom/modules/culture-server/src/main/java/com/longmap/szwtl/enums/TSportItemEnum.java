package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 15:48 2019/8/21
 * @description 运动项目状态枚举
 */
public enum TSportItemEnum {

    NORMAL(1,"正常"),
    FORBID(2,"禁止"),
    ;
    private Integer code;
    private String message;

    TSportItemEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
