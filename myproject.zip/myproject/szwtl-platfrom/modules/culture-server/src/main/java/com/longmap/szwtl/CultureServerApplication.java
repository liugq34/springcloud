package com.longmap.szwtl;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * 文化体育服务
 *
 * @author Created by oushaohui on 2019/7/11 15:18
 * @ EnableDiscoveryClient 启用服务注册发现
 */
@SpringBootApplication
@EnableDiscoveryClient
@EnableFeignClients
@MapperScan("com.longmap.szwtl.mapper")
public class CultureServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(CultureServerApplication.class, args);
    }
}
