package com.longmap.szwtl.controller;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author luor
 * @date created in 14:46 2019/8/6
 * @description
 */
@RestController
@Validated
public class BaseController {



}
