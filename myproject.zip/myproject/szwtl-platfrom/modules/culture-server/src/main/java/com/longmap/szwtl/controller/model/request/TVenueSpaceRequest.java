package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 19:59 2019/8/26
 * @description
 */
@Data
@ApiModel("场地请求信息")
public class TVenueSpaceRequest implements Serializable {
    /**
     * 主键ID
     */
    @ApiModelProperty("主键ID,修改的时候使用")
    private String venueSpaceId;

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseId;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String venueId;

    /**
     * 场馆场地名称
     */
    @ApiModelProperty("场馆场地名称")
    private String venueSpaceName;

    /**
     * 场馆项目ID
     */
    @ApiModelProperty("场馆项目ID")
    private String venueSportitemId;

    /**
     * 最大预定人数
     */
    @ApiModelProperty("最大预定人数")
    private Long maxReservePerson;

    /**
     * 状态 1.正常 2.禁止
     */
    @ApiModelProperty("状态 1.正常 2.禁止")
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    @ApiModelProperty("删除标志 0.未删除 1.删除")
    private Integer delFlag;

    /**
     * 生成场地的时候批量生成场地场号
     */
    @ApiModelProperty("生成场地的时候批量生成场地场号,比如传入 2 后台生成场号1 2")
    private Long batchGenerateVenueSpaceNo;

    /**
     * SZWTL.T_VENUE_SPACE
     */
    private static final long serialVersionUID = 1L;
}
