package com.longmap.szwtl.controller.model.request;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Controller;

@Data
@Controller
@ConfigurationProperties(prefix="sms.type")
public class SmsTemplate {

    private String venueApplyAuditSuccess;

    private String venueApplyAuditFailure;

    /**活动审核短信通知信息*/
    private String activityAuditSuccess;
    private String activityAuditFailure;

    /**场馆审核短信通知信息*/
    private String venueInfoAuditSuccess;
    private String venueInfoAuditFailure;
}
