package com.longmap.szwtl.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.controller.model.request.VenueGoodInfoShowRequest;
import com.longmap.szwtl.controller.model.response.TVenueGoodInfoByUseDateResponse;
import com.longmap.szwtl.service.VenueGoodInfoService;
import com.longmap.szwtl.vo.TVenueGoodInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author luor
 * @date created in 16:36 2019/8/30
 * @description 体育场馆商品 不需要access_token
 */
@Api(tags = "体育场馆商品展示 不需要access_token")
@RestController
@RequestMapping("/venueGoodInfoShowNoToken")
public class VenueGoodInfoShowNoTokenController {

    @Autowired
    private com.longmap.szwtl.service.VenueGoodInfoService VenueGoodInfoService;


    /**
     * 项目下（天数）所有场地 场号 商品数据的封装
     * @param venueGoodInfoShowRequest
     * @return
     */
    @ApiOperation("前台，项目下（天数）所有场地 场号 商品数据的封装")
    @GetMapping("/getSelectVenueGoodInfoShowList")
    public ResponseResult getSelectVenueGoodInfoShowList(@ApiParam("查询请求参数") VenueGoodInfoShowRequest venueGoodInfoShowRequest){
        List<TVenueGoodInfoByUseDateResponse> list = VenueGoodInfoService.selectVenueGoodInfoList(venueGoodInfoShowRequest);
        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), list);
    }
}
