package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author luor
 * @date created in 14:57 2019/8/16
 * @description
 */
@Data
@ApiModel("场馆活动室添加请求参数")
public class TFieldRequest implements Serializable {

    /**
     * 场馆活动室主键ID
     */
    @ApiModelProperty("场馆活动室主键ID，修改时候添加")
    private String fieldId;

    /**
     * 场馆活动室名称
     */
    @ApiModelProperty("场馆活动室名称")
    @NotBlank(message = "场馆活动室名称不能为空")
    private String fieldName;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    @NotBlank(message = "场馆ID不能为空")
    private String venueId;

    /**
     * 场馆名称
     */
    @ApiModelProperty("场馆名称")
    private String venueName;

    /**
     * 企业ID
     */
    @ApiModelProperty("企业ID")
    private String enterpriseId;

    /**
     * 活动室介绍
     */
    @ApiModelProperty("活动室介绍")
    private String fieldIntroduce;

    /**
     * 活动室开放时间
     */
    @ApiModelProperty("活动室介绍")
    private String fieldOpenTime;

    /**
     * 最大容纳人数
     */
    @ApiModelProperty("最大容纳人数")
    private Long maxContainPeople;

    /**
     * 活动室状态 1.手动审核 2.自动审核
     */
    @ApiModelProperty("活动室状态 1.手动审核 2.自动审核")
    private Integer auditType;

    /**
     * 电脑端图片
     */
    @ApiModelProperty("电脑端展示图片,多张图片用逗号拼接 例如 xx.png,xx.png ")
    @NotBlank(message = "图片不能为空")
    private String picturePc;

    /**
     * 手机端图片
     */
    @NotBlank(message = "图片不能为空")
    @ApiModelProperty("手机端展示图片,多张图片用逗号拼接 例如 xx.png,xx.png ")
    private String pictureMc;

    /**
     * 活动室设备
     */
    @ApiModelProperty("活动室设备")
    private String fieldDevice;

    /**
     * 活动室功能用途
     */
    @ApiModelProperty("活动室功能用途")
    private String fieldFunction;


    /**
     * 类别Id
     */
    @ApiModelProperty("类别Id ,拼接")
    private String fieldTypeName;

}
