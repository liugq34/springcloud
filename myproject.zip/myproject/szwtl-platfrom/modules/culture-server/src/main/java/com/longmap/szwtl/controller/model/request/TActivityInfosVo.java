package com.longmap.szwtl.controller.model.request;

import com.longmap.szwtl.common.pojo.TagObj;
import com.longmap.szwtl.common.validator.DateFormatByPattern;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author luor
 * @date created in 15:25 2019/7/23
 * @description
 */
@Data
@ApiModel("添加活动model")
public class TActivityInfosVo implements Serializable {

    /**
     * 主键ID(新增不填)
     */
    @ApiModelProperty("主键ID(新增不填)")
    private String activityId;

    /**
     * 审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)
     */
    @ApiModelProperty("审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)，传入 1，2")
    private Integer auditStatus;

    /**
     * 原图
     */
    @ApiModelProperty("原图")
    private String picture;

    /**
     * 横图  13:7
     */
    @ApiModelProperty("横图 13:7")
    private String pictureHorizontal;

    /**
     * 竖图  5:7
     */
    @ApiModelProperty("竖图 5:7")
    private String pictureVertical;

    /**
     * 活动名称
     */
    @ApiModelProperty("活动名称")
    @NotBlank(message = "活动名称不能为空")
    private String activityName;

    /**
     * 活动类型
     */
    @ApiModelProperty("活动类型")
    private Integer activityType;

    /**
     * 活动类别
     */
    @ApiModelProperty("活动类别")
    private Integer activityClass;

    /**
     * 企业id
     */
    @ApiModelProperty("企业id")
    private String enterpriseId;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    private String storeId;

    /**
     * 场馆名称
     */
    @ApiModelProperty("场馆名称")
    private String storeName;

    /**
     * 活动地点
     */
    private String address;

    /**
     * 经度
     */
    @ApiModelProperty("经度")
    private String longitude;

    /**
     * 维度
     */
    @ApiModelProperty("维度")
    private String latitude;

    /**
     * 年份
     */
    @ApiModelProperty("年份")
    private String years;

    /**
     * 月份
     */
    @ApiModelProperty("月份")
    private String months;

    /**
     * 开始日期(格式:yyyy-MM-dd)
     */
    @ApiModelProperty("开始日期")
    private String beginDate;

    /**
     * 结束日期(格式:yyyy-MM-dd)
     */
    @ApiModelProperty("结束日期")
    private String endDate;

    /**
     * 开始时间(格式:HH:mm)
     */
    @ApiModelProperty("开始时间")
    private String beginTime;

    /**
     * 结束时间(格式:HH:mm)
     */
    @ApiModelProperty("结束时间")
    private String endTime;

    /**
     * 是否需要预定0.不需要 1.需要
     */
    @ApiModelProperty("是否需要预定0.不需要 1.需要")
    private Integer reserveStatus;

    /**
     * 一次性允许最大预定人数
     */
    @ApiModelProperty("一次性允许最大预定人数")
    private Integer reserveMax;

    /**
     * 预定日期(格式:yyyy-MM-dd)
     */
    @ApiModelProperty("预定日期(格式:yyyy-MM-dd)")
    private String reserveBedate;

    /**
     * 预定日期(格式:yyyy-MM-dd)
     */
    @ApiModelProperty("预定日期(格式:yyyy-MM-dd)")
    private String reserveEndate;

    /**
     * 预定时间(格式:HH:mm)
     */
    @ApiModelProperty("预定时间(格式:HH:mm)")
    private String reserveBetime;

    /**
     * 预定时间(格式:HH:mm)
     */
    @ApiModelProperty("预定时间(格式:HH:mm)")
    private String reserveEntime;

    /**
     * 时间说明
     */
    @ApiModelProperty("时间说明")
    private String timeNotes;

    /**
     * 预定类型
     */
    @ApiModelProperty("预定类型")
    private Integer appointType;

    /**
     * 剩余门票数量
     */
    @ApiModelProperty("剩余门票数量")
    private Integer ticketRemainder;

    /**
     * 门票价格
     */
    @ApiModelProperty("门票价格")
    private BigDecimal ticketFee;

    /**
     * 预订提示
     */
    @ApiModelProperty("预订提示")
    private String ticketTips;

    /**
     * 主办方
     */
    @ApiModelProperty("主办方")
    private String sponsor;

    /**
     * 承办方
     */
    @ApiModelProperty("承办方")
    private String organizer;

    /**
     * 联系人
     */
    @ApiModelProperty("联系人")
    private String linkman;

    /**
     * 联系方式
     */
    @ApiModelProperty("联系方式")
    private String phone;

    /**
     * 联系email
     */
    @ApiModelProperty("联系email")
    private String email;

    /**
     * 活动简述
     */
    @ApiModelProperty("活动简述")
    private String activityTitle;

    /**
     * 温馨提示
     */
    @ApiModelProperty("温馨提示")
    private String warmPoint;

    /**
     * 参与方式
     */
    @ApiModelProperty("参与方式")
    private Integer joinType;

    /**
     * 备注
     */
    @ApiModelProperty("备注")
    private String remark;

    /**
     * 允许取件方式，支持多种选择，（订单只能选取一个）1.自取 2.邮寄 3.ALL
     */
    @ApiModelProperty("允许取件方式，支持多种选择，（订单只能选取一个）1.自取 2.邮寄 3.ALL")
    private Integer accessMode;

    /**
     * 用于取票方式的自取，填写取票地址
     */
    @ApiModelProperty("用于取票方式的自取，填写取票地址")
    private String accessModeAddress;

    /**
     * 活动来源
     */
    @ApiModelProperty("活动来源")
    private Integer source;

    /**
     * 活动详情
     */
    @ApiModelProperty("活动详情")
    private String introduce;

    /**
     * 省编码
     */
    @ApiModelProperty("省编码")
    private String provinceId;

    /**
     * 市编码
     */
    @ApiModelProperty("市编码")
    private String cityId;

    /**
     * 区域编码
     */
    @ApiModelProperty("区域编码")
    private String districtId;

    /**
     * 省名称
     */
    @ApiModelProperty("省名称")
    private String provinceName;

    /**
     * 市名称
     */
    @ApiModelProperty("市名称")
    private String cityName;

    /**
     * 区域名称
     */
    @ApiModelProperty("区域名称")
    private String districtName;

    /**
     * 街道编号
     */
    @ApiModelProperty("街道编号")
    private String subDistrictId;

    /**
     * 街道名称
     */
    @ApiModelProperty("街道名称")
    private String subDistrictName;

    /**
     * 标签tag
     */
    @ApiModelProperty("标签tags")
    private List<TagObj> tags;

    /**
     * 活动影视类型，1.公益 2.商业
     */
    @ApiModelProperty("标签tags")
    private Integer moviestype;

    /**
     * T_ACTIVITY_INFOS
     */
    private static final long serialVersionUID = 1L;
}
