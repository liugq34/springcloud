package com.longmap.szwtl.controller.model.request;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import springfox.documentation.annotations.ApiIgnore;

import java.io.Serializable;
import java.util.Date;

/**
 * @author luor
 * @date created in 10:22 2019/8/29
 * @description
 */
@Data
@ApiModel("下拉列表展示请求参数")
public class TVenueInfoForTabRequest implements Serializable {

    /**
     * 审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)
     */
    @ApiModelProperty("审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)")
    private Integer auditStatus;

    /**
     * 场馆名称
     */
    @ApiModelProperty("场馆名称, 模糊查询")
    private String venueName;

    /**
     * 区域编号
     */
    @ApiModelProperty("区域编号,划分区域查询")
    private String districtId;

   @ApiModelProperty(hidden = true)
    private Integer bit; //标记是哪个congtroller 调用

}
