package com.longmap.szwtl.controller;

import com.github.pagehelper.PageInfo;
import com.longmap.szwtl.common.response.IPageList;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.vo.SysUser;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Created by oushaohui on 2019/7/24 9:48
 * @description
 **/
@RestController
public class IndexController {
    @RequestMapping("/index")
    @ResponseBody
    public ResponseResult index() {
        List<String> stringLsit = new ArrayList<String>();
        stringLsit.add("张三丰");
        stringLsit.add("朱元璋");
        stringLsit.add("袁天罡");
        stringLsit.add("张道陵");
        stringLsit.add("张无忌");
        stringLsit.add("素还真");
        stringLsit.add("叶小钗");

        PageInfo<SysUser> pageInfo = new PageInfo<SysUser>();
        pageInfo.setPageNum(1);
        pageInfo.setPages(99);
        pageInfo.setPageSize(50);

        List<SysUser> sysUserList = new ArrayList<SysUser>();
        SysUser a = new SysUser();
        a.setRealname("张三丰");
        sysUserList.add(a);
        SysUser b = new SysUser();
        b.setRealname("张道陵");
        sysUserList.add(b);
        pageInfo.setList(sysUserList);

        return new ResponseResult(ResponseStatus.SUCCESS.getStatus(), new IPageList<SysUser>(pageInfo));
//        return new ResponseResult(ResponseStatus.ERROR.getStatus(), ResponseStatus.ERROR.getMessage());
    }
}
