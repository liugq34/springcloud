package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel("活动信息分页")
public class TActivitInfoPage implements Serializable {

    @ApiModelProperty("排序方式(1:默认; 2:即将开始; 3:即将结束; 4:最新发布; 5:收藏最高) ,不用于智能热门推荐")
    private Integer sequence = 1;

    @ApiModelProperty("页码(默认:1)")
    private Integer pageNum = 1;

    @ApiModelProperty("每页数量(默认:8)")
    private Integer pageSize = 8;

}
