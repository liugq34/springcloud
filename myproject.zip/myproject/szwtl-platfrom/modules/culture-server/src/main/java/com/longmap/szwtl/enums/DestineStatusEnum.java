package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 18:00 2019/7/26
 * @descriptioni
 */
public enum DestineStatusEnum {

    NOT_RESERVE(0,"未预约"),
    IS_RESERVE(1,"已预约"),
    IS_RESERVE_CUSTOM(2,"自定义合并预定"),
    ;

    private Integer code;
    private String message;

    DestineStatusEnum(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
