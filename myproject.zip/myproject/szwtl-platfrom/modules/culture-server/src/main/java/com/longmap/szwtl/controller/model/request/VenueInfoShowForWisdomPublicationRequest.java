package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 10:05 2019/9/3
 * @description 智慧刊物列表展示请求参数
 */
@ApiModel("智慧刊物列表展示请求参数")
@Data
public class VenueInfoShowForWisdomPublicationRequest implements Serializable {

    /**
     * 场馆类型
     */
    @ApiModelProperty("场馆类型")
    private Integer venueType;

    /**
     * 场馆类别
     */
    @ApiModelProperty("场馆类别")
    private Integer venueClass;

    /**
     * 场馆名称
     */
    @ApiModelProperty("场馆名称,模糊查询")
    private String venueName;

    /**
     * 项目编号
     */
    @ApiModelProperty("项目编号，模糊查询")
    private String sportItemCode;

    /**
     * 项目名称
     */
    @ApiModelProperty("项目名称，模糊查询")
    private String sportItemName;

    /**
     * 区域编号
     */
    @ApiModelProperty("区域编号")
    private String districtId;

    @ApiModelProperty(hidden = true)
    private Integer visitType; //访问方式 1.游客 2.登入者
}
