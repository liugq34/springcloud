package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author luor
 * @date created in 16:25 2019/8/16
 * @description
 */
@Data
@ApiModel("场馆活动室状态变更参数")
public class TFieldStatusRequest implements Serializable {

    /**
     * 场馆活动室主键ID
     */
    @ApiModelProperty("场馆活动室主键ID")
    private String fieldId;

    /**
     * 活动室状态 1.正常 2.禁止
     */
    @ApiModelProperty("活动室状态 1.正常、 2.禁止 ==>选择填写")
    private Integer fieldStatus;

    /**
     * 活动室状态 1.手动审核 2.自动审核
     */
    @ApiModelProperty("活动室状态 1.手动审核 2.自动审核 ==> 选择填写")
    private Integer auditType;
}
