package com.longmap.szwtl.controller.model.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author luor
 * @date created in 20:19 2019/8/30
 * @description
 */
@Data
@ApiModel("封装指定场馆项目的日期分组")
public class TVenueGoodInfoByUseDateResponse implements Serializable {

    /**
     * 使用日期
     */
    @ApiModelProperty("使用日期")
    private Long useDate;

    @ApiModelProperty("封装展示商品信息")
    List<TVenueGoodInfoForSpaceShowResponse> tVenueGoodInfoShowResponseList;

}
