package com.longmap.szwtl.enums;

/**
 * @author luor
 * @date created in 14:03 2019/7/23
 * @descriptioni
 */
public enum ActivityStatus {

    UP_STATUS(0,"正常"),
    DOWN_STATUS(1,"下架"),
    ;

    private Integer code;
    private String mesaage;

    ActivityStatus(Integer code, String mesaage) {
        this.code = code;
        this.mesaage = mesaage;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMesaage() {
        return mesaage;
    }

    public void setMesaage(String mesaage) {
        this.mesaage = mesaage;
    }
}
