
package com.longmap.szwtl.config;

import com.longmap.szwtl.service.SysLogInfoService;
import com.longmap.szwtl.util.JsonUtils;
import com.longmap.szwtl.vo.SysLogInfo;
import io.swagger.annotations.ApiOperation;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

@Aspect
@Component
public class LogAspect {
    private final static Logger logger = LoggerFactory.getLogger(LogAspect.class);
    @Autowired
    private SysLogInfoService sysLogInfoService;

    @Pointcut("@annotation(io.swagger.annotations.ApiOperation)")
    public void pointcut() { }

    @Around("pointcut()")
    public Object around(ProceedingJoinPoint point) throws Throwable {
        Object result = null;
        long beginTime = System.currentTimeMillis();
        Object[] args = point.getArgs();
        Class<?>[] argTypes = new Class[point.getArgs().length];
        for (int i = 0; i < args.length; i++) {
                argTypes[i] = args[i].getClass();
        }
        Method method = null;
       // try {
            method = point.getTarget().getClass()
                    .getMethod(point.getSignature().getName(), argTypes);
       /* } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (SecurityException e) {
            e.printStackTrace();
        }*/
        ApiOperation apiOperation = method.getAnnotation(ApiOperation.class);
        //try {
            result = point.proceed();
        /*} catch (Throwable e) {
            e.printStackTrace();
        }*/
        long time = System.currentTimeMillis() - beginTime;
        saveLog(point, time,apiOperation.value());
        return result;
    }

    private void saveLog(JoinPoint joinPoint, long time,String methodName) {
        ServletRequestAttributes attribute = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        HttpServletRequest request = attribute.getRequest();
        if(request.getRequestURI().contains("get")){
            return;
        }
        SysLogInfo sysLogInfo = new SysLogInfo();
        sysLogInfo.setCreateUser("11111111");
        sysLogInfo.setMethodName(methodName);
        sysLogInfo.setReqIp(request.getRemoteAddr());
        sysLogInfo.setReqMode(request.getMethod());
        sysLogInfo.setReqParams(JsonUtils.deserializer(joinPoint.getArgs()));
        sysLogInfo.setReqUrl(request.getRequestURI());
        sysLogInfo.setRunTime(time);
        sysLogInfoService.add(sysLogInfo);
    }

}

