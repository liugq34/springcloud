package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author luor
 * @date created in 19:51 2019/8/23
 * @description 表状态修改
 */
@Data
@ApiModel("场馆预定信息模板删除状态请求参数")
public class TVenueroomTemplateStatusRequest implements Serializable {
    /**
     * 模板号
     */
    @ApiModelProperty("模板号")
    private String tempId;

    /**
     * 删除状态
     */
    @ApiModelProperty("删除状态 0.未删除 1.删除")
    private Integer delFlag;
}
