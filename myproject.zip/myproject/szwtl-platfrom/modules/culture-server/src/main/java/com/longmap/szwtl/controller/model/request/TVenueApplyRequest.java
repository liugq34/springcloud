package com.longmap.szwtl.controller.model.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
@Data
@ApiModel("新增,修改申请model")
public class TVenueApplyRequest implements Serializable {

    /**
     * ID(新增不填)
     */
    @ApiModelProperty("ID(新增不填)")
    private String id;

    /**
     * 场馆ID
     */
    @ApiModelProperty("场馆ID")
    @NotBlank(message = "场馆ID不能为空")
    private String venueId;

    /**
     * 活动室ID
     */
    @ApiModelProperty("活动室ID")
    @NotBlank(message = "活动室ID不能为空")
    private String fieldId;

    /**
     * 预订信息ID
     */
    @ApiModelProperty("预订信息ID")
    @NotBlank(message = "预订信息ID不能为空")
    private String destineId;

    /**
     * 申请人名称
     */
    @ApiModelProperty("申请人名称")
    @NotBlank(message = "申请人名称不能为空")
    private String applyName;

    /**
     * 申请人联系方式
     */
    @ApiModelProperty("申请人联系方式")
    @NotBlank(message = "申请人联系方式不能为空")
    private String applyPhone;

    /**
     * 场地用途
     */
    @ApiModelProperty("场地用途(1:排练; 2:演出, 3:比赛; 4:沙龙; 5:讲座; 6:其他文化活动)")
    private Integer siteUse;

    /**
     * 申请说明
     */
    @ApiModelProperty("申请说明")
    private String description;


    /**
     * 申请类型(1:单个申请; 2:自定义申请)
     */
    @ApiModelProperty("申请类型(1:单个申请; 2:自定义申请)")
    private Integer applyType;

    /**
     * 申请来源(1:门户; 2:微信; 3:小程序)
     */
    @ApiModelProperty("申请来源(1:门户; 2:微信; 3:小程序)")
    private Integer applySource;
}
