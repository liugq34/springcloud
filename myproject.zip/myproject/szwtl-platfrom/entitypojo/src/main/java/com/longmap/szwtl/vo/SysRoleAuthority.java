package com.longmap.szwtl.vo;

import java.io.Serializable;
import lombok.Data;

/**
 * @author yaohw
 * 角色-操作权限 关联表实体类
 */
@Data
public class SysRoleAuthority implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 权限ID
     */
    private String authorityId;

    /**
     * 角色ID
     */
    private String roleId;

    /**
     * SYS_ROLE_AUTHORITY
     */
    private static final long serialVersionUID = 1L;
}