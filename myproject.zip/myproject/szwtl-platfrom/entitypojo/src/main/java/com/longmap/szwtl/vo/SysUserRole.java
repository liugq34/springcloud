package com.longmap.szwtl.vo;

import java.io.Serializable;
import lombok.Data;

/**
 * 用户-角色 关联
 * @author yaohw
 */
@Data
public class SysUserRole implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 用户ID
     */
    private String userId;

    /**
     * 角色ID
     */
    private String roleId;

    /**
     * USERPLAT.SYS_USER_ROLE
     */
    private static final long serialVersionUID = 1L;
}