package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 景点关联图片
 * @author chensx
 */
@Data
public class TravelAttractionsImg implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    private Long b06id;
    /**
     * 与景区（点）介绍表关联ID
     */
    private String guid;
    /**
     * 图片中文描述
     */
    private String b06001;
    /**
     * 备注
     */
    private String b06003;
    /**
     * 创建时间
     */
    private Date createtime;
    /**
     * 状态
     */
    private String status;
    /**
     * 排序
     */
    private Integer sortnum;
    /**
     * 图片路径
     */
    private String b06002img;

    public String getB06002img() {
        if(!StringUtils.isEmpty(b06002img)){
            if(b06002img.indexOf(TravelDomain.DOMAINURL)!=0){
                b06002img = TravelDomain.DOMAINURL + b06002img;
            }
        }
        return  b06002img;
    }
}
