package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class TSysCodeItems implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 名称
     */
    private String sysCodeName;

    /**
     * 父级id
     */
    private String parentId;

    /**
     * 系统数字字典主表id
     */
    private String sysCodeId;

    /**
     * 添加子项（0.不添加，1.添加）
     */
    private Long isAddChild;

    /**
     * 排序
     */
    private String sortNum;

    /**
     * 备注信息
     */
    private String remark;

    /**
     * 记录
     */
    private String record;

    /**
     * 级别
     */
    private BigDecimal levels;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新时间
     */
    private Date modifiedTime;

    /**
     * 删除状态 0正常 1已删除
     */
    private Long delFlag;

    /**
     * T_SYS_CODE_ITEMS
     */
    private static final long serialVersionUID = 1L;
}