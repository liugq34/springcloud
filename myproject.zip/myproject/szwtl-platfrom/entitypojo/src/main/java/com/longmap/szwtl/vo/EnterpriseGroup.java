package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class EnterpriseGroup implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 企业名称
     */
    private String enterpriseName;

    /**
     * 法人姓名
     */
    private String legalEntityName;

    /**
     * 法人联系方式
     */
    private String legalEntityContacts;

    /**
     * 法人身份证号码
     */
    private String legalEntityIdentityCard;

    /**
     * 统一社会信用代码
     */
    private String unifiedSocialCreditCode;

    /**
     * 企业联系方式
     */
    private String contacts;

    /**
     * 省编码
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编码
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编码
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 联系地址
     */
    private String address;

    /**
     * 企业LOGO
     */
    private String logo;

    /**
     * 企业邮箱
     */
    private String email;

    /**
     * 描述
     */
    private String description;

    /**
     * 审核状态（1：未审核  2：未通过 3：已通过 ）
     */
    private Short auditStatus;

    /**
     * 状态(1：正常  2：冻结 ）
     */
    private Short status;

    /**
     * 删除状态 0正常 1已删除
     */
    private Long delFlag;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新人
     */
    private String updateByUser;

    /**
     * 更新时间
     */
    private Date modifiedTime;

    /**
     * 街道ID
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 经办人姓名
     */
    private String operatorName;

    /**
     * 经办人手机号
     */
    private String operatorContacts;

    /**
     * 经办人身份证号
     */
    private String operatorEntityIdentityCard;

    /**
     * 审核记录列表
     */
    private List<AuditLog> auditLogList;

    /**
     * USERPLAT.T_ENTERPRISE_GROUP
     */
    private static final long serialVersionUID = 1L;
}