package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class TVenueSpaceNo implements Serializable {
    /**
     * 主键ID
     */
    private String venueSpaceNoId;

    /**
     * 场号编号 1 2 3 ，展示 1号场 2号场 3号场
     */
    private Long venueSpaceNoName;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 场馆项目ID
     */
    private String venueSportitemId;

    /**
     * 场馆场地ID
     */
    private String venueSpaceId;

    /**
     * 场馆场地名称
     */
    private String venueSpaceName;

    /**
     * 运动项目编号
     */
    private String sportItemCode;

    /**
     * 运行同时预定人数
     */
    private Integer maxReservePeople;

    /**
     * 状态 1.正常 2.禁止
     */
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    private Integer delFlag;

    /**
     * 创建人ID
     */
    private String createByUser;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 修改时间
     */
    private Date modifiedTime;

    /**
     * 场号名称
     */
    private String venueSpaceNoSign;

    /**
     * 场号编号
     */
    private String venueSpaceNoCode;

    /**
     * SZWTL.T_VENUE_SPACE_NO
     */
    private static final long serialVersionUID = 1L;
}