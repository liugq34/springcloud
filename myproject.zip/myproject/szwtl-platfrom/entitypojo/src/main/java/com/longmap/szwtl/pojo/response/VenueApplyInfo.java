package com.longmap.szwtl.pojo.response;

import com.longmap.szwtl.vo.TVenueDestine;
import lombok.Data;

import java.util.List;

/**
 * @author luor
 * @date created in 17:11 2019/8/19
 * @description
 */
@Data
public class VenueApplyInfo {


    /**
     * 原图
     */
    private String picture;

    /**
     * 竖图  5:7
     */
    private String pictureVertical;

    /**
     * 横图  13:7
     */
    private String pictureHorizontal;

    /**
     * 活动室名称
     */
    private String fieldName;

    /**
     * 场馆名称
     */
    private String venueName;

    /**
     * 场馆联系方式
     */
    private String phone;
}
