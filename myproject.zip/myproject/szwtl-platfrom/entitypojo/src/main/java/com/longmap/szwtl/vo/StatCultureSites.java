package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class StatCultureSites implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 类型
     */
    private Long type;

    /**
     * 名称
     */
    private String name;

    /**
     * 年份
     */
    private Long year;

    /**
     * 单位数量（个）
     */
    private BigDecimal unitnum;

    /**
     * 场地数量（个）
     */
    private BigDecimal sitenum;

    /**
     * 场地面积m2
     */
    private BigDecimal sitearea;

    /**
     * 建筑面积m2
     */
    private BigDecimal buildingarea;

    /**
     * 用地面积m2
     */
    private BigDecimal landarea;

    /**
     * 设施面积m2
     */
    private BigDecimal facilityarea;

    /**
     * DATAPLAT.STAT_CULTURE_SITES
     */
    private static final long serialVersionUID = 1L;
}