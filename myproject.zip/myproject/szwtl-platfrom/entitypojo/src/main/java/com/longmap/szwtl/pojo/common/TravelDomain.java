package com.longmap.szwtl.pojo.common;

/**
 * 旅游图片存放地址
 * @author chensx
 */
public class TravelDomain {
    /**
     * 深圳旅游网地址
     */
    public static final String DOMAINURL = "https://www.shenzhentour.com";
}
