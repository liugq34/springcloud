package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TActivityRelationshipTag implements Serializable {
    /**
     * 企业标签关系表ID
     */
    private String relationshipId;

    /**
     * 标签ID
     */
    private String tagId;

    /**
     * 活动ID
     */
    private String activityinfoId;

    /**
     * 删除状态(0:正常; 1:已删除)
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 标签名称
     */
    private String tagName;

    /**
     * SZWTL.T_ACTIVITY_RELATIONSHIP_TAG
     */
    private static final long serialVersionUID = 1L;
}