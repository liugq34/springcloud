package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 当天行程景点信息
 * @author chensx
 */
@Data
public class TravelLineTripView implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行程景点ID
     */
    private String id;
    /**
     * 行程ID
     */
    private String dayTripId;
    /**
     * 行程景点名称
     */
    private String name;
    /**
     * 建议
     */
    private String tips;
    /**
     * 第一张图片路径
     */
    private String firstImageUrl;
    /**
     * 第二张图片路径
     */
    private String secondImageUrl;
    /**
     * 第三张图片路径
     */
    private String threeImageUrl;
    /**
     * 介绍
     */
    private String intrduce;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 经度
     */
    private String latitude;
    /**
     * 创建时间
     */
    private Date createTime;

    public String getFirstImageUrl() {
        if(!StringUtils.isEmpty(firstImageUrl)){
            if(firstImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                firstImageUrl = TravelDomain.DOMAINURL + firstImageUrl;
            }
        }
        return  firstImageUrl;
    }

    public String getSecondImageUrl() {
        if(!StringUtils.isEmpty(secondImageUrl)){
            if(secondImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                secondImageUrl = TravelDomain.DOMAINURL + secondImageUrl;
            }
        }
        return  secondImageUrl;
    }

    public String getThreeImageUrl() {
        if(!StringUtils.isEmpty(threeImageUrl)){
            if(threeImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                threeImageUrl = TravelDomain.DOMAINURL + threeImageUrl;
            }
        }
        return  threeImageUrl;
    }

}
