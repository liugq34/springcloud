package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 线路基础信息
 * @author chensx
 */
@Data
public class TravelLineBase implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 线路ID
     */
    private String id;
    /**
     * 线路名称
     */
    private String name;
    /**
     * 线路天数
     */
    private String lineDays;
    /**
     * 人均消费
     */
    private Integer perConsumption;
    /**
     * 第一张图片
     */
    private String firstImageUrl;
    /**
     * 第二张图片
     */
    private String secondImageUrl;
    /**
     * 第三张图片
     */
    private String threeImageUrl;
    /**
     * 线路类别（6:滨海休闲之旅,7:主题公园之旅,8:都市风情之旅,9:历史人文之旅,10:创意科技之旅）
     */
    private Integer lineType;
    /**
     * 线路分类（1：深圳游，2：周边游,3：邮轮游，4：海上看深圳 ，5：主题游）
     */
    private String type;
    /**
     * 线路描述
     */
    private String comments;
    /**
     * 首页推荐,不推荐：0；推荐：1；
     */
    private Integer recommend;
    /**
     * 导航栏推荐 ,不推荐：0；推荐：1；
     */
    private Integer topRecommend;
    /**
     * 创建时间
     */
    private Date createTime;

    public String getFirstImageUrl() {
        if(!StringUtils.isEmpty(firstImageUrl)){
            if(firstImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                firstImageUrl = TravelDomain.DOMAINURL + firstImageUrl;
            }
        }
        return  firstImageUrl;
    }

    public String getSecondImageUrl() {
        if(!StringUtils.isEmpty(secondImageUrl)){
            if(secondImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                secondImageUrl = TravelDomain.DOMAINURL + secondImageUrl;
            }
        }
        return  secondImageUrl;
    }

    public String getThreeImageUrl() {
        if(!StringUtils.isEmpty(threeImageUrl)){
            if(threeImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                threeImageUrl = TravelDomain.DOMAINURL + threeImageUrl;
            }
        }
        return  threeImageUrl;
    }

}
