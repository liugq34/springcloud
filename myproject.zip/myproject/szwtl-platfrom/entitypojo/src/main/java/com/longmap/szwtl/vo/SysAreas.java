package com.longmap.szwtl.vo;

import java.io.Serializable;
import lombok.Data;

/**
 *
 * 区域实体类
 * @author yaohw
 */
@Data
public class SysAreas implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 区域类型 1:province/省/自治区/直辖市;2:city/地区(省下面的地级市);3:district/县/市(县级市)/区. 比如广东省的area_type 1,深圳市的area_type 2,福田区是深圳市的一个区,所以福田区的area_type = 3
     * 4，街道
     */
    private Long type;

    /**
     * 地域名称,如深圳市
     */
    private String name;

    /**
     * 父ID
     */
    private String parentId;

    /**
     * SYS_AREAS
     */
    private static final long serialVersionUID = 1L;
}