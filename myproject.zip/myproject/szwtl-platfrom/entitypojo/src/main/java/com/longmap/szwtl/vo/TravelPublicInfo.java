package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 资讯、新闻
 * 深圳概貌，景点攻略:pid=35，美食攻略:pid=410，交通攻略:pid=411，
 * @author chensx
 */
@Data
public class TravelPublicInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 资讯、新闻ID
     */
    private String guid;
    /**
     * 资讯、新闻类型
     */
    private Integer pid;
    /**
     * 标题
     */
    private String title;
    /**
     * 描述
     */
    private String describe;
    /**
     * 内容
     */
    private String context;
    /**
     * 来源
     */
    private String source;
    /**
     * 作者
     */
    private String author;
    /**
     * 图片路径
     */
    private String imageurl;
    /**
     * 上传时间
     */
    private Date pubtime;
    /**
     * 推荐 0:请选择；1:否；2:是；
     */
    private Integer recommend;

    public String getImageurl() {
        if(!StringUtils.isEmpty(imageurl)){
            if(imageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                imageurl = TravelDomain.DOMAINURL + imageurl;
            }
        }
        return  imageurl;
    }

}
