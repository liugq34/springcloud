package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TAuditLog implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 对应业务表ID
     */
    private String businessId;

    /**
     * 创建人ID
     */
    private String createUserId;

    /**
     * 创建人
     */
    private String createUserName;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;

    /**
     * 回退原因
     */
    private String rollbackReason;

    /**
     * 修改建议
     */
    private String modifiedSuggest;

    /**
     * 审核状态（1.未提交 2：待审核  3：未通过 4：已通过 ）
     */
    private Long auditStatus;

    /**
     * SZWTL.T_AUDIT_LOG
     */
    private static final long serialVersionUID = 1L;
}