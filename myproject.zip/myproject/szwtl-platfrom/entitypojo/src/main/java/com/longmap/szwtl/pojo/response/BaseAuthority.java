package com.longmap.szwtl.pojo.response;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Created by oushaohui on 2019/8/9 11:21
 * @description
 **/
@Data
public class BaseAuthority implements Serializable {
    /**
     * 权限
     */
    private String authority;
}
