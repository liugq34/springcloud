package com.longmap.szwtl.pojo.response;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Created by oushaohui on 2019/8/5 10:54
 * @description
 **/
@Data
public class BaseUserInfoAuthority implements Serializable {
    /**
     * 权限
     */
    private String authority;
}
