package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class ClubApply implements Serializable {
    /**
     * 主键id
     */
    private String id;

    /**
     * 登录账号
     */
    private String account;

    /**
     * 真实姓名
     */
    private String realname;

    /**
     * 社团ID
     */
    private String clubId;

    /**
     *  用户状态（1 申请加入，2.未加入，3 退团）
     */
    private Integer status;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 用户id
     */
    private String userId;


    /**
     * 社团名称
     */
    private String clubName;


    /**
     * CLUBPLAT.T_CLUB_APPLY
     */
    private static final long serialVersionUID = 1L;
}