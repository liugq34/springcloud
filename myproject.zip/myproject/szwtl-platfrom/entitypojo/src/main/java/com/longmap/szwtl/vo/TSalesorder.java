package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TSalesorder implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 订单编号
     */
    private String orderNo;

    /**
     * 买家ID
     */
    private String buyerId;

    /**
     * 买家昵称
     */
    private String buyerNick;

    /**
     * 买家手机号
     */
    private String buyerContact;

    /**
     * 买家备注
     */
    private String buyerMemo;

    /**
     * 卖家留言
     */
    private String buyerMessage;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 场馆ID
     */
    private String storeId;

    /**
     * 卖家ID
     */
    private String sellerId;

    /**
     * 卖家昵称
     */
    private String sellerNick;

    /**
     * 卖家备注
     */
    private String sellerMemo;

    /**
     * 购买数量
     */
    private Long num;

    /**
     * 退款状态：（1：申请退款；2：卖家确认退款；3：已退款；4：卖家拒绝退款；5：取消）
     */
    private Long refundStatus;

    /**
     * 订单状态：（1：未支付；2：已支付；3：已核销；4：取消）
     */
    private Long orderStatus;

    /**
     * 订单总金额
     */
    private BigDecimal totalFee;

    /**
     * 订单类型：（1 文化场馆，2 体育场馆，3 企业标签，4 活动，5 演出，6 展览，7 影视，8 阅读，9 体育，10 旅游，11 角色）
     */
    private Long orderType;

    /**
     * 支付方式：（1：支付宝；2：微信）
     */
    private Long paymentType;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 删除状态 0正常 1已删除
     */
    private Long delFlag;

    /**
     * 省编码
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编码
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编码
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道编码
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 取件方式(1.自取 2.邮寄 3.ALL)
     */
    private Long accessMode;

    /**
     * 订单过期状态(0:未过期; 1:已过期)
     */
    private Long orderExpired;

    /**
     * 用户删除(0:未删除; 1:已删除)
     */
    private Long userDelete;

    /**
     * 场馆名称
     */
    private String storeName;

    /**
     * 申请来源(1:门户; 2:微信; 3:小程序)
     */
    private Long orderSource;

    /**
     * 邮寄地址
     */
    private String mailAddress;

    /**
     * 邮寄收件人
     */
    private String mailRecipient;

    /**
     * 收件人电话
     */
    private String mailPhone;

    /**
     * 卖家联系方式
     */
    private String sellerPhone;

    /**
     * 申请id
     */
    private String applyId;

    /**
     * ORDERPLAT.T_SALESORDER
     */
    private static final long serialVersionUID = 1L;


    /** 非数据库字段 **/
    private List<TSalesorderItem> tSalesorderItem;
}