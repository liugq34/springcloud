package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class AuditLog implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 对应业务表ID
     */
    private String businessId;

    /**
     * 创建人ID
     */
    private String createUserId;

    /**
     * 创建人名称
     */
    private String createUserName;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 回退原因
     */
    private String rollbackReason;

    /**
     * 修改建议
     */
    private String modifiedSuggest;

    /**
     * 审核状态（1：待提交 2：待审核  3：未通过 4：已通过 ）
     */
    private Long auditStatus;

    /**
     * USERPLAT.T_AUDIT_LOG
     */
    private static final long serialVersionUID = 1L;
}