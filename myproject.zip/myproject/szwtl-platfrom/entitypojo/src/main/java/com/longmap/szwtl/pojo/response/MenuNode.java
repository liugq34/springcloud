package com.longmap.szwtl.pojo.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 * 权限菜单节点
 * @author: yaohw
 * @create: 2019-07-22 09:53
 **/
@Data
@AllArgsConstructor
@NoArgsConstructor
@ApiModel
public class MenuNode implements Serializable {

    private static final long serialVersionUID = -526324944915280489L;

    /**
     * 主键ID
     */
    @ApiModelProperty(value = "主键ID")
    private String id;

    /**
     * 父ID
     */
    @ApiModelProperty(value = "父ID，一级菜单时为空")
    private String parentId;

    /**
     * 菜单名称
     */
    @ApiModelProperty(value = "菜单名称")
    private String name;

    /**
     * 菜单跳转地址
     */
    @ApiModelProperty(value = "菜单跳转地址")
    private String url;

    /**
     * 菜单类型(0:一级菜单; 1:子菜单)
     */
    @ApiModelProperty(value = "菜单类型(0:一级菜单; 1:子菜单)")
    private Long menuType;

    /**
     * 菜单排序
     */
    @ApiModelProperty(value = "菜单排序")
    private Long sortNo;

    /**
     * 菜单图标
     */
    @ApiModelProperty(value = "菜单图标")
    private String icon;

    /**
     * 是否隐藏: 0否,1是
     */
    @ApiModelProperty(value = "是否隐藏: 0否,1是")
    private Short forbidden;

    /**
     * 描述
     */
    @ApiModelProperty(value = "描述")
    private String description;


    /**
     * 子菜单
     */
    @ApiModelProperty(value = "子菜单")
    private List<MenuNode> children;

}
