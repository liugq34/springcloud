package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TVenueComment implements Serializable {
    /**
     * 主键ID
     */
    private String commentid;

    /**
     * 场馆ID
     */
    private String venueid;

    /**
     * 用户ID
     */
    private String userid;

    /**
     * 用户名称
     */
    private String username;

    /**
     * 是否匿名（0.否1.是）
     */
    private Long anonymous;

    /**
     * 评价（1.一星 2.二星 ...5.五星）
     */
    private Long starrating;

    /**
     * 场馆评论内容
     */
    private String content;

    /**
     * 图片路径
     */
    private String picturepath;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * SZWTL.T_VENUE_COMMENT
     */
    private static final long serialVersionUID = 1L;
}