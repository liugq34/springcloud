package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 美食
 * @author chensx
 */
@Data
public class TravelFood implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 美食ID
     */
    private String id;
    /**
     * 名称
     */
    private String name;
    /**
     * 联系电话
     */
    private String phone;
    /**
     * 成立时间
     */
    private String setuptime;
    /**
     * 总部地点
     */
    private String address;
    /**
     * 人均消费
     */
    private Integer perConsumption;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 纬度
     */
    private String latitude;
    /**
     * 介绍
     */
    private String introduce;
    /**
     * 详情页大图
     */
    private String pageImageUrl;
    /**
     * 列表页图片
     */
    private String listImageUrl;
    /**
     * 提供的食物类别
     */
    private String foodType;
    /**
     * 所属商圈
     */
    private String hotShoppingDistrict;
    /**
     * 所在区
     */
    private String area_;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 移动端列表小图
     */
    private String mobileimg;

    public String getListImageUrl() {
        if(!StringUtils.isEmpty(listImageUrl)){
            if(listImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                listImageUrl = TravelDomain.DOMAINURL + listImageUrl;
            }
        }
        return  listImageUrl;
    }

    public String getPageImageUrl() {
        if(!StringUtils.isEmpty(pageImageUrl)){
            if(pageImageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                pageImageUrl = TravelDomain.DOMAINURL + pageImageUrl;
            }
        }
        return  pageImageUrl;
    }

    public String getMobileimg() {
        if(!StringUtils.isEmpty(mobileimg)){
            if(mobileimg.indexOf(TravelDomain.DOMAINURL)!=0){
                mobileimg = TravelDomain.DOMAINURL + mobileimg;
            }

        }
        return  mobileimg;
    }

}
