package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 酒店关联图片信息
 * @author chensx
 */
@Data
public class TravelHotelImg implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * ID
     */
    private String d06id;
    /**
     * 编号
     */
    private String d06001;
    /**
     * 图片
     */
    private String d06002Img;
    /**
     * 状态
     */
    private String status;
    /**
     * 创建时间
     */
    private Date createtime;

    public String getD06002Img() {
        if(!StringUtils.isEmpty(d06002Img)){
            if(d06002Img.indexOf(TravelDomain.DOMAINURL)!=0){
                d06002Img = TravelDomain.DOMAINURL + d06002Img;
            }
        }
        return  d06002Img;
    }
}
