package com.longmap.szwtl.pojo.request;

import com.longmap.szwtl.common.validator.IsPhone;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * 企业审核结果短信通知
 * @author: yaohw
 * @create: 2019-08-09 15:21
 **/
@Data
public class EnterpriseAuditRequest {



    @ApiModelProperty("初始账号")
    @NotBlank(message = "账号不可为空")
    @IsPhone(message = "账号须为手机号")
    String account;

    @ApiModelProperty("初始密码，审核通过时不能为空")
    String password;

    @ApiModelProperty("审核不通过原因，审核不通过时不能为空")
    String msg;

    @ApiModelProperty("类型，0:成功，1:失败")
    @NotNull(message = "类型不可为空")
    int type;
}
