package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 线路-行程信息
 * @author chensx
 */
@Data
public class TravelLineDayTrip implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行程ID
     */
    private String id;
    /**
     * 线路ID
     */
    private String lineId;
    /**
     * 第几天
     */
    private Integer inday;
    /**
     * 当天行程介绍
     */
    private String introduce;
    /**
     * 交通线路
     */
    private String transportLine;
    /**
     * 旅行小贴士
     */
    private String tips;
    //吃
    /**
     * 吃-第一张图片路径
     */
    private String mealFirstImageurl;
    /**
     * 吃-第二张图片路径
     */
    private String mealSecondImageurl;
    /**
     * 吃-第三张图片路径
     */
    private String mealThreeImageurl;
    //住
    /**
     * 住-第一张图片路径
     */
    private String hotelFirstImageurl;
    /**
     * 住-第二张图片路径
     */
    private String hotelSecondImageurl;
    /**
     * 住-第三张图片路径
     */
    private String hotelThreeImageurl;
    /**
     * 推荐状态,不推荐：1；推荐：2；
     */
    private String recommend;
    /**
     * 添加日期
     */
    private Date createTime;

    public String getMealFirstImageurl() {
        if(!StringUtils.isEmpty(mealFirstImageurl)){
            if(mealFirstImageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                mealFirstImageurl = TravelDomain.DOMAINURL + mealFirstImageurl;
            }
        }
        return  mealFirstImageurl;
    }

    public String getMealSecondImageurl() {
        if(!StringUtils.isEmpty(mealSecondImageurl)){
            if(mealSecondImageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                mealSecondImageurl = TravelDomain.DOMAINURL + mealSecondImageurl;
            }
        }
        return  mealSecondImageurl;
    }

    public String getMealThreeImageurl() {
        if(!StringUtils.isEmpty(mealThreeImageurl)){
            if(mealThreeImageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                mealThreeImageurl = TravelDomain.DOMAINURL + mealThreeImageurl;
            }
        }
        return  mealThreeImageurl;
    }

    public String getHotelFirstImageurl() {
        if(!StringUtils.isEmpty(hotelFirstImageurl)){
            if(hotelFirstImageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                hotelFirstImageurl = TravelDomain.DOMAINURL + hotelFirstImageurl;
            }
        }
        return  hotelFirstImageurl;
    }

    public String getHotelSecondImageurl() {
        if(!StringUtils.isEmpty(hotelSecondImageurl)){
            if(hotelSecondImageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                hotelSecondImageurl = TravelDomain.DOMAINURL + hotelSecondImageurl;
            }
        }
        return  hotelSecondImageurl;
    }

    public String getHotelThreeImageurl() {
        if(!StringUtils.isEmpty(hotelThreeImageurl)){
            if(hotelThreeImageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                hotelThreeImageurl = TravelDomain.DOMAINURL + hotelThreeImageurl;
            }
        }
        return  hotelThreeImageurl;
    }

}
