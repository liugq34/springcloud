package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TSalesorderItem implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 订单ID
     */
    private String orderId;

    /**
     * 订单编号
     */
    private String orderNo;

    /**
     * 商品ID
     */
    private String productId;

    /**
     * 商品名称
     */
    private String productName;

    /**
     * 商品编码
     */
    private String productNumber;

    /**
     * 购买数量
     */
    private Long num;

    /**
     * 订单总金额
     */
    private BigDecimal price;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 更新时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 删除状态 0正常 1已删除
     */
    private Long delFlag;

    /**
     * 开始日期
     */
    private String beginDate;

    /**
     * 开始时间
     */
    private String beginTime;

    /**
     * 结束时间
     */
    private String endTime;

    /**
     * 参加状态(0:为未参加; 1:已参加)
     */
    private Long participateStatus;

    /**
     * 地点
     */
    private String address;

    /**
     * 原图
     */
    private String picture;

    /**
     * 横图  13:7
     */
    private String pictureHorizontal;

    /**
     * 结束日期
     */
    private String endDate;

    /**
     * 竖图  5:7
     */
    private String pictureVertical;

    /**
     * ORDERPLAT.T_SALESORDER_ITEM
     */
    private static final long serialVersionUID = 1L;
}