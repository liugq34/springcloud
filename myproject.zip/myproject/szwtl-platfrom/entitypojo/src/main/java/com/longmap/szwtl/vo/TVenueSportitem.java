package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class TVenueSportitem implements Serializable {
    /**
     * 主键ID
     */
    private String venueSportitemId;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 运动项目code
     */
    private String sportItemCode;

    /**
     * 运动项目名称
     */
    private String sportItemName;

    /**
     * 使用类型 1、按步长，2、按早晚，3、按天
     */
    private Integer occupyType;

    /**
     * 步长
     */
    private BigDecimal step;

    /**
     * 提前退订时间，单位：小时
     */
    private Long refundtime;

    /**
     * 室内or室外
     */
    private Integer inoutdoor;

    /**
     * 是否有灯光
     */
    private Integer havelight;

    /**
     * 地板类型
     */
    private String floorType;

    /**
     * 工作日开始营业时间
     */
    private Long weekdayStartTime;

    /**
     * 工作日结束营业时间
     */
    private Long weekdayEndTime;

    /**
     * 周末开始营业时间
     */
    private Long weekendStartTime;

    /**
     * 周末结束营业时间
     */
    private Long weekendEndTime;

    /**
     * 状态 1.正常 2.禁止
     */
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    private Integer delFlag;

    /**
     * 创建人ID
     */
    private String createByUser;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 修改人ID
     */
    private String updateByUser;

    /**
     * 修改时间
     */
    private Date modifiedTime;

    /**
     * SZWTL.T_VENUE_SPORTITEM
     */
    private static final long serialVersionUID = 1L;

    /**
     * 非数据数据
     */
   //工作日开始营业时间
    private String weekdayStartTimeStr;
   //工作日结束营业时间
    private String weekdayEndTimeStr;
   //周末开始营业时间
    private String weekendStartTimeStr;
    //周末结束营业时间
    private String weekendEndTimeStr;
    //封装项目下的场地
    private List<TVenueSpace> tVenueSpaceList;
}