package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TVenueroomTemplate implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 场馆id
     */
    private String venueId;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 创建人id
     */
    private String createByUser;

    /**
     * 模板号
     */
    private String tempId;

    /**
     * 模板名称
     */
    private String tempName;

    /**
     * 开始时间
     */
    private Long startTime;

    /**
     * 结束时间
     */
    private Long endTime;

    /**
     * 价格
     */
    private BigDecimal fee;

    /**
     * 删除状态
     */
    private Integer delFlag;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * SZWTL.T_VENUEROOM_TEMPLATE
     */
    private static final long serialVersionUID = 1L;

    /**非数据库字段*/
    private List<TVenueroomTemplate> tVenueroomTemplateList;
    /**开始时间*/
    private String startTimeStr;
    /**结束时间*/
    private String endTimeStr;
}