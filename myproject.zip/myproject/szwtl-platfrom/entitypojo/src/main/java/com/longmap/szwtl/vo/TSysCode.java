package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class TSysCode implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 名称
     */
    private String sysCodeName;

    /**
     * 添加子项（0.不添加，1.添加）
     */
    private Long addChild;

    /**
     * 排序
     */
    private String sortNum;

    /**
     * 备注信息
     */
    private String remark;

    /**
     * 记录
     */
    private String record;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 修改时间
     */
    private Date modifiedTime;

    /**
     * 删除(0:正常; 1:删除)
     */
    private Long delFlag;

    /**
     * T_SYS_CODE
     */
    private static final long serialVersionUID = 1L;
}