package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class TranReceipt implements Serializable {
    /**
     * 主键id
     */
    private String id;

    /**
     * 公文id
     */
    private String tranid;

    /**
     * 用户id
     */
    private String userId;

    /**
     * 姓名
     */
    private String userName;

    /**
     * 企业名称
     */
    private String enterpriseName;

    /**
     * 手机号
     */
    private String mobile;

    /**
     * 添加时间
     */
    private Date createTime;

    /**
     * 回执内容
     */
    private String returnContent;

    /**
     * USERPLAT.T_TRAN_RECEIPT
     */
    private static final long serialVersionUID = 1L;
}