package com.longmap.szwtl.pojo.response;

import lombok.Data;

import java.io.Serializable;

/**
 * @author Created by oushaohui on 2019/8/9 11:12
 * @description
 **/
@Data
public class BaseRole implements Serializable {
    /*
     * 角色编码
     */
    private String roleCode;
}
