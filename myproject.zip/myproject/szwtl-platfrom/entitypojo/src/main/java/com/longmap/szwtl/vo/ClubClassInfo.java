package com.longmap.szwtl.vo;

import java.io.Serializable;
import lombok.Data;

@Data
public class ClubClassInfo implements Serializable {
    /**
     * 主键表
     */
    private String id;

    /**
     * 社团id
     */
    private String clubId;

    /**
     * 社团类别ID（1.音乐、2.舞蹈、3.戏剧、4.曲艺、5.书画、6.影视、7.志愿者、8.健身、9.其他）
     */
    private String clubClassId;

    /**
     * 社团类型名称
     */
    private String clubClassName;

    /**
     * CLUBPLAT.T_CLUB_CLASS_INFO
     */
    private static final long serialVersionUID = 1L;
}