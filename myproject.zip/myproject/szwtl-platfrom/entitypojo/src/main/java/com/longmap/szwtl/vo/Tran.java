package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class Tran implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 标题
     */
    private String title;

    /**
     * 是否包含回执（0：不需要,1：需要,默认0）
     */
    private Integer isNeedReturn;

    /**
     * 是否需要发送短信提醒（0：不需要,1：需要,默认0）
     */
    private Integer isNeedSms;

    /**
     * 发布状态（0：未发布,1：已发布,2：已撤回,默认0）
     */
    private Integer pubStatus;

    /**
     * 内容
     */
    private String content;

    /**
     * 附件上传路径
     */
    private String fileUrl;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 创建人id
     */
    private String createUserId;

    /**
     * 创建时间
     */
    private Date createTime;

    /**
     * 发布人
     */
    private String pubUser;

    /**
     * 发布人id
     */
    private String pubUserId;

    /**
     * 发布时间
     */
    private Date pubTime;

    /**
     * 修改人id
     */
    private String updateUserId;

    /**
     * 修改时间
     */
    private Date updateTime;

    /**
     * 删除标志（0正常,1删除）
     */
    private Long delFlg;

    /**
     * USERPLAT.T_TRAN
     */
    private static final long serialVersionUID = 1L;
}