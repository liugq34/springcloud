package com.longmap.szwtl.pojo.request;

import com.longmap.szwtl.common.validator.IsPhone;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * @author luor
 * @date created in 16:29 2019/8/14
 * @description 场馆审核短信提醒
 */
@Data
public class VenueAuditRequest implements Serializable {

    @ApiModelProperty("初始账号")
    @NotBlank(message = "账号不可为空")
    @IsPhone(message = "账号须为手机号")
    String account;

    @ApiModelProperty("场馆名称")
    @NotNull(message = "场馆名称不可为空")
    String venueName;

    @ApiModelProperty("回退原因，审核不通过时不能为空")
    String rollbackReason;

    @ApiModelProperty("修改建议，审核不通过时不能为空")
    String modifiedSuggest;

    @ApiModelProperty("类型，0:成功，1:失败")
    @NotNull(message = "类型不可为空")
    int type;
}
