package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

/**
 * 数据字典
 * @author yaohw
 */
@Data
public class DataDict implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 父级ID
     */
    private String parentId;

    /**
     * 名称
     */
    private String dataName;

    /**
     * 类型：1 文化场馆，2 体育场馆，3 企业标签，4 活动，5 演出，6 展览，7 影视，8 阅读，9 体育，10 旅游, 11 角色
     * 其中4-10为消费用户标签
     */
    private Long dataType;

    /**
     * 数据编码
     */
    private String dataCode;

    /**
     * 删除：1是，0否
     */
    private Short deleted;

    /**
     * 备注
     */
    private String remark;

    /**
     * 创建时间
     */
    @JsonIgnore
    private Date createdTime;

    /**
     * 修改时间
     */
    @JsonIgnore
    private Date modifiedTime;

    /**
     * 类型，适用于不使用ID保存的业务场景
     */
    private Long type;

    /**
     * USERPLAT.T_DATA_DICT
     */
    private static final long serialVersionUID = 1L;
}