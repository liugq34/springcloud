package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class TranSendOperation implements Serializable {
    /**
     * 主键id
     */
    private String id;

    /**
     * 公文id
     */
    private String tranid;

    /**
     * 公文标题
     */
    private String title;

    /**
     * 企业id/区街道id
     */
    private String enterpriseId;

    /**
     * 企业名称/区街道名称
     */
    private String enterpriseName;

    /**
     * 场馆id
     */
    private String venueId;

    /**
     * 场馆名称
     */
    private String venueName;

    /**
     * 接收用户id
     */
    private String receiveUserId;

    /**
     * 接收用户姓名
     */
    private String receiveUserName;

    /**
     * 设定时限
     */
    private Integer setTimeLimit;

    /**
     * 是否自动发短信催办（0：否,1：是 默认0）
     */
    private Integer autoSmsUrge;

    /**
     * 用户查看公文时间
     */
    private Date selTranTime;

    /**
     * 用户查看公文状态（0：否,1：是 默认0）
     */
    private Integer selTranStatus;

    /**
     * 发送公文时间
     */
    private Date sendTranTime;

    /**
     * 发布公文用户姓名
     */
    private String sendTranName;

    /**
     * 发布公文用户id
     */
    private String sendTranUserid;

    /**
     * 通知短信id
     */
    private String messageId;

    /**
     * 催办短信id
     */
    private String urgeMessageId;

    /**
     * 是否需要回执（0：否,1：是 默认0）
     */
    private Integer isNeedReturn;

    /**
     * 企业是否签收（0：未签收,1：已签收 默认0）
     */
    private Integer isNeedSign;

    /**
     * 是否已发过催办短信（0：否,1：是 默认0）
     */
    private Integer isUrgeSms;

    /**
     * 规定回执时间
     */
    private Date setReceTime;

    /**
     * USERPLAT.T_TRAN_SEND_OPERATION
     */
    private static final long serialVersionUID = 1L;
}