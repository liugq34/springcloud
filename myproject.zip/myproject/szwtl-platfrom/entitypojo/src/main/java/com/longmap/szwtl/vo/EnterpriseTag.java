package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class EnterpriseTag implements Serializable {
    /**
     * 企业标签关系表ID
     */
    private String relationshipId;

    /**
     * 标签ID
     */
    private String tagId;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 删除：1是，0否
     */
    private Short deleted;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 修改时间
     */
    private Date modifiedTime;

    /**
     * USERPLAT.T_ENTERPRISE_RELATIONSHIP_TAG
     */
    private static final long serialVersionUID = 1L;
}