package com.longmap.szwtl.vo;

import java.io.Serializable;
import lombok.Data;

/**
 * @author yaohw
 * 角色-权限菜单 关联表实体类
 */

@Data
public class SysRolePermission implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 角色ID
     */
    private String roleId;

    /**
     * 权限ID
     */
    private String permissionId;

    /**
     * SYS_ROLE_PERMISSION
     */
    private static final long serialVersionUID = 1L;
}