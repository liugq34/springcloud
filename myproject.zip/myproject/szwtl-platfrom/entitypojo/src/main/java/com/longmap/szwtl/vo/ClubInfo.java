package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class ClubInfo implements Serializable {
    /**
     * 社团id
     */
    private String clubId;

    /**
     * 招募时间
     */
    private String recruitmentTime;

    /**
     * 招募人数
     */
    private Integer recruitment;

    /**
     * 社团名称
     */
    private String clubName;


    /**
     * 社团类别ID（1.音乐、2.舞蹈、3.戏剧、4.曲艺、5.书画、6.影视、7.志愿者、8.健身、9.其他）
     */
    private String clubClassId;

    /**
     * 社团类型名称
     */
    private String clubClassName;
    /**
     * 团队所在地
     */
    private String address;

    /**
     * 成立时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date establishmentTime;

    /**
     * 社团介绍
     */
    private String communityIntroduction;

    /**
     * 招募要求
     */
    private String recruitmentRequirements;

    /**
     * 留言
     */
    private String leavingMessage;

    /**
     * 社团风采
     */
    private String communityElegance;

    /**
     * 发布人
     */
    private String publisher;

    /**
     * 发布时间
     */
    private String releaseTime;

    /**
     * 招募状态（1.最新发布、2.人气、 3.招募中 4.满员）
     */
    private Integer status;

    /**
     * 热度
     */
    private Integer hotNum;

    /**
     * 推荐热门
     */
    private Integer recommandType;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 修改时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 企业ID
     */
    private String enterpriseid;

    /**
     * 省编码
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编码
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编码
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道编码
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 经度
     */
    private String longitude;

    /**
     * 纬度
     */
    private String latitude;

    /**
     * 审核人
     */
    private String auditman;

    /**
     * 审核时间
     */
    private String auditTime;

    /**
     * 审核状态
     */
    private Integer auditStatus;

    /**
     * 审核备注
     */
    private String auditRemark;

    /**
     * 创建人ID
     */
    private String createUserId;

    /**
     * 联系人手机
     */
    private String phone;

    /**
     * 横图（滚动图片）
     */
    private String pictureHorizontal;

    /**
     * 竖图（滚动图片）
     */
    private String pictureVertical;

    /**
     * 原图（滚动图片）
     */
    private String picture;

    /**
     * 已招募人数
     */
    private Integer alreadyNum;


    /**
     * 用户状态（1 申请加入，2.未加入，3 退团）
     */
    private Integer userStatus;


    /**
     * 上下架状态(0:正常; 1:下架)
     */
    private Integer clubStatus;

    /**
     * 用户id
     */
    private String userId;


    /**
     * CLUBPLAT.T_CLUB_INFO
     */
    private static final long serialVersionUID = 1L;
}