package com.longmap.szwtl.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Data
public class InterfacePersonInfo implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 姓名
     */
    private String personName;

    /**
     * 手机
     */
    private String mobile;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 证件类型
     */
    private Long idType;

    /**
     * 证件号
     */
    private String idCard;

    /**
     * 所属行业
     */
    private String tradeType;

    /**
     * 工作单位
     */
    private String workUnit;

    /**
     * 单位性质
     */
    private String unitNature;

    /**
     * 地址
     */
    private String address;

    /**
     * 使用目的
     */
    private String purposeUse;

    /**
     * 1：待提交 2：待审核  4：未通过 3：已通过
     */
    private Long auditStatus;

    /**
     * 冻结状态：0正常，1冻结
     */
    private Long frozenStatus;

    /**
     * 添加时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 添加人
     */
    private String createUser;

    /**
     * 修改时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 修改人
     */
    private String updateUser;

    /**
     * 删除标志（0正常,1删除）
     */
    private Long delFlg;

    /**
     * INTERFACE_PERSON_INFO
     */
    private static final long serialVersionUID = 1L;

    /**
     * 用户id
     */
    private String userId;
    /**
     * 登录账号
     */
    private String account;

    /**
     * 密码
     */
    private String password;

    private Long status;
}