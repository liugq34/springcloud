package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 景点信息
 * @author chensx
 */
@Data
public class TravelAttractions implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 景点ID
     */
    private String guid;
    /**
     * 景点编号
     */
    private String b01id;
    /**
     * 旅游景区（点）中文名
     */
    private String b01001;
    /**
     * 旅游景区（点）英文名
     */
    private String b01002;
    /**
     * 旅游景区（点）级别
     */
    private String b01003;
    /**
     旅游景区（点）类别
     */
    private String b01004;
    /**
     * 旅游景区（点）介绍
     */
    private String b01005;
    /**
     * 景区门票
     */
    private String b01006;
    /**
     * 景区标志（Logo）
     */
    private String b01007Img;
    /**
     * 景区宣传语
     */
    private String b01008;
    /**
     * 宣传视频
     */
    private String b01009;
    /**
     * 景区管理机构名称
     */
    private String b01010;
    /**
     * 景区管理机构地址（中）
     */
    private String b01017;
    /**
     * 景区管理机构地址（英）
     */
    private String b01018;
    /**
     * 邮政编码
     */
    private String b01019;
    /**
     * 游客服务中心电话
     */
    private String b01020;
    /**
     * 投诉电话
     */
    private String b01021;
    /**
     * 公安报警电话
     */
    private String b01022;
    /**
     * 紧急救援电话（医疗救助）
     */
    private String b01023;
    /**
     * 传真
     */
    private String b01024;
    /**
     * 电子邮箱
     */
    private String b01025;
    /**
     * 景区网址
     */
    private String b01026;
    /**
     * 网上订票
     */
    private String b01027;
    /** 预定电话
     */
    private String b01028;
    /**
     * 预定传真
     */
    private String b01029;
    /**
     * 电子信箱
     */
    private String b01030;
    /**
     * 支付方式
     */
    private String b01031;
    /**
     * 信息员
     */
    private String b01032;
    /**
     * 信息员联系电话
     */
    private String b01033;
    /**
     * 信息员电子邮箱
     */
    private String b01034;
    /**
     * 旅游景区景点所在地
     */
    private String b01035;
    /**
     * 交通情况
     */
    private String b01036;
    /**
     * 景区外观图片
     */
    private String b01037Img;
    /**
     * 用户ID
     */
    private String userId;
    /**
     * 旅游景点类型
     */
    private String tourType;
    /**
     * 排序
     */
    private String zsort;
    /**
     * 推荐
     */
    private String zrecommended;
    private String vtime;
    /**
     * 儿童价格
     */
    private String childPrice;
    /**
     * 成人价格
     */
    private String manPrice;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 纬度
     */
    private String latitude;
    /**
     * 首页推荐 0:不推荐，1：推荐
     */
    private Integer sy_recommend;
    /**
     * 景区导语
     */
    private String jqdy;
    /**
     * 最佳旅游时间
     */
    private String optimumtime;
    /**
     * 旺季
     */
    private String busySeason;
    /**
     * 淡季
     */
    private String lowSeason;
    /**
     * 景区电话
     */
    private String jqPhone;
    /**
     * 建议浏览时间
     */
    private String browsetime;
    /**
     * 门票价格
     */
    private String price;
    /**
     * 景区语音导语
     */
    private String voiceword;
    /**
     * 所在区
     */
    private String area_;
    /**
     * 适合人群
     */
    private String shrq;
    /**
     * 景点特色
     */
    private String tsinfo;
    /**
     * 移动端图片
     */
    private String mobileimg;
    /**
     * 创建时间
     */
    private Date createTime;

    public String getB01007Img() {
        if(!StringUtils.isEmpty(b01007Img)){
            if(b01007Img.indexOf(TravelDomain.DOMAINURL)!=0){
                b01007Img = TravelDomain.DOMAINURL + b01007Img;
            }
        }
        return  b01007Img;
    }

    public String getB01037Img() {
        if(!StringUtils.isEmpty(b01037Img)){
            if(b01037Img.indexOf(TravelDomain.DOMAINURL)!=0){
                b01037Img = TravelDomain.DOMAINURL + b01037Img;
            }
        }
        return  b01037Img;
    }

    public String getMobileimg() {
        if(!StringUtils.isEmpty(mobileimg)){
            if(mobileimg.indexOf(TravelDomain.DOMAINURL)!=0){
                mobileimg = TravelDomain.DOMAINURL + mobileimg;
            }
        }
        return  mobileimg;
    }

}
