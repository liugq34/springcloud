package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;

/**
 * 酒店信息
 * @author chensx
 */
@Data
public class TravelHotel implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 酒店ID
     */
    private String guid;
    /**
     * 酒店名称（中文）
     */
    private String d01001;
    /**
     * 酒店名称（英文）
     */
    private String d01002;
    /**
     * 酒店星级
     */
    private String d01003;
    /**
     * 酒店类型
     */
    private String d01004;
    /**
     * 酒店宣传语
     */
    private String d01006;
    /**
     * 酒店简介
     */
    private String d01007;

    /**
     * 酒店管理公司
     */
    private String d01010;
    /**
     * 建筑设计和装修设计主题说明
     */
    private String d01011;
    /**
     * 酒店注册名称
     */
    private String d01012;
    /**
     * 酒店地址（中文）
     */
    private String d01022;
    /**
     * 酒店地址（英文）
     */
    private String d01023;
    /**
     * 邮政编码
     */
    private String d01024;
    /**
     * 星评联系人
     */
    private String d01025;
    /**
     * 联系电话
     */
    private String d01026;
    /**
     * 传真
     */
    private String d01027;
    /**
     * 电子信箱
     */
    private String d01028;
    /**
     * 销售部电话
     */
    private String d01029;
    /**
     * 预定电话
     */
    private String d01030;
    /**
     * 投诉电话
     */
    private String d01031;
    /**
     * 预定传真
     */
    private String d01032;
    /**
     * 咨询预定电子信箱
     */
    private String d01033;
    /**
     * 电子信箱
     */
    private String d01034;
    /**
     * 企业网址
     */
    private String d01035;
    /**
     * 网上订房
     */
    private String d01036;
    /**
     * 支付方式
     */
    private String d01037;
    /**
     * 信息员
     */
    private String d01038;
    /**
     * 信息员联系电话
     */
    private String d01039;
    /**
     * 信息员电子邮箱
     */
    private String d01040;
    /**
     * 酒店所在地
     */
    private String d01041;
    /**
     * 交通情况
     */
    private String d01042;
    /**
     * 周边信息
     */
    private String d01043;
    /**
     * 投资总额
     */
    private String d01044;
    /**
     * 所有制性质
     */
    private String d01045;
    /**
     * 网站分类
     */
    private String d01046;

    /**
     * 酒店中文名称
     */
    private String d01048;
    /**
     * 酒店LOGO
     */
    private String d01005Img;
    /**
     * 酒店外景图片
     */
    private String d01047Img;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 经度
     */
    private String latitude;
    /**
     * 经度
     */
    private String price;
    /**
     * 所在区
     */
    private String area_;
    /**
     * 住宿环境
     */
    private String zshj;
    /**
     * 好吃的
     */
    private String goodFood;
    /**
     * 好玩的
     */
    private String nicePlay;

    public String getD01005Img() {
        if(!StringUtils.isEmpty(d01005Img)){
            if(d01005Img.indexOf(TravelDomain.DOMAINURL)!=0){
                d01005Img = TravelDomain.DOMAINURL + d01005Img;
            }
        }
        return  d01005Img;
    }

    public String getD01047Img() {
        if(!StringUtils.isEmpty(d01047Img)){
            if(d01047Img.indexOf(TravelDomain.DOMAINURL)!=0){
                d01047Img = TravelDomain.DOMAINURL + d01047Img;
            }
        }
        return  d01047Img;
    }

}
