package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class StatCompositeSites implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 名称
     */
    private Long type;

    /**
     * null
     */
    private String name;

    /**
     * null
     */
    private String areas;

    /**
     * 年份
     */
    private Long year;

    /**
     * 单位数量（个）
     */
    private BigDecimal unitnum;

    /**
     * 场地数量（个）
     */
    private BigDecimal sitenum;

    /**
     * 场地面积m2
     */
    private BigDecimal sitearea;

    /**
     * 建筑面积m2
     */
    private BigDecimal buildingarea;

    /**
     * 用地面积m2
     */
    private BigDecimal landarea;

    /**
     * 设施面积m2
     */
    private BigDecimal facilityarea;

    /**
     * DATAPLAT.STAT_COMPOSITE_SITES
     */
    private static final long serialVersionUID = 1L;
}