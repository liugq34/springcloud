package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Data;

@Data
public class TVenueGoodInfo implements Serializable {
    /**
     * 主键ID
     */
    private String goodId;

    /**
     * 商品名称
     */
    private String goodName;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 场馆项目ID
     */
    private String venueItemId;

    /**
     * 场馆场地ID
     */
    private String venueGroundtypeId;

    /**
     * 场馆场号ID
     */
    private String venueSpaceNoId;

    /**
     * 运动项目编号
     */
    private String sportItemCode;

    /**
     * 使用日期
     */
    private Long useDate;

    /**
     * 开始时间
     */
    private Long startTime;

    /**
     * 结束时间
     */
    private Long endTime;

    /**
     * 售价
     */
    private BigDecimal saleprice;

    /**
     * 总数量
     */
    private Long totalnum;

    /**
     * 可预订数量
     */
    private Long remainnum;

    /**
     * 已预定数量
     */
    private Long reservednum;

    /**
     * 状态 1.正常 2.禁止
     */
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    private Integer delflag;

    /**
     * 场馆场号编号用于排序
     */
    private Long venueSpaceNoName;

    /**
     * SZWTL.T_VENUE_GOOD_INFO
     */
    private static final long serialVersionUID = 1L;

    /**日期格式非数据库字段*/
    //使用日期
    private String  useDateStr;

    //开始时间
    private String startTimeStr;

    //结束时间
    private String endTimeStr;
}