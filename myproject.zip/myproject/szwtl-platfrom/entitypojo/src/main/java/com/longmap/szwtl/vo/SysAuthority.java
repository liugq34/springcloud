package com.longmap.szwtl.vo;

import java.io.Serializable;
import lombok.Data;

/**
 * 操作权限表实体类
 * @author yaohw
 */
@Data
public class SysAuthority implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 权限
     */
    private String authority;

    /**
     * 描述
     */
    private String description;

    /**
     * SYS_AUTHORITY
     */
    private static final long serialVersionUID = 1L;
}