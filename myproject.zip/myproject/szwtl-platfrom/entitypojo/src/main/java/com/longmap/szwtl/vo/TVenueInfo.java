package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TVenueInfo implements Serializable {
    /**
     * 主键ID
     */
    private String venueId;

    /**
     * 原图
     */
    private String picture;

    /**
     * 场馆名称
     */
    private String venueName;

    /**
     * 场馆类型
     */
    private Integer venueType;

    /**
     * 场馆类别
     */
    private Integer venueClass;

    /**
     * 所在区
     */
    private String location;

    /**
     * 街道
     */
    private String street;

    /**
     * 场馆地点
     */
    private String address;

    /**
     * 经度
     */
    private String longitude;

    /**
     * 维度
     */
    private String latitude;

    /**
     * 联系人
     */
    private String linkman;

    /**
     * 联系方式
     */
    private String phone;

    /**
     * 温馨提示
     */
    private String warmPoint;

    /**
     * 开放时间
     */
    private String openTime;

    /**
     * 备注
     */
    private String remark;

    /**
     * 场馆状态(0:正常; 1:下架)
     */
    private Integer status;

    /**
     * 预订提示
     */
    private String ticketTips;

    /**
     * 热度
     */
    private Integer hotNum;

    /**
     * 推荐热门
     */
    private Integer recommandType;

    /**
     * 审核人
     */
    private String auditman;

    /**
     * 审核时间
     */
    private String auditTime;

    /**
     * 审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)
     */
    private Integer auditStatus;

    /**
     * 删除状态(0:正常; 1:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 是否可以预定（0.不可预定，1.可以预定）
     */
    private Integer reserveStatus;

    /**
     * 省编号
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编号
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编号
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道编号
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 审核备注
     */
    private String auditRemark;

    /**
     * 创建人ID
     */
    private String createUserId;

    /**
     * 横图  13:7
     */
    private String pictureHorizontal;

    /**
     * 机构代码
     */
    private String institutionCode;

    /**
     * 单位性质
     */
    private String unitNature;

    /**
     * 法人代表
     */
    private String legalRepresentative;

    /**
     * 法人代表联系电话
     */
    private String legalRepresentativePhone;

    /**
     * 负责人
     */
    private String personInCharge;

    /**
     * 负责人电话
     */
    private String personInChargePhone;

    /**
     * 主管部门
     */
    private Integer competentDepartmentType;

    /**
     * 设施面积
     */
    private String facilityArea;

    /**
     * 建成时间
     */
    private String completionTime;

    /**
     * 用地面积
     */
    private String landArea;

    /**
     * 建筑面积
     */
    private String builtUpArea;

    /**
     * 场地面积
     */
    private String siteArea;

    /**
     * 运营模式
     */
    private String operationalModel;

    /**
     * 经费来源
     */
    private String sourcesFunds;

    /**
     * 员工人数
     */
    private String employeesNum;

    /**
     * 场馆简介
     */
    private String briefIntroduction;

    /**
     * 场馆Id(用于对接)
     */
    private String venueProductNumber;

    /**
     * 是否发送， 0.未发送 1.发送
     */
    private Integer sendStatus;

    /**
     * 竖图  5:7
     */
    private String pictureVertical;

    /**
     * 场馆详情
     */
    private String introduce;

    /**
     * SZWTL.T_VENUE_INFO
     */
    private static final long serialVersionUID = 1L;

    /***非数据库字段*/
    private String storeId;
    private TVenueComment tVenueComment;
    private List<TVenueSportitem> tVenueSportitemList;
    private String sportVenueClass;

    /**用于关联项目表字段*/
    private String sportItemCode; //项目编号
    private String sportItemName; //项目名称

}