package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.longmap.szwtl.common.pojo.TagObj;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class TActivityInfo implements Serializable {
    /**
     * 主键ID
     */
    private String activityId;

    /**
     * 原图
     */
    private String picture;

    /**
     * 活动名称
     */
    private String activityName;

    /**
     * 活动类型
     */
    private Integer activityType;

    /**
     * 活动类别
     */
    private Integer activityClass;

    /**
     * 企业id
     */
    private String enterpriseId;

    /**
     * 场馆ID
     */
    private String storeId;

    /**
     * 场馆名称
     */
    private String storeName;

    /**
     * 所在区
     */
    private String location;

    /**
     * 街道
     */
    private String street;

    /**
     * 活动地点
     */
    private String address;

    /**
     * 经度
     */
    private String longitude;

    /**
     * 维度
     */
    private String latitude;

    /**
     * 年份
     */
    private String years;

    /**
     * 月份
     */
    private String months;

    /**
     * 开始日期(格式:yyyy-MM-dd)
     */
    private String beginDate;

    /**
     * 结束日期(格式:yyyy-MM-dd)
     */
    private String endDate;

    /**
     * 开始时间(格式:HH:mm)
     */
    private String beginTime;

    /**
     * 结束时间(格式:HH:mm)
     */
    private String endTime;

    /**
     * 是否需要预定0.不需要 1.需要
     */
    private Integer reserveStatus;

    /**
     * 一次性允许最大预定人数
     */
    private Integer reserveMax;

    /**
     * 预定日期(格式:yyyy-MM-dd)
     */
    private String reserveBedate;

    /**
     * 预定日期(格式:yyyy-MM-dd)
     */
    private String reserveEndate;

    /**
     * 预定时间(格式:HH:mm)
     */
    private String reserveBetime;

    /**
     * 预定时间(格式:HH:mm)
     */
    private String reserveEntime;

    /**
     * 时间说明
     */
    private String timeNotes;

    /**
     * 预定类型
     */
    private Integer appointType;

    /**
     * 剩余门票数量
     */
    private Integer ticketRemainder;

    /**
     * 已预订门票数量
     */
    private Integer ticketAppointed;

    /**
     * 门票价格
     */
    private BigDecimal ticketFee;

    /**
     * 预订提示
     */
    private String ticketTips;

    /**
     * 主办方
     */
    private String sponsor;

    /**
     * 承办方
     */
    private String organizer;

    /**
     * 联系人
     */
    private String linkman;

    /**
     * 联系方式
     */
    private String phone;

    /**
     * 活动简述
     */
    private String activityTitle;

    /**
     * 温馨提示
     */
    private String warmPoint;

    /**
     * 参与方式
     */
    private Integer joinType;

    /**
     * 备注
     */
    private String remark;

    /**
     * 活动状态(0:正常; 1:下架)
     */
    private Integer status;

    /**
     * 审核人
     */
    private String auditman;

    /**
     * 审核时间
     */
    private String auditTime;

    /**
     * 审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)
     */
    private Integer auditStatus;

    /**
     * 允许取件方式，支持多种选择，（订单只能选取一个）1.自取 2.邮寄 3.ALL
     */
    private Integer accessMode;

    /**
     * 热度
     */
    private Integer hotNum;

    /**
     * 推荐热门
     */
    private Integer recommandType;

    /**
     * 删除状态(0:正常; 1:已删除)
     */
    private Long delFlag;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 修改人
     */
    private String updateUser;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 活动来源
     */
    private Integer source;

    /**
     * 省编码
     */
    private String provinceId;

    /**
     * 市编码
     */
    private String cityId;

    /**
     * 区域编码
     */
    private String districtId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道编号
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 联系email
     */
    private String email;

    /**
     * 活动关键字
     */
    private String keywords;

    /**
     * 审核备注
     */
    private String auditRemark;

    /**
     * 创建人ID
     */
    private String createUserId;

    /**
     * 横图  13:7
     */
    private String pictureHorizontal;

    /**
     * 用于取票方式的自取，填写取票地址
     */
    private String accessModeAddress;

    /**
     * 创建人场馆ID
     */
    private String createUserVenueId;

    /**
     * 创建人场馆名称
     */
    private String createUserVenue;

    /**
     * 创建人企业ID
     */
    private String createUserEnterpriseId;

    /**
     * 创建人企业名称
     */
    private String createEnterprise;

    /**
     * 活动Id(用于对接)
     */
    private String activityProductNumber;

    /**
     * 是否发送
     */
    private Integer sendStatus;

    /**
     * 竖图  5:7
     */
    private String pictureVertical;

    /**
     * 活动影视类型，1.公益 2.商业
     */
    private Integer moviestype;

    /**
     * 活动详情
     */
    private String introduce;

    /**
     * SZWTL.T_ACTIVITY_INFO
     */
    private static final long serialVersionUID = 1L;

    /***非数据库字段*/
    private List<TActivityComment> tActivityCommentList;
    private TActivityComment tActivityComment;
    private List<TagObj> tags;
    private String beginDateGreater;
    private String beginDateLess;
    private String[] activityClasss; //活动类别 查询多条

}