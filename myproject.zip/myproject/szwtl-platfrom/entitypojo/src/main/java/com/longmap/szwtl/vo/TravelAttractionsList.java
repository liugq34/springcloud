package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;

/**
 * 景点信息
 * @author chensx
 */
@Data
public class TravelAttractionsList implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 景点ID
     */
    private String guid;
    /**
     * 旅游景区（点）中文名
     */
    private String b01001;
    /**
     * 景区外观图片
     */
    private String b01037Img;
    /**
     * 旅游景区（点）级别
     */
    private String b01003;
    /**
     * 游客服务中心电话
     */
    private String b01020;
    /**
     * 旅游景区景点所在地
     */
    private String b01035;
    /**
     * 移动端图片
     */
    private String mobileimg;
    /**
     * 所在区
     */
    private String area_;

    /**
     * 旅游景点类型
     */
    private String tourType;

    /**
     * 经度
     */
    private String longitude;

    /**
     * 纬度
     */
    private String latitude;

    /**
     * 距离
     */
    private double distance;

    public String getB01037Img() {
        if(!StringUtils.isEmpty(b01037Img)){
            if(b01037Img.indexOf(TravelDomain.DOMAINURL)!=0){
                b01037Img = TravelDomain.DOMAINURL + b01037Img;
            }
        }
        return  b01037Img;
    }

    public String getMobileimg() {
        if(!StringUtils.isEmpty(mobileimg)){
            if(mobileimg.indexOf(TravelDomain.DOMAINURL)!=0){
                mobileimg = TravelDomain.DOMAINURL + mobileimg;
            }
        }
        return  mobileimg;
    }

}
