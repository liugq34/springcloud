package com.longmap.szwtl.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

@Data
public class NewsReadRecord implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 新闻ID
     */
    private String newsId;

    /**
     * 新闻标题
     */
    private String title;

    /**
     * 类型：1文化新闻，2体育新闻，3旅游新闻
     */
    private Long type;

    /**
     * 请求终端：1PC,2android,3ios,4其他
     */
    private Long reqTerminal;

    /**
     * 请求ip
     */
    private String reqIp;

    /**
     * 添加时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 添加人
     */
    private String createUser;

    /**
     * 修改时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 修改人
     */
    private String updateUser;

    /**
     * 删除标志（0正常,1删除）
     */
    private Long delFlg;

    /**
     * NEWS_READ_RECORD
     */
    private static final long serialVersionUID = 1L;
}