package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;

/**
 * 酒店信息
 * @author chensx
 */
@Data
public class TravelHotelList implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 酒店ID
     */
    private String guid;
    /**
     * 酒店名称（中文）
     */
    private String d01001;
    /**
     * 酒店星级
     */
    private String d01003;
    /**
     * 酒店地址（中文）
     */
    private String d01022;
    /**
     * 预定电话
     */
    private String d01030;
    /**
     * 网站分类
     */
    private String d01046;
    /**
     * 酒店LOGO
     */
    private String d01005Img;
    /**
     * 酒店外景图片
     */
    private String d01047Img;
    /**
     * 经度
     */
    private String longitude; //经度
    /**
     * 经度
     */
    private String latitude; //纬度
    /**
     * 经度
     */
    private String price;  //价格
    /**
     * 所在区
     */
    private String area_;

    public String getD01005Img() {
        if(!StringUtils.isEmpty(d01005Img)){
            if(d01005Img.indexOf(TravelDomain.DOMAINURL)!=0){
                d01005Img = TravelDomain.DOMAINURL + d01005Img;
            }
        }
        return  d01005Img;
    }

    public String getD01047Img() {
        if(!StringUtils.isEmpty(d01047Img)){
            if(d01047Img.indexOf(TravelDomain.DOMAINURL)!=0){
                d01047Img = TravelDomain.DOMAINURL + d01047Img;
            }
        }
        return  d01047Img;
    }

}
