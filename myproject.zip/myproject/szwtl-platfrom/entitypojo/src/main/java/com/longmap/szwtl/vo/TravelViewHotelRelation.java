package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 周边推荐关联表
 * @author chensx
 */
@Data
public class TravelViewHotelRelation implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    private String guid;
    /**
     * 主信息id
     */
    private String pid;
    /**
     * 周边信息id
     */
    private String sid;
    /**
     * 距离,通过坐标计算
     */
    private Double distance;
    /**
     * 类型
     */
    private Integer type;
    /**
     * 创建时间
     */
    private Date createtime;

}
