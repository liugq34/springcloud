package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class SysLogInfo implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 方法名称
     */
    private String methodName;

    /**
     * 请求url
     */
    private String reqUrl;

    /**
     * 请求方式
     */
    private String reqMode;

    /**
     * 请求参数
     */
    private String reqParams;

    /**
     * 请求ip
     */
    private String reqIp;

    /**
     * 运行时间
     */
    private Long runTime;

    /**
     * 添加时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 添加人
     */
    private String createUser;

    /**
     * 修改时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 修改人
     */
    private String updateUser;

    /**
     * 删除标志（0正常,1删除）
     */
    private Long delFlg;

    /**
     * SZWTL.SYS_LOG_INFO
     */
    private static final long serialVersionUID = 1L;
}