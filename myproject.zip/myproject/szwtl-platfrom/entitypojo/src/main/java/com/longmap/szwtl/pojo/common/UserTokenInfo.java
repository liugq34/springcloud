package com.longmap.szwtl.pojo.common;

import lombok.Data;

import java.io.Serializable;

@Data
public class UserTokenInfo implements Serializable {


    public String opername;
    public String username;
    private String password;
    public String name;
    public String address;
    private Integer type;
    private String enterpriseId;
}
