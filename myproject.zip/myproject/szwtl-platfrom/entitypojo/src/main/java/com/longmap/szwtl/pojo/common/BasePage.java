package com.longmap.szwtl.pojo.common;

import lombok.Data;

import java.io.Serializable;

@Data
public class BasePage implements Serializable {


    private Integer pageSize = 10;
    private Integer pageNo = 1;

}
