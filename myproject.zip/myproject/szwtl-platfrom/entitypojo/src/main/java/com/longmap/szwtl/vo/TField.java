package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.List;

import com.longmap.szwtl.pojo.response.VenueBydateObj;
import lombok.Data;

@Data
public class TField implements Serializable {
    /**
     * 场馆活动室主键ID
     */
    private String fieldId;

    /**
     * 场馆活动室名称
     */
    private String fieldName;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 场馆名称
     */
    private String venueName;

    /**
     * 活动室介绍
     */
    private String fieldIntroduce;

    /**
     * 活动室状态 1.正常 2.禁止
     */
    private Integer fieldStatus;

    /**
     * 活动室开放时间
     */
    private String fieldOpenTime;

    /**
     * 最大容纳人数
     */
    private Long maxContainPeople;

    /**
     * 场馆活动室编号
     */
    private String fieldNum;

    /**
     * 类别ID
     */
    private Integer fieldTypeId;

    /**
     * 类别名称
     */
    private String fieldTypeName;

    /**
     * 电脑端图片
     */
    private String picturePc;

    /**
     * 手机端图片
     */
    private String pictureMc;

    /**
     * 活动室设备
     */
    private String fieldDevice;

    /**
     * 活动室功能用途
     */
    private String fieldFunction;

    /**
     * 活动室状态 1.手动审核 2.自动审核
     */
    private Integer auditType;

    /**
     * 删除 0.未删除 1.删除
     */
    private Integer delFlag;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * SZWTL.T_FIELD
     */
    private static final long serialVersionUID = 1L;

    /***非数据库字段*/
    /***天数 分组天数查询时候使用*/
    private List<VenueBydateObj> venueBydateList;
}