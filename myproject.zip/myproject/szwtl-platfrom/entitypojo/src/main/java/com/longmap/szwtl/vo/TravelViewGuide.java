package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 关联攻略
 * @author chensx
 */
@Data
public class TravelViewGuide implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * ID
     */
    private String id;
    /**
     * 父ID（关联ID）
     */
    private String foreignId;
    /**
     * 作者
     */
    private String autor;
    /**
     * 标题
     */
    private String title;
    /**
     * 内容
     */
    private String content;
    /**
     * 创建时间
     */
    private Date createtime;
    /**
     * 发布时间
     */
    private Date pubtime;
    /**
     * 攻略类型  景点攻略：view,美食攻略:food,交通攻略：traffic，旅游小贴士：traveltips
     */
    private String guideType;
    /**
     * 图片路径
     */
    private String imageUrl;
    /**
     * 简单说明
     */
    private String comment_;
    /**
     * 点击数
     */
    private Integer clickNum;

    public String getImageUrl() {
        if(!StringUtils.isEmpty(imageUrl)){
            if(imageUrl.indexOf(TravelDomain.DOMAINURL)!=0){
                imageUrl = TravelDomain.DOMAINURL + imageUrl;
            }
        }
        return  imageUrl;
    }
}
