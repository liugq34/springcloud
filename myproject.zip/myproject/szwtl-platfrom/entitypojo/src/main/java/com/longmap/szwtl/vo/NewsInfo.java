package com.longmap.szwtl.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

@Data
public class NewsInfo implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 新闻标题
     */
    private String title;

    /**
     * 类型：1文化新闻，2体育新闻，3旅游新闻
     */
    private Long type;

    /**
     * 热门新闻：1是2否
     */
    private Long isHot;

    /**
     * 原图
     */
    private String picture;
    /**
     * 横图  13:7
     */
    private String pictureHorizontal;

    /**
     * 竖图  5:7
     */
    private String pictureVertical;

    /**
     * 发布日期
     */
    @JsonFormat(pattern="yyyy-MM-dd HH:mm",timezone="GMT+8")
    private Date releaseTime;

    /**
     * 发布人
     */
    private String releaseName;

    /**
     * 新闻状态：1：待提交 2：待审核  4：未通过 3：已通过
     */
    private Long releaseStatus;

    /**
     * 上架状态：1下架，0上架
     */
    private Long putawayStatus;

    /**
     * 备注
     */
    private String remark;

    /**
     * 添加时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 添加人
     */
    private String createUser;

    /**
     * 修改时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 修改人
     */
    private String updateUser;

    /**
     * 删除标志（0正常,1删除）
     */
    private Long delFlg;

    /**
     * 内容详情
     */
    private String details;


    /**
     * 来源
     */
    private String source;

    /**
     * 点击数
     */
    private Long clickNum;

    /**
     * 置顶标志
     */
    private Long stickyPost;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 门店ID
     */
    private String storeId;


    /**
     * 省编码
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;


    /**
     * 市编码
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编码
     */
    private String districtId;
    /**
     * 区域名称
     */
    private String districtName;
    /**
     * 街道编码
     */
    private String subDistrictId;
    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 封面是否有图片或者视频文件，1无，2有
     */
    private Long isFile;

    /**
     * NEWS_INFO
     */
    private static final long serialVersionUID = 1L;

    private String releaseTimeStr;

    private boolean isToken;

}