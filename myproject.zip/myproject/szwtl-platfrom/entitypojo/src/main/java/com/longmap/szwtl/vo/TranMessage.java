package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

@Data
public class TranMessage implements Serializable {
    /**
     * 主键id
     */
    private String id;

    /**
     * 公文id
     */
    private String tranid;

    /**
     * 公文标题
     */
    private String title;

    /**
     * 发送用户id
     */
    private String sendUserId;

    /**
     * 发送用户人姓名
     */
    private String sendUserName;

    /**
     * 企业名称
     */
    private String enterpriseName;

    /**
     * 接收人id
     */
    private String receiveUserId;

    /**
     * 接收人号码
     */
    private String receiveNumber;

    /**
     * 接收人姓名
     */
    private String receiveUserName;

    /**
     * 职务
     */
    private String job;

    /**
     * 发送状态（0：未成功,1：已成功,默认1）
     */
    private Integer sendStatus;

    /**
     * 短信类型（1：通知短信,2:催办短信,3:群发短信,默认1）
     */
    private Integer smsType;

    /**
     * 添加时间
     */
    private Date createTime;

    /**
     * 短信内容
     */
    private String messageContent;

    /**
     * USERPLAT.T_TRAN_MESSAGES
     */
    private static final long serialVersionUID = 1L;
}