package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 权限菜单表实体类，不同角色显示不同菜单
 * @author yaohw
 */
@Data
public class SysPermission implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 父ID
     */
    private String parentId;

    /**
     * 菜单名称
     */
    private String name;

    /**
     * 菜单跳转地址
     */
    private String url;

    /**
     * 菜单类型(0:一级菜单; 1:子菜单)
     */
    private Long menuType;

    /**
     * 菜单排序
     */
    private Long sortNo;

    /**
     * 菜单图标
     */
    private String icon;

    /**
     * 是否隐藏: 0否,1是
     */
    private Short forbidden;

    /**
     * 描述
     */
    private String description;

    /**
     * 创建人
     */
    private String createByUser;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新人
     */
    private String updateByUser;

    /**
     * 更新时间
     */
    private Date modifiedTime;

    /**
     * 删除状态 0正常 1已删除
     */
    private Long delFlag;

    /**
     * SYS_PERMISSION
     */
    private static final long serialVersionUID = 1L;
}