package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TVenueSpace implements Serializable {
    /**
     * 主键ID
     */
    private String venueSpaceId;

    /**
     * 场馆场地名称
     */
    private String venueSpaceName;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 场馆项目ID
     */
    private String venueSportitemId;

    /**
     * 最大预定人数
     */
    private Long maxReservePerson;

    /**
     * 创建人ID
     */
    private String createByUser;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 状态 1.正常 2.禁止
     */
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    private Integer delFlag;

    /**
     * SZWTL.T_VENUE_SPACE
     */
    private static final long serialVersionUID = 1L;

    /**非数据库字段*/
    private List<TVenueSpaceNo> TVenueSpaceNoList;
}