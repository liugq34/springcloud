package com.longmap.szwtl.pojo.response;

import com.longmap.szwtl.vo.TVenueDestine;
import lombok.Data;

import java.util.List;

/**
 * @author luor
 * @date created in 17:11 2019/8/19
 * @description
 */
@Data
public class VenueBydateObj {

    private String days;

    /**活动室下的预定位置*/
    private List<TVenueDestine> tVenueDestineList;
}
