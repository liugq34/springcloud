package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.common.TravelDomain;
import lombok.Data;
import org.springframework.util.StringUtils;

import java.io.Serializable;
import java.util.Date;

/**
 * 购物
 * @author chensx
 */
@Data
public class TravelShopping implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 购物ID
     */
    private String id;
    /**
     * 购物中心名称
     */
    private String name;
    /**
     * 购物中心地址
     */
    private String address;
    /**
     * 购物中心图片路径
     */
    private String imageurl;
    /**
     * 购物中心介绍
     */
    private String introdce;
    /**
     * 乘车路线
     */
    private String busLine;
    /**
     * 首页栏推荐状态,不推荐：0；推荐：1；
     */
    private Integer recommend;
    /**
     * 购物中心类别(10:鞋履配饰;15:超市&便利店;20:专卖店;25:服饰箱包;30:综合商场;35:食品药品;)
     */
    private String shoppingType;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 纬度
     */
    private String latitude;
    /**
     * 所在区
     */
    private String area_;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 移动端列表小图
     */
    private String mobileimg;

    public String getImageurl() {
        if(!StringUtils.isEmpty(imageurl)){
            if(imageurl.indexOf(TravelDomain.DOMAINURL)!=0){
                imageurl = TravelDomain.DOMAINURL + imageurl;
            }
        }
        return  imageurl;
    }

    public String getMobileimg() {
        if(!StringUtils.isEmpty(mobileimg)){
            if(mobileimg.indexOf(TravelDomain.DOMAINURL)!=0){
                mobileimg = TravelDomain.DOMAINURL + mobileimg;
            }
        }
        return  mobileimg;
    }

}
