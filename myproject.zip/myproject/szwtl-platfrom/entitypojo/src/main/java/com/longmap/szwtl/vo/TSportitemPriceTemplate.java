package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

@Data
public class TSportitemPriceTemplate implements Serializable {
    /**
     * 主键ID
     */
    private String priceTemplateId;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 场馆项目ID
     */
    private String venueSportitemId;

    /**
     * 价格模板名称
     */
    private String priceTemplateName;

    /**
     * 工作日早上价格
     */
    private BigDecimal weekdayDayprice;

    /**
     * 工作日早上截至时间
     */
    private Long weekdayDayendTime;

    /**
     * 工作日下午价格
     */
    private BigDecimal weekdayNightprice;

    /**
     * 周末早上价格
     */
    private BigDecimal weekendDayprice;

    /**
     * 周末早上截至时间
     */
    private Long weekendDayendTime;

    /**
     * 周末下午价格
     */
    private BigDecimal weekendNightprice;

    /**
     * 创建人ID
     */
    private String createByUser;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 状态 1.正常 2.禁止
     */
    private Integer status;

    /**
     * 删除标志 0.未删除 1.删除
     */
    private Integer delFlag;

    /**
     * 场馆项目名称
     */
    private String venueSportitemName;

    /**
     * SZWTL.T_SPORTITEM_PRICE_TEMPLATE
     */
    private static final long serialVersionUID = 1L;

    /**
     * 工作日早上截至时间
     */
    private String weekdayDayendTimeStr;

    /**
     * 周末早上截至时间
     */
    private String weekendDayendTimeStr;
}