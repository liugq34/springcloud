package com.longmap.szwtl.vo;

import com.longmap.szwtl.pojo.response.BaseRole;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class SysInterfaceUser implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 登录账号
     */
    private String account;

    /**
     * 密码
     */
    private String password;

    /**
     * SSO授权密码
     */
    private String authorizedPassword;

    /**
     * 密码盐
     */
    private String salt;

    /**
     * 账号类型（1：个人 2：企业）
     */
    private Long accountType;

    /**
     * 关联ID
     */
    private String relId;

    /**
     * 状态(0：冻结 1：正常  ）
     */
    private Long status;

    /**
     * 删除状态（0，正常，1已删除）
     */
    private Long delFlag;

    /**
     * 创建人
     */
    private String createByUser;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新人
     */
    private String updateByUser;

    /**
     * 更新时间
     */
    private Date modifiedTime;

    /**
     * 旧密码
     */
    private String oldPassword;

    /**
     * 角色
     */
    private List<BaseRole> roles;

    /**
     * SYS_INTERFACE_USER
     */
    private static final long serialVersionUID = 1L;
}