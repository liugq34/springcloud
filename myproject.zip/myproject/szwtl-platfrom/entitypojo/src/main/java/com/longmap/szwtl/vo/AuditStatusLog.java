package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

@Data
public class AuditStatusLog implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 对应业务表ID
     */
    private String businessId;

    /**
     * 创建人ID
     */
    private String createUserId;

    /**
     * 创建人名称
     */
    private String createUserName;

    /**
     * 创建时间
     */
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;

    /**
     * 回退原因
     */
    private String rollbackReason;

    /**
     * 修改建议
     */
    private String modifiedSuggest;

    /**
     * 审核状态（1：待提交 2：待审核  3：未通过 4：已通过 ）
     */
    private Long auditStatus;

    /**
     * CLUBPLAT.T_AUDIT_STATUS_LOG
     */
    private static final long serialVersionUID = 1L;
}