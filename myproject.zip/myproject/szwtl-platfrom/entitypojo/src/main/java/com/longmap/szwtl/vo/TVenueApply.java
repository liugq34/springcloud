package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.longmap.szwtl.pojo.response.VenueApplyInfo;
import lombok.Data;

@Data
public class TVenueApply implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 预订信息ID
     */
    private String destineId;

    /**
     * 申请企业ID
     */
    private String applyEnterpriseId;

    /**
     * 申请人ID
     */
    private String applyUser;

    /**
     * 申请人名称
     */
    private String applyName;

    /**
     * 申请人联系方式
     */
    private String applyPhone;

    /**
     * 申请说明
     */
    private String description;

    /**
     * 场地用途(1:排练; 2:演出, 3:比赛; 4:沙龙; 5:讲座; 6:其他文化活动)
     */
    private Integer siteUse;

    /**
     * 预定日期(开始)
     */
    private String applyBedate;

    /**
     * 预定日期(结束)
     */
    private String applyEndate;

    /**
     * 开始时间
     */
    private String beginTime;

    /**
     * 结束时间
     */
    private String endTime;

    /**
     * 省编码
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编码
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编码
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道编码
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 审核人
     */
    private String auditman;

    /**
     * 审核时间(格式:yyyy-MM-dd HH:mm:ss)
     */
    private String auditTime;

    /**
     * 审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)
     */
    private Integer auditStatus;

    /**
     * 审核备注
     */
    private String auditRemark;

    /**
     * 创建人
     */
    private String createByUser;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 修改人
     */
    private String updateByUser;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 删除状态(0:正常; 1:已删除)
     */
    private Integer delFlag;

    /**
     * 申请类型(1:单个申请; 2:自定义申请)
     */
    private Integer applyType;

    /**
     * 申请自定义名称
     */
    private String destineCustomname;

    /**
     * 申请来源(1:门户; 2:微信; 3:小程序)
     */
    private Integer applySource;

    /**
     * SZWTL.T_VENUE_APPLY
     */
    private static final long serialVersionUID = 1L;

    /**
     * 审核日志
     */
    private List<TAuditLog> tAuditLogList;

    /**
     * 申请信息展示
     */
    private VenueApplyInfo venueApplyInfo;
}