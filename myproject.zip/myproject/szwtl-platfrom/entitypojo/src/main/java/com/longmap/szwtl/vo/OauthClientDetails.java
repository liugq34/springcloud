package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * 认证客户端详情表
 * @author yaohw
 */
@Data
public class OauthClientDetails implements Serializable {
    /**
     * 客户端(CLIENT_ID)
     */
    private String clientId;

    /**
     * 客户端所能访问的资源RESOURCE_IDS集合,多个资源时用逗号
     */
    private String resourceIds;

    /**
     * 客户端(CLIENT_ID)的访问密匙
     */
    private String clientSecret;

    /**
     * 客户端申请的权限范围,可选值包括read,write,trust,多个资源时用逗号
     */
    private String scope;

    /**
     * 客户端支持的grant_type,可选值包括authorization_code,password,refresh_token,implicit,client_credentials, 若支持多个grant_type用逗号隔开
     */
    private String authorizedGrantTypes;

    /**
     * 客户端的重定向URI
     */
    private String webServerRedirectUri;

    /**
     * 客户端所拥有的Spring Security的权限值,若有多个权限值用逗号隔开
     */
    private String authorities;

    /**
     * 客户端的access_token的有效时间值(单位:秒)
     */
    private Long accessTokenValidity;

    /**
     * 客户端的refresh_token的有效时间值(单位:秒)
     */
    private Long refreshTokenValidity;

    /**
     * 是否自动Approval操作, 默认值为 false, 可选值包括 true,false,read,write
     */
    private String autoapprove;

    /**
     * null
     */
    private Long trusted;

    /**
     * null
     */
    private Long archived;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 用户ID，用于客户端跟用户绑定
     */
    private String userId;

    /**
     * 预留的字段
     */
    private String additionalInformation;

    /**
     * USERPLAT.OAUTH_CLIENT_DETAILS
     */
    private static final long serialVersionUID = 1L;
}