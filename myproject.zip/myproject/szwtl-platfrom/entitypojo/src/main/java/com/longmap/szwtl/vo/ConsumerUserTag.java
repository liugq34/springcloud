package com.longmap.szwtl.vo;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 消费用户标签
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsumerUserTag implements Serializable {
    /**
     * ID
     */
    private String id;

    /**
     * 消费用户ID
     */
    private String consumerUserId;

    /**
     * 标签ID
     */
    private String tagId;

    /**
     * USERPLAT.T_CONSUMER_USER_TAG
     */
    private static final long serialVersionUID = 1L;
}