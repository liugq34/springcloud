package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.util.Date;
import lombok.Data;
/**
 * 角色表实体类
 * @author yaohw
 */
@Data
public class SysRole implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 角色名称
     */
    private String roleName;

    /**
     * 角色编码
     */
    private String roleCode;

    /**
     * 描述
     */
    private String description;

    /**
     * 创建人
     */
    private String createByUser;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新人
     */
    private String updateByUser;

    /**
     * 更新时间
     */
    private Date modifiedTime;

    /**
     * 删除状态 0正常 1已删除
     */
    private Long delFlag;

    /**
     * SYS_ROLE
     */
    private static final long serialVersionUID = 1L;
}