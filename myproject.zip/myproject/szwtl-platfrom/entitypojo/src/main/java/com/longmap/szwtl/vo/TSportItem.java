package com.longmap.szwtl.vo;

import java.io.Serializable;
import lombok.Data;

@Data
public class TSportItem implements Serializable {
    /**
     * 主键ID
     */
    private String sportItemId;

    /**
     * 运动项目编号
     */
    private String sportItemCode;

    /**
     * 运动项目名称
     */
    private String sportItemName;

    /**
     * 运动项目图标
     */
    private String sportItemIcon;

    /**
     * 排序
     */
    private Integer sort;

    /**
     * 状态 1.正常 2.禁止
     */
    private Integer status;

    /**
     * SZWTL.T_SPORT_ITEM
     */
    private static final long serialVersionUID = 1L;
}