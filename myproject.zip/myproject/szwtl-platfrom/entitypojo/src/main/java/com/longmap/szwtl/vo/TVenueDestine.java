package com.longmap.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

@Data
public class TVenueDestine implements Serializable {
    /**
     * 主键ID
     */
    private String id;

    /**
     * 场馆ID
     */
    private String venueId;

    /**
     * 场地名称
     */
    private String venueName;

    /**
     * 预定日期(格式:例如2019-08-26 ==》 20190826)
     */
    private Long destineDate;

    /**
     * 预定星期(星期 2 3 4 5 6 7 1 对应星期一到星期天)
     */
    private Integer destineWeek;

    /**
     * 开始时间(格式: 例如09：30 ==》 930)
     */
    private Long beginTime;

    /**
     * 结束时间(格式: 例如09：30 ==》 930)
     */
    private Long endTime;

    /**
     * 预定价格
     */
    private BigDecimal ticketFee;

    /**
     * 预定状态(0:未预定; 1:已预订; 2:自定义合并预定)
     */
    private Integer destineStatus;

    /**
     * 场地状态(0:正常; 1:下架)
     */
    private Integer status;

    /**
     * 删除状态(0:正常; 1:已删除)
     */
    private Integer delFlag;

    /**
     * 创建人
     */
    private String createUser;

    /**
     * 创建时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createdTime;

    /**
     * 修改时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date modifiedTime;

    /**
     * 预定人ID
     */
    private String destineId;

    /**
     * 活动室ID
     */
    private String fieldId;

    /**
     * 活动室名称
     */
    private String fieldName;

    /**
     * 预定人数
     */
    private Long reservePeople;

    /**
     * 自定义合并预定名称(用于自定义添加名称)
     */
    private String destineCustomname;

    /**
     * SZWTL.T_VENUE_DESTINE
     */
    private static final long serialVersionUID = 1L;

    /**非数据库数据*/
    private Long destineDate_end; //用于查询七天之内的预定情况
    /**开始时间*/
    private String beginTimeStr;
    /**结束时间*/
    private String endTimeStr;
    /**预定日期*/
    private String destineDateStr;
}