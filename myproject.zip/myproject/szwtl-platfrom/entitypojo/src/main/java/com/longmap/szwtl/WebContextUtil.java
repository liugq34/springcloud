/*
package com.longmap.szwtl;

import com.longmap.szwtl.pojo.common.UserTokenInfo;
import com.longmap.szwtl.util.JsonUtils;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.authentication.OAuth2AuthenticationDetails;

import java.util.LinkedHashMap;

public class WebContextUtil {


    */
/**
     * 获取当前上下文授权信息
     * @return
     *//*

    public static  OAuth2Authentication getAuthentication() {

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(null == authentication){
            return null;
        }
        if (!(authentication instanceof AnonymousAuthenticationToken)) {
            OAuth2Authentication oAuth2Authentication = (OAuth2Authentication)SecurityContextHolder.getContext().getAuthentication();
            return  oAuth2Authentication;
        }
        throw  new AuthenticationServiceException("authentication not found");
    }

    */
/**
     * 获取当前上下文token的信息
     * @return
     *//*

    public static OAuth2AuthenticationDetails getDetails(){
        Authentication authentication = getAuthentication();
        if(authentication == null){
            return null;
        }
        OAuth2AuthenticationDetails details = (OAuth2AuthenticationDetails) authentication.getDetails();
        return details;
    }

    */
/**
     * 获取登陆用户信息
     * @return
     *//*

    public static UserTokenInfo getUserInfo(){

        OAuth2Authentication oAuth2Authentication = getAuthentication();
        if(oAuth2Authentication == null){
            return null;
        }
        UsernamePasswordAuthenticationToken authentication = (UsernamePasswordAuthenticationToken)oAuth2Authentication.getUserAuthentication();
        LinkedHashMap userDetail =  (LinkedHashMap)authentication.getDetails();
        String json = JsonUtils.deserializer(userDetail);

        UserTokenInfo user = JsonUtils.serializable(json, UserTokenInfo.class);
        return user;
    }

    */
/**
     *  获取当前登入用户的访问accessToken
     * @return
     *//*

    public static String getAccessToken(){
        if(getDetails() == null){
            return null;
        }
        return getDetails().getTokenValue();
    }
}
*/
