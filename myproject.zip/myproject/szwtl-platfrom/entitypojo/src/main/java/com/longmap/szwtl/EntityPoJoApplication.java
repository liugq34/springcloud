package com.longmap.szwtl;

/**
 * @author Created by oushaohui on 2019/7/12 9:54
 * @description
 **/
public class EntityPoJoApplication {
    public static void main(String[] args) {

    }
}
