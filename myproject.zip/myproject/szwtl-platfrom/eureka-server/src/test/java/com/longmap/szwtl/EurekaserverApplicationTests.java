package com.longmap.szwtl;


import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class EurekaserverApplicationTests {

    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue() {
        assertTrue(true);
    }
}
