package com.longmap.szwtl.auth.util;

import com.longmap.szwtl.pojo.response.MenuNode;
import com.longmap.szwtl.util.ListWarp;
import com.longmap.szwtl.vo.SysAuthority;
import com.longmap.szwtl.vo.SysPermission;
import org.springframework.beans.BeanUtils;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Created by oushaohui on 2019/8/2 14:12
 * @description
 **/
public class BaseTransform {
    /**
     * 构建 List<GrantedAuthority>
     *
     * @param sysAuthorities
     * @return
     */
    public static List<GrantedAuthority> buildGrantedAuthority(List<SysAuthority> sysAuthorities) {
        List<GrantedAuthority> authorities = new ArrayList<>(sysAuthorities.size());
        for (SysAuthority sysAuthority : sysAuthorities) {
            authorities.add(new SimpleGrantedAuthority(sysAuthority.getAuthority()));
        }
        return authorities;
    }

    /**
     * 构建菜单树
     *
     * @param permissionList
     * @return
     */
    public static List<MenuNode> buildTree(List<SysPermission> permissionList) {
        List<MenuNode> resultList = new ArrayList<>();
        Map<String, List<SysPermission>> stringListMap = buildListMap(permissionList);
        Map<String, MenuNode> stringMenuNodeMap = buildMap(permissionList);
        //获取一级菜
        List<MenuNode> roots = getChildrenByParentId(null, stringListMap);
        for (MenuNode root : roots) {
            resultList.add(recursiveTree(root.getId(), stringListMap, stringMenuNodeMap));
        }
        return resultList;
    }

    /**
     * 递归获取子节点菜单
     *
     * @param id
     * @param stringListMap
     * @param stringMenuNodeMap
     * @return
     */
    private static MenuNode recursiveTree(String id, Map<String, List<SysPermission>> stringListMap, Map<String, MenuNode> stringMenuNodeMap) {
        MenuNode node = stringMenuNodeMap.get(id);
        node.setChildren(new ArrayList<>());
        List<MenuNode> children = getChildrenByParentId(id, stringListMap);
        if (children == null || children.isEmpty()) {
            node.setChildren(null);
            return node;
        }
        for (MenuNode child : children) {
            MenuNode nextChild = recursiveTree(child.getId(), stringListMap, stringMenuNodeMap);
            node.getChildren().add(nextChild);
        }
        return node;

    }


    /**
     * 根据父级ID获取子菜单
     *
     * @param parentId
     * @param stringListMap
     * @return
     */
    private static List<MenuNode> getChildrenByParentId(String parentId, Map<String, List<SysPermission>> stringListMap) {
        List<SysPermission> rootPermission = stringListMap.get(parentId);
        return warpList(rootPermission);
    }


    /**
     * 构建key为父级ID，value为子菜单的map
     *
     * @param list
     * @return
     */
    private static Map<String, List<SysPermission>> buildListMap(List<SysPermission> list) {
        Map<String, List<SysPermission>> map = new HashMap<>();
        for (SysPermission permission : list) {
            List<SysPermission> children = map.get(permission.getParentId());
            if (children == null) {
                children = new ArrayList<>();
                children.add(permission);
                map.put(permission.getParentId(), children);
            } else {
                children.add(permission);
                map.put(permission.getParentId(), children);
            }
        }
        return map;
    }


    /**
     * 构建key为ID，value为对象节点
     *
     * @param permissionList
     * @return
     */
    private static Map<String, MenuNode> buildMap(List<SysPermission> permissionList) {
        Map<String, MenuNode> map = new HashMap<>(permissionList.size());
        for (SysPermission permission : permissionList) {
            MenuNode target = new MenuNode();
            BeanUtils.copyProperties(permission, target);
            map.put(permission.getId(), target);
        }
        return map;
    }

    /**
     * 集合类型转换
     *
     * @param sourceList
     * @return
     */
    private static List<MenuNode> warpList(List<SysPermission> sourceList) {
        return new ListWarp<SysPermission, MenuNode>() {
            @Override
            public MenuNode warp(SysPermission source) {
                MenuNode target = new MenuNode();
                BeanUtils.copyProperties(source, target);
                return target;
            }
        }.warpList(sourceList);
    }
}
