package com.longmap.szwtl.auth.config.provider;

import com.longmap.szwtl.auth.config.token.CustomConsumerResourceOwnerPasswordTokenGranter;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

/**
 * @author Created by oushaohui on 2019/7/23 11:02
 * @description
 **/
public class ConsumerUsernamePasswordAuthenticationProvider extends DaoAuthenticationProvider {
    @Override
    public boolean supports(Class<?> authentication) {
        return CustomConsumerResourceOwnerPasswordTokenGranter.MyUsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
