package com.longmap.szwtl.auth.config.provider;

import com.longmap.szwtl.auth.config.token.CustomResourceOwnerPasswordTokenGranter;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

/**
 * @author Created by oushaohui on 2019/6/9 9:53
 * @description
 * @projectName springcloud-project
 * @packageName com.osh.core.config.provider
 */
public class UsernamePasswordAuthenticationProvider extends DaoAuthenticationProvider {
    @Override
    public boolean supports(Class<?> authentication) {
        return CustomResourceOwnerPasswordTokenGranter.MyUsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
