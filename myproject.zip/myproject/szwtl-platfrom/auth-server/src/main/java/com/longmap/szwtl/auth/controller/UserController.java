package com.longmap.szwtl.auth.controller;

import com.longmap.szwtl.auth.base.BaseConsumerUserDetails;
import com.longmap.szwtl.auth.base.BaseSysUserDetails;
import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import com.longmap.szwtl.pojo.response.BaseUserInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.BeanUtils;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

/**
 * @author Created by oushaohui on 2019/06/04 10:31
 * @description
 **/
@RestController
@Api(tags = "获取登录用户")
public class UserController {

    /**
     * 获取授权用户的信息
     *
     * @param user 当前用户
     * @return 授权信息
     */
    @GetMapping("/user")
    public Principal user(Principal user) {
        return user;
    }

    /**
     * 获取当前用户的信息
     *
     * @param user 当前用户
     * @return 授权信息
     */
    @GetMapping("/getUserInfo")
    @ApiOperation("登录用户")
    public ResponseResult getUserInfo(Principal user) {
        OAuth2Authentication oAuth2Authentication = (OAuth2Authentication) user;
        BaseUserInfo baseUserInfo = new BaseUserInfo();
        if (oAuth2Authentication.getUserAuthentication().getPrincipal() instanceof BaseSysUserDetails) {
            // 获取系统授权用户的信息
            BaseSysUserDetails baseSysUserDetails = (BaseSysUserDetails) oAuth2Authentication.getUserAuthentication().getPrincipal();
            BeanUtils.copyProperties(baseSysUserDetails.getSysUser(), baseUserInfo);
        } else if (oAuth2Authentication.getUserAuthentication().getPrincipal() instanceof BaseConsumerUserDetails) {
            // 获取普通授权用户的信息
            BaseConsumerUserDetails baseConsumerUserDetails = (BaseConsumerUserDetails) oAuth2Authentication.getUserAuthentication().getPrincipal();
            BeanUtils.copyProperties(baseConsumerUserDetails.getConsumerUser(), baseUserInfo);
        }
        ResponseResult responseResult = new ResponseResult();
        responseResult.setStatus(ResponseStatus.SUCCESS.getStatus());
        responseResult.setData(baseUserInfo);
        return responseResult;
    }
}