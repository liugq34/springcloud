package com.longmap.szwtl.auth.service;

import com.longmap.szwtl.auth.base.BaseSysUserDetails;
import com.longmap.szwtl.auth.config.SM3PasswordEncoder;
import com.longmap.szwtl.auth.controller.model.response.SysUserAndRole;
import com.longmap.szwtl.auth.mapper.SysAuthorityMapper;
import com.longmap.szwtl.auth.mapper.SysPermissionMapper;
import com.longmap.szwtl.auth.mapper.SysUserMapper;
import com.longmap.szwtl.auth.util.BaseTransform;
import com.longmap.szwtl.common.contant.RoleConstant;
import com.longmap.szwtl.pojo.response.BaseAuthority;
import com.longmap.szwtl.pojo.response.BaseRole;
import com.longmap.szwtl.pojo.response.MenuNode;
import com.longmap.szwtl.vo.SysAuthority;
import com.longmap.szwtl.vo.SysUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Created by oushaohui on 2019/7/18 14:20
 * @description 系统用户登录集成
 **/
public abstract class BaseSysUserDetailsService implements UserDetailsService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    protected SysUserMapper sysUserMapper;

    @Autowired
    protected SysPermissionMapper sysPermissionMapper;

    @Autowired
    protected SysAuthorityMapper sysAuthorityMapper;

    @Autowired
    protected SM3PasswordEncoder sm3PasswordEncoder;

    protected abstract SysUser getSysUser(String username);

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // 用户基本信息
        SysUser sysUser = getSysUser(username);
        if (sysUser != null) {
            if (sysUser.getStatus() == 0) {
                throw new BadCredentialsException(username + "用户已冻结");
            } else {
                // 用户角色
                SysUserAndRole sysUserAndRole = sysUserMapper.selectUserAndRoleByUserId(sysUser.getId());
                List<BaseRole> roles = new ArrayList<>();
                BaseRole baseRole = new BaseRole();
                baseRole.setRoleCode(sysUserAndRole.getRole().getRoleCode());
                roles.add(baseRole);
                sysUser.setRoles(roles);
                // 角色菜单
                List<MenuNode> nodeList = BaseTransform.buildTree(sysPermissionMapper.selectByRoleId(sysUserAndRole.getRole().getId()));
                sysUser.setNodeList(nodeList);
                // 角色权限
                List<SysAuthority> sysAuthorities = sysAuthorityMapper.selectByRoleId(sysUserAndRole.getRole().getId());
                List<BaseAuthority> authorities = new ArrayList<>();
                for (SysAuthority sysAuthority : sysAuthorities) {
                    BaseAuthority baseAuthority = new BaseAuthority();
                    baseAuthority.setAuthority(sysAuthority.getAuthority());
                    authorities.add(baseAuthority);
                }
                sysUser.setAuthorities(authorities);
                // 返回带有用户权限信息的User
                org.springframework.security.core.userdetails.User user = new org.springframework.security.core.userdetails.User(sysUser.getAccount(),
                        sysUser.getPassword(), true, true, true, true, BaseTransform.buildGrantedAuthority(sysAuthorities));
                return new BaseSysUserDetails(sysUser, user);
            }
        } else {
            throw new BadCredentialsException(username + "用户不存在");
        }
    }
}
