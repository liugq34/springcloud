package com.longmap.szwtl;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

/**
 * @author Created by oushaohui on 2019/7/23 15:54
 * @description OAuth2认证授权服务 @ EnableDiscoveryClient 启用服务注册发现
 */
@SpringBootApplication
@EnableDiscoveryClient
@MapperScan(basePackages = "com.longmap.szwtl.auth.mapper")
public class AuthServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(AuthServerApplication.class, args);
    }
}
