package com.longmap.szwtl.auth.config;

import com.longmap.szwtl.auth.config.token.CustomConsumerResourceOwnerPasswordTokenGranter;
import com.longmap.szwtl.auth.config.token.CustomInterfaceResourceOwnerPasswordTokenGranter;
import com.longmap.szwtl.auth.config.token.CustomResourceOwnerPasswordTokenGranter;
import com.longmap.szwtl.auth.config.token.WeChatConsumerTokenGranter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.CompositeTokenGranter;
import org.springframework.security.oauth2.provider.OAuth2RequestFactory;
import org.springframework.security.oauth2.provider.TokenGranter;
import org.springframework.security.oauth2.provider.client.ClientCredentialsTokenGranter;
import org.springframework.security.oauth2.provider.client.JdbcClientDetailsService;
import org.springframework.security.oauth2.provider.code.AuthorizationCodeServices;
import org.springframework.security.oauth2.provider.code.AuthorizationCodeTokenGranter;
import org.springframework.security.oauth2.provider.code.JdbcAuthorizationCodeServices;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;
import org.springframework.security.oauth2.provider.implicit.ImplicitTokenGranter;
import org.springframework.security.oauth2.provider.refresh.RefreshTokenGranter;
import org.springframework.security.oauth2.provider.token.AuthorizationServerTokenServices;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.JdbcTokenStore;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStore;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author Created by oushaohui on 2019/06/04 10:17
 * @description 授权服务器配置
 * EnableAuthorizationServer 启用授权服务
 **/
@Configuration
@EnableAuthorizationServer
public class AuthorizationServerConfigurer extends AuthorizationServerConfigurerAdapter {
    @Autowired
    private DataSource dataSource;
    @Autowired
    private AuthenticationManager authenticationManager;    // 认证管理器
    @Autowired
    private RedisConnectionFactory redisConnectionFactory;  // redis连接工厂
//    @Autowired
//    private WebResponseExceptionTranslator webResponseExceptionTranslator;

    /**
     * 指定token存储的位置
     *
     * @return
     */
    @Bean
    public TokenStore tokenStore() {
        return new RedisTokenStore(redisConnectionFactory);
        // return new JdbcTokenStore(dataSource);
    }

    @Bean // 声明 ClientDetails实现
    public ClientDetailsService clientDetails() {
        return new JdbcClientDetailsService(dataSource);
    }

    @Bean
    public AuthorizationCodeServices authorizationCodeServices() {
        return new JdbcAuthorizationCodeServices(dataSource);
    }

    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        endpoints.allowedTokenEndpointRequestMethods(HttpMethod.GET, HttpMethod.POST);
        endpoints.authenticationManager(this.authenticationManager);
        // 自定义token
        //endpoints.accessTokenConverter(accessTokenConverter());
        endpoints.tokenStore(tokenStore());
        // 配置TokenServices参数
        DefaultTokenServices tokenServices = new DefaultTokenServices();
        tokenServices.setTokenStore(endpoints.getTokenStore());
        // 是否支持刷新Token
        tokenServices.setSupportRefreshToken(true);
        tokenServices.setReuseRefreshToken(true);
        tokenServices.setClientDetailsService(endpoints.getClientDetailsService());
        tokenServices.setTokenEnhancer(endpoints.getTokenEnhancer());
        tokenServices.setAccessTokenValiditySeconds((int) TimeUnit.HOURS.toSeconds(2));// 2小时
        tokenServices.setRefreshTokenValiditySeconds((int) TimeUnit.DAYS.toSeconds(30));// 30天
        endpoints.tokenServices(tokenServices);
        endpoints.tokenGranter(tokenGranter(endpoints));
//        endpoints.exceptionTranslator(webResponseExceptionTranslator);
    }

    @Override
    public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
        security
                .tokenKeyAccess("permitAll()")
                .checkTokenAccess("isAuthenticated()");
    }

    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        // jdbc查出数据来存储
        clients.withClientDetails(clientDetails());
    }

    public TokenGranter tokenGranter(final AuthorizationServerEndpointsConfigurer endpoints) {
        ClientDetailsService clientDetails = endpoints.getClientDetailsService();
        AuthorizationServerTokenServices tokenServices = endpoints.getTokenServices();
        AuthorizationCodeServices authorizationCodeServices = authorizationCodeServices();
        OAuth2RequestFactory requestFactory = endpoints.getOAuth2RequestFactory();
        List<TokenGranter> tokenGranters = new ArrayList<TokenGranter>();
        tokenGranters.add(new AuthorizationCodeTokenGranter(tokenServices, authorizationCodeServices,
                clientDetails, requestFactory));
        tokenGranters.add(new RefreshTokenGranter(tokenServices, clientDetails, requestFactory));
        tokenGranters.add(new ImplicitTokenGranter(tokenServices, clientDetails, requestFactory));
        tokenGranters.add(new ClientCredentialsTokenGranter(tokenServices, clientDetails, requestFactory));
        /**
         * 系统用户自定义授权
         */
        CustomResourceOwnerPasswordTokenGranter tokenGranter = new CustomResourceOwnerPasswordTokenGranter(authenticationManager, tokenServices, clientDetails,
                requestFactory);
        tokenGranters.add(tokenGranter);
        /**
         * 普通用户自定义授权
         */
        CustomConsumerResourceOwnerPasswordTokenGranter customConsumerResourceOwnerPasswordTokenGranter = new CustomConsumerResourceOwnerPasswordTokenGranter(authenticationManager, tokenServices, clientDetails,
                requestFactory);
        tokenGranters.add(customConsumerResourceOwnerPasswordTokenGranter);
        /**
         * 自定义微信授权 10:14 2019/7/22
         */
        WeChatConsumerTokenGranter weChatConsumerTokenGranter = new WeChatConsumerTokenGranter(authenticationManager, tokenServices, clientDetails, requestFactory);
        tokenGranters.add(weChatConsumerTokenGranter);
        /**
         * 自定义接口用户授权 10:14 2019/7/22
         */
        CustomInterfaceResourceOwnerPasswordTokenGranter customInterfaceResourceOwnerPasswordTokenGranter = new CustomInterfaceResourceOwnerPasswordTokenGranter(authenticationManager, tokenServices, clientDetails, requestFactory);
        tokenGranters.add(customInterfaceResourceOwnerPasswordTokenGranter);
        return new CompositeTokenGranter(tokenGranters);
    }
}
