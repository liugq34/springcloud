package com.longmap.szwtl.auth.controller.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.longmap.szwtl.vo.SysRole;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 用户角色信息
 * @author: yaohw
 * @create: 2019-07-30 09:27
 **/
@Data
public class SysUserAndRole implements Serializable {

    /**
     * ID
     */
    private String id;

    /**
     * 登录账号
     */
    private String account;

    /**
     * 真实姓名
     */
    private String realname;

    /**
     * 密码
     */
    @JsonIgnore
    private String password;

    /**
     * 密码盐
     */
    @JsonIgnore
    private String salt;

    /**
     * 头像
     */
    private String avatar;

    /**
     * 生日
     */
    private String birthday;

    /**
     * 性别（1：男 2：女）
     */
    private Long sex;

    /**
     * 电子邮件
     */
    private String email;

    /**
     * 状态(1：正常  2：冻结 ）
     */
    private Long status;

    /**
     * 省编码
     */
    private String provinceId;

    /**
     * 省名称
     */
    private String provinceName;

    /**
     * 市编码
     */
    private String cityId;

    /**
     * 市名称
     */
    private String cityName;

    /**
     * 区域编码
     */
    private String districtId;

    /**
     * 区域名称
     */
    private String districtName;

    /**
     * 街道ID
     */
    private String subDistrictId;

    /**
     * 街道名称
     */
    private String subDistrictName;

    /**
     * 联系地址
     */
    private String address;

    /**
     * 删除状态（0，正常，1已删除）
     */
    private Long delFlag;

    /**
     * 描述
     */
    private String description;

    /**
     * 创建人
     */
    private String createByUser;

    /**
     * 创建时间
     */
    private Date createdTime;

    /**
     * 更新人
     */
    private String updateByUser;

    /**
     * 更新时间
     */
    private Date modifiedTime;

    /**
     * 企业ID
     */
    private String enterpriseId;

    /**
     * 门店ID
     */
    private String storeId;

    /**
     * 身份证号码
     */
    private String identityCard;


    /**
     * 用户类型，1:超级管理类，2：市区街道类，3：企业类
     */
    private Integer type;

    /**
     * SSO授权密码
     */
    @JsonIgnore
    private String authorizedPassword;

    /**
     * 用户角色
     */
    private SysRole role;
}
