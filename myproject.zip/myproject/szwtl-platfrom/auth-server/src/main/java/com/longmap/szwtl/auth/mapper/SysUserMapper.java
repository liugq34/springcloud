package com.longmap.szwtl.auth.mapper;

import com.longmap.szwtl.auth.controller.model.response.SysUserAndAuthority;
import com.longmap.szwtl.auth.controller.model.response.SysUserAndRole;
import com.longmap.szwtl.vo.SysPermission;
import com.longmap.szwtl.vo.SysUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SysUserMapper {
    /**
     * @mbg.generated
     */
    int deleteByPrimaryKey(String id);

    /**
     * @mbg.generated
     */
    int insert(SysUser record);

    /**
     * @mbg.generated
     */
    int insertSelective(SysUser record);

    /**
     * @mbg.generated
     */
    SysUser selectByPrimaryKey(String id);

    /**
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(SysUser record);

    /**
     * @mbg.generated
     */
    int updateByPrimaryKey(SysUser record);

    /**
     * @mbg.generated
     */
    SysUser selectByAccount(String account);

    /**
     * 根据用户ID查询用户角色菜单信息
     *
     * @param id
     * @return
     */
    SysUserAndRole selectUserAndRoleByUserId(String id);

    /**
     * 根据用户ID查询用户角色权限信息
     *
     * @param id
     * @return
     */
    SysUserAndAuthority selectUserAndAuthorityByUserId(String id);

}