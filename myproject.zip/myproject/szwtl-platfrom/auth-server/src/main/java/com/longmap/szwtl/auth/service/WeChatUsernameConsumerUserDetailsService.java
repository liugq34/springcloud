package com.longmap.szwtl.auth.service;

import com.longmap.szwtl.util.NumberUtil;
import com.longmap.szwtl.util.UUID;
import com.longmap.szwtl.vo.TConsumerUser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Created by oushaohui on 2019/7/23 10:43
 * @description 微信用户登录
 **/
@Service
public class WeChatUsernameConsumerUserDetailsService extends BaseConsumerUserDetailsService {

    protected Logger logger = LoggerFactory.getLogger(WeChatUsernameConsumerUserDetailsService.class);

    @Value("${wechat.appid}")
    private String appId;

    @Value("${wechat.secret}")
    private String secret;


    @Override
    protected TConsumerUser getConsumerUser(String username) {
        // 小程序登陆
        logger.info("个人用户{}登录中", username);
        logger.info("appId : " + appId + ", secret : " + secret + ", username : " + username);
        //小程序用户管理 API
        // https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code
        Map<String, String> param = new HashMap<String, String>();
        param.put("appid", appId);
        param.put("secret", secret);
        param.put("js_code", username);
        param.put("grant_type", "authorization_code");
        // POST  api.weixin.qq.com Method
        // 微信返回值
        Map<String, String> resMap = new HashMap<String, String>();
        resMap.put("openid", "sdafsafsfsdfaf");
        TConsumerUser tConsumerUser = tConsumerUserMapper.selectByAccount(username);
        if (tConsumerUser != null) {
            return tConsumerUser;
        } else {
            // 如果小程序员第一次进来就要注册
            // insert user
            tConsumerUser = new TConsumerUser();
            tConsumerUser.setId(UUID.randomUUID());
            tConsumerUser.setWxOpenid(UUID.randomUUID());
            tConsumerUser.setAccount(username);
            tConsumerUser.setContacts(username);
            tConsumerUser.setIdentityCard("110101199003072578");
            tConsumerUser.setRealname("张三丰");
            tConsumerUser.setSex(1L);
            tConsumerUser.setBirthday("1008/8/1");
            tConsumerUser.setAddress("广东省深圳市福田区档案大厦");

            StringBuffer stringBuffer = new StringBuffer("123456");
            String salt = NumberUtil.randomNumber();
            String password = sm3PasswordEncoder.encode(stringBuffer.toString());
            tConsumerUser.setPassword(password);
            tConsumerUser.setAuthorizedPassword(password);
            tConsumerUser.setSalt(salt);

            Date now =new Date();
            tConsumerUser.setCreatedTime(now);
            tConsumerUserMapper.insert(tConsumerUser);
            return tConsumerUser;
        }

    }
}
