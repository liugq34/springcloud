package com.longmap.szwtl.auth.service;

import com.longmap.szwtl.vo.SysUser;
import org.springframework.stereotype.Service;

/**
 * @author Created by oushaohui on 2019/7/18 14:19
 * @description
 **/
@Service
public class UsernameSysUserDetailsService extends BaseSysUserDetailsService {
    @Override
    protected SysUser getSysUser(String username) {
      return sysUserMapper.selectByAccount(username);
    }
}
