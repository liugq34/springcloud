package com.longmap.szwtl.auth.config.exception;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;

/**
 * @author Created by oushaohui on 2019/8/13 14:58
 * @description
 **/
@JsonSerialize(using = UserOAuth2ExceptionJacksonSerializer.class)
public class UserOAuth2Exception extends OAuth2Exception {
    private Integer status = 400;

    public UserOAuth2Exception(String message, Throwable t) {
        super(message, t);
        status = ((OAuth2Exception) t).getHttpErrorCode();
    }

    public UserOAuth2Exception(String message) {
        super(message);
    }

    @Override
    public int getHttpErrorCode() {
        return status;
    }
}
