package com.longmap.szwtl.auth.mapper;

import com.longmap.szwtl.vo.SysAuthority;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysAuthorityMapper {
    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(String id);

    /**
     *
     * @mbg.generated
     */
    int insert(SysAuthority record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(SysAuthority record);

    /**
     *
     * @mbg.generated
     */
    SysAuthority selectByPrimaryKey(String id);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(SysAuthority record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(SysAuthority record);

    /**
     * 根据权限查询
     * @param Authority
     * @return
     */
    SysAuthority selectOneByAuthority(String Authority);

    /**
     * 查询全部
     * @return
     */
    List<SysAuthority> selectAll();

    /**
     * 查询角色对应的权限
     * @param roleId
     * @return
     */
    List<SysAuthority> selectByRoleId(String roleId);
}