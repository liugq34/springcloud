package com.longmap.szwtl.auth.controller.model.response;

import com.longmap.szwtl.pojo.response.BaseRole;
import com.longmap.szwtl.pojo.response.MenuNode;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author Created by oushaohui on 2019/7/31 14:42
 * @description
 **/
@Data
@ApiModel("授权用户model")
public class UserInfo implements Serializable {
    /**
     * ID
     */
    @ApiModelProperty(value = "主键ID")
    private String id;

    /**
     * 登录账号
     */
    @ApiModelProperty(value = "登录账号")
    private String account;

    /**
     * 真实姓名
     */
    @ApiModelProperty(value = "真实姓名")
    private String realname;

    /**
     * 头像
     */
    @ApiModelProperty(value = "头像")
    private String avatar;

    /**
     * 生日
     */
    @ApiModelProperty(value = "生日")
    private String birthday;

    /**
     * 性别（1：男 2：女）
     */
    @ApiModelProperty(value = "性别（1：男 2：女）")
    private Long sex;

    /**
     * 电子邮件
     */
    @ApiModelProperty(value = "电子邮件")
    private String email;

    /**
     * 状态(1：正常  2：冻结 ）
     */
    @ApiModelProperty(value = "状态(1：正常  2：冻结 ）")
    private Long status;

    /**
     * 省编码
     */
    @ApiModelProperty(value = "省编码")
    private String provinceId;

    /**
     * 省名称
     */
    @ApiModelProperty(value = "省名称")
    private String provinceName;

    /**
     * 市编码
     */
    @ApiModelProperty(value = "市编码")
    private String cityId;

    /**
     * 市名称
     */
    @ApiModelProperty(value = "市名称")
    private String cityName;

    /**
     * 区域编码
     */
    @ApiModelProperty(value = "区域编码")
    private String districtId;

    /**
     * 区域名称
     */
    @ApiModelProperty(value = "区域名称")
    private String districtName;


    /**
     * 街道ID
     */
    @ApiModelProperty(value = "街道ID")
    private String subDistrictId;

    /**
     * 街道名称
     */
    @ApiModelProperty(value = "街道名称")
    private String subDistrictName;

    /**
     * 联系地址
     */
    @ApiModelProperty(value = "联系地址")
    private String address;

    /**
     * 描述
     */
    @ApiModelProperty(value = "描述")
    private String description;


    /**
     * 创建时间
     */
    @ApiModelProperty(value = "创建时间")
    private Date createdTime;

    /**
     * 企业ID
     */
    @ApiModelProperty(value = "企业ID")
    private String enterpriseId;

    /**
     * 门店ID
     */
    @ApiModelProperty(value = "门店ID")
    private String storeId;
    /**
     * 角色菜单
     */
    @ApiModelProperty(value = "角色菜单")
    private List<MenuNode> nodeList;
    /**
     * 角色权限
     */
    @ApiModelProperty(value = "角色权限")
    private List<GrantedAuthority> authorities;
    /**
     * 角色
     */
    @ApiModelProperty(value = "角色")
    /**
     * 角色
     */
    private List<BaseRole> roles;
}
