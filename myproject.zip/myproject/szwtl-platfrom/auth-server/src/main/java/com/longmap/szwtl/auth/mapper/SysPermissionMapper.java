package com.longmap.szwtl.auth.mapper;

import com.longmap.szwtl.vo.SysPermission;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface SysPermissionMapper {
    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(String id);

    /**
     *
     * @mbg.generated
     */
    int insert(SysPermission record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(SysPermission record);

    /**
     *
     * @mbg.generated
     */
    SysPermission selectByPrimaryKey(String id);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(SysPermission record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(SysPermission record);

    /**
     * 查询一级菜单上一个排序编码
     * @return
     */
    SysPermission selectRootSortNo();

    /**
     * 查询子级菜单上一个排序编码
     * @param parentId 父级ID
     * @return
     */
    SysPermission selectChildSortNo(@Param(value = "parentId") String parentId);


    /**
     * 查询所有菜单
     * @param delFlag 删除标识，0：正常，1：删除
     * @return
     */
    List<SysPermission> selectAll(@Param(value = "delFlag") long delFlag);

    /**
     * 查询角色对应的权限菜单
     * @param roleId
     * @return
     */
    List<SysPermission> selectByRoleId(@Param("roleId") String roleId);

    /**
     * 查询一级菜单列表
     * @return
     */
    List<SysPermission> selectRootList();

    /**
     * 根据父级ID查询其子菜单列表
     * @param parentId
     * @return
     */
    List<SysPermission> selectChildren(@Param(value = "parentId") String parentId);

}