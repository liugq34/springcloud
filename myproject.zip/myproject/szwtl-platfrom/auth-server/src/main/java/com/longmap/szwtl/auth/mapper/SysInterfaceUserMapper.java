package com.longmap.szwtl.auth.mapper;
import com.longmap.szwtl.vo.SysInterfaceUser;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface SysInterfaceUserMapper {
    /**
     *
     * @mbg.generated
     */
    int deleteByPrimaryKey(SysInterfaceUser record);

    /**
     *
     * @mbg.generated
     */
    int insert(SysInterfaceUser record);

    /**
     *
     * @mbg.generated
     */
    int insertSelective(SysInterfaceUser record);

    /**
     *
     * @mbg.generated
     */
    SysInterfaceUser selectByPrimaryKey(String id);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(SysInterfaceUser record);

    /**
     *
     * @mbg.generated
     */
    int updateByPrimaryKey(SysInterfaceUser record);
    List<SysInterfaceUser> list(SysInterfaceUser sysInterfaceUser);
    SysInterfaceUser selectByAccount(String account);
}