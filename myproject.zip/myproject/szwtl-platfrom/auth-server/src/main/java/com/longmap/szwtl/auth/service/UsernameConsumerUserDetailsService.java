package com.longmap.szwtl.auth.service;

import com.longmap.szwtl.vo.TConsumerUser;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

/**
 * @author Created by oushaohui on 2019/7/23 10:40
 * @description
 **/
@Service
@Log4j2
public class UsernameConsumerUserDetailsService extends BaseConsumerUserDetailsService {
    @Override
    protected TConsumerUser getConsumerUser(String username) {
        TConsumerUser consumerUser = tConsumerUserMapper.selectByAccount(username);
        log.info("{}",consumerUser);
        return consumerUser;
    }
}
