package com.longmap.szwtl.auth.config.provider;

import com.longmap.szwtl.auth.config.token.WeChatConsumerTokenGranter;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;

/**
 * @author Created by oushaohui on 2019/6/9 9:51
 * @description
 * @projectName springcloud-project
 * @packageName com.osh.core.config.provider
 */
public class WeChatAuthenticationProvider extends DaoAuthenticationProvider {
    @Override
    public boolean supports(Class<?> authentication) {
        return WeChatConsumerTokenGranter.WeChatAppletsAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
