package com.longmap.szwtl.auth.service;

import com.longmap.szwtl.auth.base.BaseConsumerUserDetails;
import com.longmap.szwtl.auth.base.BaseInterfaceUserDetails;
import com.longmap.szwtl.auth.config.SM3PasswordEncoder;
import com.longmap.szwtl.auth.mapper.SysAuthorityMapper;
import com.longmap.szwtl.auth.mapper.SysInterfaceUserMapper;
import com.longmap.szwtl.auth.mapper.SysPermissionMapper;
import com.longmap.szwtl.auth.mapper.TConsumerUserMapper;
import com.longmap.szwtl.pojo.response.BaseRole;
import com.longmap.szwtl.vo.SysInterfaceUser;
import com.longmap.szwtl.vo.TConsumerUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Created by oushaohui on 2019/7/23 10:34
 * @description 开放接口用户登录集成
 **/
public abstract class BaseInterfaceUserDetailsService implements UserDetailsService {
    @Autowired
    SysInterfaceUserMapper sysInterfaceUserMapper;

    protected abstract SysInterfaceUser getSysInterfaceUser(String username);

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // 用户基本信息
        SysInterfaceUser sysInterfaceUser = getSysInterfaceUser(username);
        if (sysInterfaceUser != null) {
            // 角色
            List<BaseRole> roles = new ArrayList<>();
            BaseRole baseRole = new BaseRole();
            baseRole.setRoleCode("GUEST");
            roles.add(baseRole);
            sysInterfaceUser.setRoles(roles);
            // 返回带有用户权限信息的User
            org.springframework.security.core.userdetails.User user = new org.springframework.security.core.userdetails.User(sysInterfaceUser.getAccount(),
                    sysInterfaceUser.getPassword(), true, true, true, true, AuthorityUtils.createAuthorityList(new String[]{"GUEST_ROLE"}));
            return new BaseInterfaceUserDetails(sysInterfaceUser, user);
        } else {
            throw new BadCredentialsException(username + "用户不存在");
        }
    }
}
