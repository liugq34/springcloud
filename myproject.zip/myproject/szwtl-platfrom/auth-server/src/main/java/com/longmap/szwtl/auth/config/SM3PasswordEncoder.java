package com.longmap.szwtl.auth.config;

import com.longmap.szwtl.common.encryption.SM3Digest;
import lombok.extern.apachecommons.CommonsLog;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * @author Created by oushaohui on 2019/7/23 10:04
 * @description
 **/
@CommonsLog
public class SM3PasswordEncoder implements PasswordEncoder {

    @Override
    public String encode(CharSequence charSequence) {
        SM3Digest sm3Digest = new SM3Digest();
        return sm3Digest.encode(charSequence.toString());
    }

    /**
     * @param charSequence 明文
     * @param s            密文
     * @return
     */
    @Override
    public boolean matches(CharSequence charSequence, String s) {
        SM3Digest sm3Digest = new SM3Digest();
        if (sm3Digest.encode(charSequence.toString()).equals(s)) {
            return true;
        }
        return false;
    }
}
