package com.longmap.szwtl.auth.controller;

import com.longmap.szwtl.common.response.ResponseResult;
import com.longmap.szwtl.common.response.ResponseStatus;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Created by oushaohui on 2019/8/19 15:52
 * @description
 **/
@RestController
@Api(tags = "登出接口")
public class TokenRevokeEndpointController {

    @Autowired
    @Qualifier("consumerTokenServices")
    private ConsumerTokenServices tokenServices;

    @DeleteMapping("/oauth/logout")
    @ApiOperation("登出")
    public ResponseResult logout(@RequestParam("access_token") String access_token) {
        boolean flag = tokenServices.revokeToken(access_token);
        ResponseResult responseResult = new ResponseResult();
        if (flag) {
            responseResult.setStatus(ResponseStatus.SUCCESS.getStatus());
            responseResult.setMessage(ResponseStatus.SUCCESS.getMessage());
        } else {
            responseResult.setStatus(ResponseStatus.ERROR.getStatus());
            responseResult.setMessage(ResponseStatus.ERROR.getMessage());
        }
        return responseResult;
    }
}
