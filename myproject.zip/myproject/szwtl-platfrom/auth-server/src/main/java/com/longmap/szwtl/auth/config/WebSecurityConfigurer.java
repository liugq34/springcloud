package com.longmap.szwtl.auth.config;


import com.longmap.szwtl.auth.config.provider.ConsumerUsernamePasswordAuthenticationProvider;
import com.longmap.szwtl.auth.config.provider.UsernamePasswordAuthenticationProvider;
import com.longmap.szwtl.auth.config.provider.WeChatAuthenticationProvider;
import com.longmap.szwtl.auth.service.UsernameConsumerUserDetailsService;
import com.longmap.szwtl.auth.service.UsernameInterfaceUserDetailsService;
import com.longmap.szwtl.auth.service.UsernameSysUserDetailsService;
import com.longmap.szwtl.auth.service.WeChatUsernameConsumerUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.Arrays;

/**
 * @author Created by oushaohui on 2019/06/04 10:29
 * @description 安全配置
 * EnableWebSecurity 启用web安全配置
 * EnableGlobalMethodSecurity 启用全局方法安全注解，就可以在方法上使用注解来对请求进行过滤
 **/
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfigurer extends WebSecurityConfigurerAdapter {
    /**
     * 注入系统用户信息服务
     *
     * @return 用户信息服务对象
     */
    @Bean
    public UserDetailsService userDetailsService() {
        return new UsernameSysUserDetailsService();
    }

    /**
     * 注入系统用户信息服务
     *
     * @return 用户信息服务对象
     */
    @Bean
    public UserDetailsService usernameConsumerUserDetailsService() {
        return new UsernameConsumerUserDetailsService();
    }

    /**
     * 注入系统用户信息服务
     *
     * @return 用户信息服务对象
     */
    @Bean
    public UserDetailsService usernameInterfaceUserDetailsService() {
        return new UsernameInterfaceUserDetailsService();
    }


    /**
     * 注入微信用户信息服务
     *
     * @return 用户信息服务对象
     */
    @Bean
    public UserDetailsService weChatUserDetailsService() {
        return new WeChatUsernameConsumerUserDetailsService();
    }

    /**
     * 配置匹配用户时密码规则
     */
    @Bean
    public SM3PasswordEncoder sm3PasswordEncoder() {
        return new SM3PasswordEncoder();
    }

    /**
     * 全局用户信息
     *
     * @param auth 认证管理
     * @throws Exception 用户认证异常信息
     */
    @Autowired
    public void globalUserDetails(AuthenticationManagerBuilder auth) throws Exception {
        // 设置UserDetailsService以及密码规则
        auth.userDetailsService(userDetailsService()).passwordEncoder(sm3PasswordEncoder());
    }

    /**
     * 认证管理
     *
     * @return 认证管理对象
     * @throws Exception 认证异常信息
     */
    @Override
    @Bean
    public AuthenticationManager authenticationManagerBean() throws Exception {
        return new ProviderManager(Arrays.asList(usernamePasswordAuthenticationProvider(), weChatAuthenticationProvider(), consumerUsernamePasswordAuthenticationProvider()));
    }

    /**
     * http安全配置
     *
     * @param http http安全对象
     * @throws Exception http安全异常信息
     */
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests().antMatchers(HttpMethod.OPTIONS).permitAll().anyRequest().authenticated().and()
                .httpBasic().and().csrf().disable();
    }

    @Bean
    public UsernamePasswordAuthenticationProvider usernamePasswordAuthenticationProvider() {
        UsernamePasswordAuthenticationProvider provider = new UsernamePasswordAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService());
        provider.setPasswordEncoder(sm3PasswordEncoder());
        provider.setHideUserNotFoundExceptions(false);
        return provider;
    }

    @Bean
    public WeChatAuthenticationProvider weChatAuthenticationProvider() {
        WeChatAuthenticationProvider provider = new WeChatAuthenticationProvider();
        provider.setUserDetailsService(weChatUserDetailsService());
        provider.setPasswordEncoder(sm3PasswordEncoder());
        provider.setHideUserNotFoundExceptions(false);
        return provider;
    }

    @Bean
    public ConsumerUsernamePasswordAuthenticationProvider consumerUsernamePasswordAuthenticationProvider() {
        ConsumerUsernamePasswordAuthenticationProvider provider = new ConsumerUsernamePasswordAuthenticationProvider();
        provider.setUserDetailsService(usernameConsumerUserDetailsService());
        provider.setPasswordEncoder(sm3PasswordEncoder());
        provider.setHideUserNotFoundExceptions(false);
        return provider;
    }
}
