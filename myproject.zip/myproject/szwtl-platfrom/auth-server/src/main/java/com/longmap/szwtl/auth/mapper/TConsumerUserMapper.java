package com.longmap.szwtl.auth.mapper;

import com.longmap.szwtl.vo.TConsumerUser;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TConsumerUserMapper {
    /**
     * @mbg.generated
     */
    int deleteByPrimaryKey(String id);

    /**
     * @mbg.generated
     */
    int insert(TConsumerUser record);

    /**
     * @mbg.generated
     */
    int insertSelective(TConsumerUser record);

    /**
     * @mbg.generated
     */
    TConsumerUser selectByPrimaryKey(String id);

    /**
     * @mbg.generated
     */
    int updateByPrimaryKeySelective(TConsumerUser record);

    /**
     * @mbg.generated
     */
    int updateByPrimaryKey(TConsumerUser record);

    /**
     * 账号查询用户
     */
    TConsumerUser selectByAccount(String account);

    /**
     * 微信WX_OPENID查询用户
     */
    TConsumerUser selectByWxOpenid(String wxOpenid);
}