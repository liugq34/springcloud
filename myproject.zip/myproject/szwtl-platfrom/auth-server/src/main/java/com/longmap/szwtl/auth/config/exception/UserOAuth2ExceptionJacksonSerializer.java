package com.longmap.szwtl.auth.config.exception;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import org.springframework.web.util.HtmlUtils;

import java.io.IOException;
import java.util.Map;

/**
 * @author Created by oushaohui on 2019/8/13 15:09
 * @description
 **/
public class UserOAuth2ExceptionJacksonSerializer extends StdSerializer<UserOAuth2Exception> {

    protected UserOAuth2ExceptionJacksonSerializer() {
        super(UserOAuth2Exception.class);
    }

    @Override
    public void serialize(UserOAuth2Exception value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        gen.writeStartObject();
        gen.writeObjectField("status", value.getHttpErrorCode());
        String message = value.getMessage();
        if (message != null) {
            message = HtmlUtils.htmlEscape(message);
        }
        gen.writeStringField("message", message);
        if (value.getAdditionalInformation() != null) {
            for (Map.Entry<String, String> entry : value.getAdditionalInformation().entrySet()) {
                String key = entry.getKey();
                String add = entry.getValue();
                gen.writeStringField(key, add);
            }
        }
        gen.writeEndObject();
    }
}
