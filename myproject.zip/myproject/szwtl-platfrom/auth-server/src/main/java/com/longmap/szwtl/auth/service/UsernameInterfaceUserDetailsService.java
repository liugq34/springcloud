package com.longmap.szwtl.auth.service;

import com.longmap.szwtl.vo.SysInterfaceUser;
import com.longmap.szwtl.vo.SysUser;
import com.longmap.szwtl.vo.TConsumerUser;
import org.springframework.stereotype.Service;

/**
 * @author Created by oushaohui on 2019/7/18 14:19
 * @description
 **/
@Service
public class UsernameInterfaceUserDetailsService extends BaseInterfaceUserDetailsService {

    @Override
    protected SysInterfaceUser getSysInterfaceUser(String username) {
        return sysInterfaceUserMapper.selectByAccount(username);
    }
}
