package com.longmap.szwtl.gateway.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;

/**
 * @author Created by oushaohui on 2019/8/26 10:19
 * @description
 **/
public class CustomRouteLocator {

    private static Logger logger = LoggerFactory.getLogger(CustomRouteLocator.class);

    @Autowired
    private RequestFilter requestFilter;

    public RouteLocator routeLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("auth-server",
                        r -> r
                                .method(HttpMethod.GET)
                                .and()
                                .path("/auth/**")
                                .filters(f -> {
                                    f.filter(requestFilter);
                                    logger.info("request method GET");
                                    return f;
                                })
                                .uri("lb://auth-server"))
                .route("auth-server",
                        r -> r
                                .method(HttpMethod.POST)
                                .and()
                                .readBody(String.class, readBody -> {
                                    logger.info("request method POST, Content-Type is application/x-www-form-urlencoded, body  is:{}", readBody);
                                    return true;
                                })
                                .and()
                                .path("/auth/**")
                                .filters(f -> {
                                    f.filter(requestFilter);
                                    return f;
                                })
                                .uri("lb://auth-server")
                ).build();
    }
}
