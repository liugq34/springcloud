package com.longmap.szwtl.gateway.filter;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.factory.AbstractGatewayFilterFactory;
import org.springframework.cloud.gateway.support.BodyInserterContext;
import org.springframework.cloud.gateway.support.CachedBodyOutputMessage;
import org.springframework.cloud.gateway.support.DefaultServerRequest;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Created by oushaohui on 2019/8/26 15:49
 * @description 请求日志
 **/
public class RequestGatewayFilterFactory extends AbstractGatewayFilterFactory<Object> {

    private static Logger logger = LoggerFactory.getLogger(RequestGatewayFilterFactory.class);

    private static final String START_TIME = "startTime";
    private static final String REQUEST_ID = "REQUEST_ID";

    @Override
    public GatewayFilter apply(Object config) {
        return new RequestFilter();
    }

    @Override
    public String name() {
        return "RequestLog";
    }

    /**
     * 请求过滤器
     */
    private class RequestFilter implements GatewayFilter, Ordered {
        @Override
        public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
            // 记录请求参数
            exchange.getAttributes().put(START_TIME, System.currentTimeMillis());
            exchange.getAttributes().put(REQUEST_ID, UUID.randomUUID().toString());
            return chain.filter(exchange.mutate().request(exchange.getRequest()).build()).then(Mono.fromRunnable(() -> {
                // 请求数据类型
                MediaType mediaType = exchange.getRequest().getHeaders().getContentType();
                ServerRequest serverRequest = new DefaultServerRequest(exchange);
                if (MediaType.APPLICATION_JSON.isCompatibleWith(mediaType)) { // 如果是JSON格式，将Body内容转化为Object Or Map
                    serverRequest.bodyToMono(Object.class)
                            .flatMap(body -> {
                                buildRequestLog(exchange.getRequest(), body);
                                return Mono.just(body);
                            });
                } else if (MediaType.APPLICATION_FORM_URLENCODED.isCompatibleWith(mediaType)) {  // 如果是表单请求
                    serverRequest.bodyToMono(String.class)
                            .flatMap(body -> {
                                buildRequestLog(exchange.getRequest(), body);
                                return Mono.just(body);
                            });
                }
                // 无法兼容的请求，则不读取body
                buildRequestLog(exchange.getRequest(), "");
                Long startTime = exchange.getAttribute(START_TIME);
                String requestId = exchange.getAttribute(REQUEST_ID);
                if (StringUtils.isNotEmpty(requestId) && startTime != null) {
                    Long executeTime = (System.currentTimeMillis() - startTime);
                    logger.info("Execute Time={}", requestId + "," + exchange.getRequest().getPath() + " : " + executeTime + "ms");
                }
            }));
        }


        /**
         * 优先级默认设置为最高
         *
         * @return
         */
        @Override
        public int getOrder() {
            return Ordered.HIGHEST_PRECEDENCE;
        }


        /**
         * 参照 ModifyRequestBodyGatewayFilterFactory.java 截取的方法
         *
         * @param exchange
         * @param chain
         * @param outClass
         * @param modifiedBody
         * @return
         */
        private Mono<Void> bodyToMono(ServerWebExchange exchange, GatewayFilterChain chain, Class outClass, Mono<?> modifiedBody) {
            BodyInserter bodyInserter = BodyInserters.fromPublisher(modifiedBody, outClass);
            HttpHeaders headers = new HttpHeaders();
            headers.putAll(exchange.getRequest().getHeaders());

            // the new content type will be computed by bodyInserter
            // and then set in the request decorator
            headers.remove(HttpHeaders.CONTENT_LENGTH);

            CachedBodyOutputMessage outputMessage = new CachedBodyOutputMessage(exchange, headers);

            return bodyInserter.insert(outputMessage, new BodyInserterContext())
                    // .log("modify_request", Level.INFO)
                    .then(Mono.defer(() -> {
                        ServerHttpRequestDecorator decorator = new ServerHttpRequestDecorator(
                                exchange.getRequest()) {
                            @Override
                            public HttpHeaders getHeaders() {
                                long contentLength = headers.getContentLength();
                                HttpHeaders httpHeaders = new HttpHeaders();
                                httpHeaders.putAll(super.getHeaders());
                                if (contentLength > 0) {
                                    httpHeaders.setContentLength(contentLength);
                                } else {
                                    // TODO: this causes a 'HTTP/1.1 411 Length Required'
                                    // on httpbin.org
                                    httpHeaders.set(HttpHeaders.TRANSFER_ENCODING,
                                            "chunked");
                                }
                                return httpHeaders;
                            }

                            @Override
                            public Flux<DataBuffer> getBody() {
                                return outputMessage.getBody();
                            }
                        };
                        return chain.filter(exchange.mutate().request(decorator).build()).then(Mono.fromRunnable(() -> {
                            Long startTime = exchange.getAttribute(START_TIME);
                            String requestId = exchange.getAttribute(REQUEST_ID);
                            if (startTime != null) {
                                Long executeTime = (System.currentTimeMillis() - startTime);
                                logger.info("Execute Time={}", requestId + "," + exchange.getRequest().getPath() + " : " + executeTime + "ms");
                            }
                        }));
                    }));
        }

        /**
         * @param serverHttpRequest request
         * @param body              请求body内容
         */
        private void buildRequestLog(ServerHttpRequest serverHttpRequest, Object body) {
            logger.info("Host={}", serverHttpRequest.getURI().getHost());
            logger.info("Path={}", serverHttpRequest.getURI().getPath());
            logger.info("Port={}", serverHttpRequest.getURI().getPort() + "");
            // 记录要访问的URL
            StringBuilder builder = new StringBuilder("Request=");
            builder.append(serverHttpRequest.getURI().getRawPath());
            // 记录访问的IP
            logger.info("getHostAddress={}", serverHttpRequest.getRemoteAddress().getAddress().getHostAddress());
            logger.info("getRemoteAddress={}", serverHttpRequest.getRemoteAddress());
            logger.info("getHostString={}", serverHttpRequest.getRemoteAddress().getHostString());
            logger.info("getHostName={}", serverHttpRequest.getRemoteAddress().getHostName());
            builder.append(", HostAddress: ").append(serverHttpRequest.getRemoteAddress().getAddress().getHostAddress());
            // 记录访问的方法
            HttpMethod method = serverHttpRequest.getMethod();
            if (null != method) {
                builder.append(", Method: ").append(method.name());
            }
            // 获取HttpHeaders
            builder.append(", Header { ");
            for (Map.Entry<String, List<String>> entry : serverHttpRequest.getHeaders().entrySet()) {
                logger.info("Key={},Value={}", entry.getKey(), entry.getValue());
                builder.append(entry.getKey()).append(":").append(StringUtils.join(entry.getValue(), ",")).append(",");
            }
            builder.deleteCharAt(builder.length() - 1);
            // 记录参数
            builder.append("} Param {");
            if (null != method && HttpMethod.GET.matches(method.name())) {
                // 记录请求的参数信息 针对GET 请求
                MultiValueMap<String, String> queryParams = serverHttpRequest.getQueryParams();
                for (Map.Entry<String, List<String>> entry : queryParams.entrySet()) {
                    builder.append(entry.getKey()).append("=").append(StringUtils.join(entry.getValue(), ",")).append(",");
                }
                builder.deleteCharAt(builder.length() - 1);
                builder.append("}");
            } else {
                builder.append(serverHttpRequest.getURI().getQuery());
                builder.append("} Body: ");
                // 从Body中读取参数
                builder.append(body);
            }
            logger.info(builder.toString());
        }
    }

    /**
     * 获取请求IP
     *
     * @param request
     * @return
     */
    private static String getIpAddress(ServerHttpRequest request) {
        HttpHeaders headers = request.getHeaders();
        String ip = headers.getFirst("x-forwarded-for");
        if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
            // 多次反向代理后会有多个ip值，第一个ip才是真实ip
            if (ip.indexOf(",") != -1) {
                ip = ip.split(",")[0];
            }
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = headers.getFirst("X-Real-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddress().getAddress().getHostAddress();
        }
        return ip;
    }
}
