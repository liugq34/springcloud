package com.longmap.szwtl.gateway.response;

/**
 * @author Created by oushaohui on 2019/7/24 9:22
 * @description 返回状态
 */
public enum ResponseStatus {
    /**
     * success
     */
    SUCCESS("success", "success"),
    SERVICE_OFFLINE("SERVICE OFFLINE","Service Offline"),
    ERROR("error", "程序发生未知异常，请联系管理员解决。"),
    INVALID_REQUEST("invalid_request", "请求缺少某个必需参数，包含一个不支持的参数或参数值，或者格式不正确。"),
    INVALID_CLIENT("invalid_client", "请求的client_id或client_secret参数无效。"),
    INVALID_GRANT("invalid_grant", "请求的grant_type是无效的。"),
    INVALID_SCOPE("invalid_scope", "请求的scope参数是无效的"),
    EXPIRED_TOKEN("expired_token", "请求的access_token已过期。"),
    REDIRECT_URI_MISMATCH("redirect_uri_mismatch", "请求的redirect_uri所在的域名与开发者注册应用时所填写的域名不匹配。"),
    INVALID_REDIRECT_URI("invalid_redirect_uri", "请求的回调URL不在白名单中。"),
    INVALID_SIGNATURE("invalid_signature", "无效的签名。"),
    SHORTAGE_STOCK("shortage_stock", "库存不够。"),
    STOCK_NULL("stock_null", "商品不存在。"),
    STATUS_INCONFORMITY("status_inconformity", "状态不符合。");

    ResponseStatus(String status, String message) {
        this.status = status;
        this.message = message;
    }

    private String status;

    private String message;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

