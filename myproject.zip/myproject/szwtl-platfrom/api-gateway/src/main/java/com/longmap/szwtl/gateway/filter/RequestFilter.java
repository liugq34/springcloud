package com.longmap.szwtl.gateway.filter;

import io.netty.buffer.ByteBufAllocator;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferUtils;
import org.springframework.core.io.buffer.NettyDataBufferFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;
import java.util.AbstractMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;

/**
 * @author Created by oushaohui on 2019/8/26 9:40
 * @description
 **/
public class RequestFilter implements GatewayFilter, Ordered {

    private static Logger logger = LoggerFactory.getLogger(RequestFilter.class);

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest serverHttpRequest = exchange.getRequest();
        logger.info("Host={}", serverHttpRequest.getURI().getHost());
        logger.info("Path={}", serverHttpRequest.getURI().getPath());
        logger.info("Port={}", serverHttpRequest.getURI().getPort() + "");
        // 请求方式
        String method = serverHttpRequest.getMethodValue();
        // 只记录 http 请求(包含 https)
        String schema = serverHttpRequest.getURI().getScheme();
        if ((!"http".equals(schema) && !"https".equals(schema))) {
            return chain.filter(exchange.mutate().request(exchange.getRequest()).build());
        }
        // 获取HttpHeaders
        HttpHeaders httpHeaders = serverHttpRequest.getHeaders();
        Iterator<?> iterator = httpHeaders.entrySet().iterator();
        while (iterator.hasNext()) {
            AbstractMap.SimpleImmutableEntry entry = (AbstractMap.SimpleImmutableEntry) iterator.next();
            logger.info("Key={}", entry.getKey());
            logger.info("Value={}", entry.getValue());
        }
        // GET方法获取参数
        if ("GET".equalsIgnoreCase(method)) {
            // 记录要访问的url
            StringBuilder stringBuilder = new StringBuilder("");
            MultiValueMap<String, String> multiValueMap = serverHttpRequest.getQueryParams();
            for (Map.Entry<String, List<String>> entry : multiValueMap.entrySet()) {
                stringBuilder.append(entry.getKey()).append("=").append(StringUtils.join(entry.getValue(), ",")).append(",");
            }
            logger.info("Request URL={}", stringBuilder.toString());
        } else {
            Object requestBody = exchange.getAttribute("cachedRequestBodyObject");
            logger.info("request body is:{}", requestBody);
        }
        // 封装request，传给下一级
        return chain.filter(exchange.mutate().request(exchange.getRequest()).build());
    }

    /**
     * 获取POST请求参数
     *
     * @param serverHttpRequest
     * @return
     */
    private String requestDataBuffer(ServerHttpRequest serverHttpRequest) {
        // 获取请求体
        Flux<DataBuffer> dataBufferFlux = serverHttpRequest.getBody();
        AtomicReference<String> stringAtomicReference = new AtomicReference<>();
        dataBufferFlux.subscribe(buffer -> {
            CharBuffer charBuffer = StandardCharsets.UTF_8.decode(buffer.asByteBuffer());
            DataBufferUtils.release(buffer);
            stringAtomicReference.set(charBuffer.toString());
        });
        // 获取request body
        return stringAtomicReference.get();
    }

    /**
     * 字符串转换DataBuffer
     *
     * @param value
     * @return
     */
    private DataBuffer buildDataBuffer(String value) {
        byte[] bytes = value.getBytes(StandardCharsets.UTF_8);
        NettyDataBufferFactory nettyDataBufferFactory = new NettyDataBufferFactory(ByteBufAllocator.DEFAULT);
        DataBuffer dataBuffer = nettyDataBufferFactory.allocateBuffer(bytes.length);
        dataBuffer.write(bytes);
        return dataBuffer;
    }

    @Override
    public int getOrder() {
        return 0;
    }
}