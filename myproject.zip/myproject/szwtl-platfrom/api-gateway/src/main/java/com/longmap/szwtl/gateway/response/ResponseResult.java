package com.longmap.szwtl.gateway.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

/**
 * @author:yaohw
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseResult {
    /**
     * 返回状态码
     */
    private String status;

    /**
     * 返回描述
     */
    private String message;
    /**
     * 返回数据
     */
    private Object data;

    public ResponseResult() {
    }

    public ResponseResult(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public ResponseResult(String status, Object data) {
        this.status = status;
        this.data = data;
    }

    public ResponseResult(String status, String message, Object data) {
        this.status = status;
        this.message = message;
        this.data = data;
    }
}
