package com.longmap.szwtl.gateway.fallback;

import com.longmap.szwtl.gateway.response.ResponseResult;
import com.longmap.szwtl.gateway.response.ResponseStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Created by oushaohui on 2019/7/30 15:14
 * @description 授权服务熔断
 **/
@RestController
public class FallbackFactory {
    @GetMapping("/fallback")
    public ResponseResult fallback() {
        ResponseResult responseResult = new ResponseResult();
        responseResult.setStatus(ResponseStatus.SERVICE_OFFLINE.getStatus());
        responseResult.setMessage(ResponseStatus.SERVICE_OFFLINE.getMessage());
        return responseResult;
    }
}
