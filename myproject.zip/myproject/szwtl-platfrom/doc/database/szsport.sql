﻿create table sport_item 
(
   id                   varchar(50)                    null,
   item_code            varchar(10)                    null,
   name                 varchar(50)                    null,
   icon                 varchar(200)                   null,
   sort                 number                         null,
   status               number                         null,
   constraint AK_KEY_1_SPORT_IT unique (id)
);



create table stadium_sportitem 
(
   id                   varchar(50)                    not null,
   enterprise_id        varchar(50)                    null,
   stadium_id           varchar(50)                    null,
   sport_item_code      varchar(10)                    null,
   sport_item_name      varchar(10)                    null,
   occupy_type          integer                        null,
   step                 decimal(2,1)                   null,
   refundtime           integer                        null,
   inoutdoor            integer                        null,
   havelight            integer                        null,
   floor_type           integer                        null,
   weekday_start_time   integer                        null,
   weekday_end_time     integer                        null,
   weekend_start_time   integer                        null,
   weekend_end_time     integer                        null,
   status               integer                        null,
   delflag              integer                        null,
   adduser              varchar(10)                    null,
   addtime              date                           null,
   updatetime           date                           null,
   constraint PK_STADIUM_SPORTITEM primary key clustered (id),
   constraint AK_KEY_2_STADIUM_ unique (id)
);

comment on column stadium_sportitem.occupy_type is 
'1、按步长，2、按早晚，3、按天';

comment on column stadium_sportitem.inoutdoor is 
'室内or室外';

comment on column stadium_sportitem.havelight is 
'是否有灯光';

comment on column stadium_sportitem.floor_type is 
'地板类型';





create table stadium_groundtype 
(
   id                   varchar(50)                    null,
   enterprise_id        varchar(50)                    null,
   stadium_id           varchar(50)                    null,
   stadium_sportitem_id varchar(50)                    null,
   name                 varchar(50)                    null,
   maxperson            integer                        null,
   adduser              varchar(50)                    null,
   addtime              date                           null,
   status               integer                        null,
   delflag              integer                        null,
   constraint AK_KEY_1_STADIUM_ unique (id)
);

comment on column stadium_groundtype.stadium_id is 
'场馆id';

comment on column stadium_groundtype.stadium_sportitem_id is 
'场馆项目id';

comment on column stadium_groundtype.name is 
'场地名称';

comment on column stadium_groundtype.maxperson is 
'最大预定人数';



create table stadium_ground_info 
(
   id                   varchar(50)                    null,
   enterprise_id        varchar(50)                    null,
   stadium_id           varchar(50)                    null,
   stadium_sportitem_id varchar(50)                    null,
   stadium_groundtype_id varchar(50)                   null,
   stadium_name         varchar(50)                    null,
   sport_item_code      varchar(50)                    null,
   stadium_code         integer                        null,
   maxnum               integer                        null,
   status               integer                        null,
   adduser              varchar(50)                    null,
   addtime              date                           null,
   updatetime           date                           null,
   delflag              integer                        null,
   constraint AK_KEY_1_STADIUM_ unique (id)
);

comment on column stadium_ground_info.stadium_id is 
'场馆id';

comment on column stadium_ground_info.stadium_sportitem_id is 
'场馆项目id';

comment on column stadium_ground_info.stadium_groundtype_id is 
'场地信息id';

comment on column stadium_ground_info.stadium_name is 
'场地名称';

comment on column stadium_ground_info.sport_item_code is 
'运动项目编号';

comment on column stadium_ground_info.stadium_code is 
'场地编号';

comment on column stadium_ground_info.maxnum is 
'允许同时预定人数';





create table stadium_sportitem_price_template 
(
   id                   varchar(50)                    null,
   enterprise_id        varchar(50)                    null,
   stadium_id           varchar(50)                    null,
   stadium_sportitem_id varchar(50)                    null,
   name                 varchar(50)                    null,
   weekday_dayprice     decimal(5,2)                   null,
   weekday_dayend_time  integer                        null,
   weekday_nightprice   decimal(5,2)                   null,
   weekend_dayprice     decimal(5,2)                   null,
   weekend_dayend_time  integer                        null,
   weekend_nightprice   decimal(5,2)                   null,
   adduser              varchar(10)                    null,
   addtime              date                           null,
   status               integer                        null,
   delflag              integer                        null,
   constraint AK_KEY_1_STADIUM_ unique (id)
);

comment on column stadium_sportitem_price_template.stadium_id is 
'场馆id';

comment on column stadium_sportitem_price_template.stadium_sportitem_id is 
'场馆运动项目id';

comment on column stadium_sportitem_price_template.name is 
'模板名称';

comment on column stadium_sportitem_price_template.weekday_dayprice is 
'工作日早上价格';

comment on column stadium_sportitem_price_template.weekday_dayend_time is 
'工作日早上截止时间';

comment on column stadium_sportitem_price_template.weekday_nightprice is 
'工作日下午价格';

comment on column stadium_sportitem_price_template.weekend_dayprice is 
'周末早上价格';

comment on column stadium_sportitem_price_template.weekend_dayend_time is 
'周末早上截止时间';

comment on column stadium_sportitem_price_template.weekend_nightprice is 
'周末下午价格';








create table stadium_good_info 
(
   id                   varchar(50)                    null,
   enterprise_id        varchar(50)                    null,
   stadium_id           varchar(50)                    null,
   stadium_sportitem_id varchar(50)                    null,
   stadium_groundtype_id varchar(50)                    null,
   stadium_ground_info_id varchar(50)                    null,
   sport_item_code      varchar(10)                    null,
   good_name            varchar(20)                    null,
   usedate              integer                        null,
   start_time           integer                        null,
   end_time             integer                        null,
   saleprice            decimal(10,2)                  null,
   totalnum             integer                        null,
   remainnum            integer                        null,
   reservednum          integer                        null,
   status               integer                        null,
   delflag              integer                        null,
   constraint AK_KEY_1_STADIUM_ unique (id)
);

comment on column stadium_good_info.stadium_id is 
'场馆id';

comment on column stadium_good_info.stadium_sportitem_id is 
'场馆项目id';

comment on column stadium_good_info.stadium_groundtype_id is 
'场地id';

comment on column stadium_good_info.stadium_ground_info_id is 
'场号id';

comment on column stadium_good_info.sport_item_code is 
'运动项目编号';

comment on column stadium_good_info.good_name is 
'商品名称';

comment on column stadium_good_info.usedate is 
'使用日期';

comment on column stadium_good_info.start_time is 
'开始时间';

comment on column stadium_good_info.end_time is 
'结束时间';





