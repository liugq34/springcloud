--操作日志表
CREATE TABLE sys_log_info(
  id  VARCHAR2(32) NOT NULL,
  method_name VARCHAR2(32) NOT NULL,
  req_url VARCHAR2(64) NOT NULL,
  req_mode VARCHAR2(8) NOT NULL,
  req_params VARCHAR2(1024) NOT NULL,
  req_ip VARCHAR2(32) NOT NULL,
  run_time NUMBER(11) NOT NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
  PRIMARY KEY (id)
);
create index index_create_user on sys_log_info(create_user);
create index index_created_time on sys_log_info(created_time);
COMMENT ON TABLE sys_log_info IS '操作日志表';
COMMENT ON COLUMN sys_log_info.id IS '主键ID';
COMMENT ON COLUMN sys_log_info.method_name IS '方法名称';
COMMENT ON COLUMN sys_log_info.req_url IS '请求url';
COMMENT ON COLUMN sys_log_info.req_mode IS '请求方式';
COMMENT ON COLUMN sys_log_info.req_params IS '请求参数';
COMMENT ON COLUMN sys_log_info.req_ip IS '请求ip';
COMMENT ON COLUMN sys_log_info.run_time IS '运行时间';
COMMENT ON COLUMN sys_log_info.created_time IS '添加时间';
COMMENT ON COLUMN sys_log_info.create_user IS '添加人';
COMMENT ON COLUMN sys_log_info.modified_time IS '修改时间';
COMMENT ON COLUMN sys_log_info.update_user IS '修改人';
COMMENT ON COLUMN sys_log_info.del_flg IS '删除标志（0正常,1删除）';


