--订单信息
CREATE TABLE t_salesorder (
	id VARCHAR2(32) NOT NULL,
	order_no VARCHAR2(32) NOT NULL,
	buyer_id VARCHAR2(32) NOT NULL,
	buyer_nick VARCHAR2(100) NOT NULL,
	buyer_contact VARCHAR2(25) NOT NULL,
	buyer_memo VARCHAR2(255) DEFAULT NULL,
	buyer_message VARCHAR2(255) DEFAULT NULL,
	enterprise_id VARCHAR2(32) NOT NULL,
	store_id VARCHAR2(32) DEFAULT NULL,
	store_name VARCHAR2(50) DEFAULT NULL,
	seller_id VARCHAR2(32) NOT NULL,
	seller_nick VARCHAR2(100) NOT NULL,
	seller_memo VARCHAR2(255) DEFAULT NULL,
	seller_phone VARCHAR2(20) NULL,
	num NUMBER(11) NULL,
	refund_status NUMBER(11) NULL,
	order_status NUMBER(11) DEFAULT 2,
	total_fee NUMBER(10,2) DEFAULT 0,
	order_type NUMBER(11) NOT NULL,
	payment_type NUMBER(11) NULL,
	created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP DEFAULT NULL,
	del_flag NUMBER(11) DEFAULT 0,
	province_id VARCHAR2(32) DEFAULT NULL,
	province_name VARCHAR2(50) DEFAULT NULL,
	city_id VARCHAR2(32) DEFAULT NULL,
	city_name VARCHAR2(50) DEFAULT NULL,
	district_id VARCHAR2(32) DEFAULT NULL,
	district_name VARCHAR2(50) DEFAULT NULL,
	sub_district_id VARCHAR2(32) DEFAULT NULL,
	sub_district_name VARCHAR2(50) DEFAULT NULL,
	access_mode NUMBER(11),
	order_expired NUMBER(11) DEFAULT 0,
	user_delete  NUMBER(11) DEFAULT 0,
	order_source NUMBER(11) DEFAULT 0,
	mail_address VARCHAR2(128) DEFAULT NULL,
	mail_recipient VARCHAR2(100) DEFAULT NULL,
	mail_phone VARCHAR2(25) DEFAULT NULL,
	apply_id VARCHAR2(32) NULL,
	PRIMARY KEY (id)
);
create unique index index_unique_order_no on t_salesorder(order_no);

COMMENT ON TABLE t_salesorder IS '订单信息';
COMMENT ON COLUMN t_salesorder.id IS 'ID';
COMMENT ON COLUMN t_salesorder.order_no IS '订单编号';
COMMENT ON COLUMN t_salesorder.buyer_id IS '买家ID';
COMMENT ON COLUMN t_salesorder.buyer_nick IS '买家昵称';
COMMENT ON COLUMN t_salesorder.buyer_contact IS '买家手机号';
COMMENT ON COLUMN t_salesorder.buyer_memo IS '买家备注';
COMMENT ON COLUMN t_salesorder.buyer_message IS '卖家留言';
COMMENT ON COLUMN t_salesorder.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_salesorder.store_id IS '场馆ID';
COMMENT ON COLUMN t_salesorder.store_name IS '场馆名称';
COMMENT ON COLUMN t_salesorder.seller_id IS '卖家ID';
COMMENT ON COLUMN t_salesorder.seller_nick IS '卖家昵称';
COMMENT ON COLUMN t_salesorder.seller_memo IS '卖家备注';
COMMENT ON COLUMN t_salesorder.seller_phone IS '卖家联系方式';
COMMENT ON COLUMN t_salesorder.num IS '购买数量';
COMMENT ON COLUMN t_salesorder.refund_status IS '退款状态：（1：申请退款；2：卖家确认退款；3：已退款；4：卖家拒绝退款；5：取消）';
COMMENT ON COLUMN t_salesorder.order_status IS '订单状态：（1：未支付；2：已支付；3：已核销；4：取消）';
COMMENT ON COLUMN t_salesorder.total_fee IS '订单总金额';
COMMENT ON COLUMN t_salesorder.order_type IS '订单类型：（1：文化场馆订单；2：体育场馆订单）';
COMMENT ON COLUMN t_salesorder.payment_type IS '支付方式：（1：支付宝；2：微信）';
COMMENT ON COLUMN t_salesorder.created_time IS '创建时间';
COMMENT ON COLUMN t_salesorder.modified_time IS '更新时间';
COMMENT ON COLUMN t_salesorder.del_flag IS '删除状态 0正常 1已删除';
COMMENT ON COLUMN t_salesorder.province_id IS '省编码';
COMMENT ON COLUMN t_salesorder.province_name IS '省名称';
COMMENT ON COLUMN t_salesorder.city_id IS '市编码';
COMMENT ON COLUMN t_salesorder.city_name IS '市名称';
COMMENT ON COLUMN t_salesorder.district_id IS '区域编码';
COMMENT ON COLUMN t_salesorder.district_name IS '区域名称';
COMMENT ON COLUMN t_salesorder.sub_district_id IS '街道编码';
COMMENT ON COLUMN t_salesorder.sub_district_name IS '街道名称';
COMMENT ON COLUMN t_salesorder.access_mode IS '取票方式(1.自取 2.邮寄 3.ALL)';
COMMENT ON COLUMN t_salesorder.order_expired IS '订单过期状态(0:未过期; 1:已过期)';
COMMENT ON COLUMN t_salesorder.user_delete IS '用户删除状态(0:未删除; 1:已删除)';
COMMENT ON COLUMN t_salesorder.order_source IS '订单来源';
COMMENT ON COLUMN t_salesorder.mail_address IS '邮寄地址';
COMMENT ON COLUMN t_salesorder.mail_recipient IS '邮寄收件人';
COMMENT ON COLUMN t_salesorder.mail_phone IS '收件人电话';
COMMENT ON COLUMN t_salesorder.apply_id IS '申请id';


CREATE TABLE t_salesorder_item (
	id VARCHAR2(32) NOT NULL,
	order_id VARCHAR2(32) NOT NULL,
	order_no VARCHAR2(32) NOT NULL,
	product_id VARCHAR2(32) NOT NULL,
	product_name VARCHAR2(32) NOT NULL,
	product_number VARCHAR2(32) NOT NULL,
	num NUMBER(11) NULL,
	price NUMBER(10,2) DEFAULT 0,
	begin_date VARCHAR2(200),
	end_date VARCHAR2(20),
	begin_time VARCHAR2(20),
	end_time VARCHAR2(20),
	created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP DEFAULT NULL,
	del_flag NUMBER(11) DEFAULT 0,
	participate_status NUMBER(11) DEFAULT 0,
	address VARCHAR2(100) NULL,
	picture VARCHAR2(2048) NULL,
	picture_horizontal VARCHAR2(2048) NULL,
	picture_vertical VARCHAR2(2048) NULL,
	PRIMARY KEY (id)
);

create index index_product_number on t_salesorder_item(product_number);

COMMENT ON TABLE t_salesorder_item IS '订单明细信息';
COMMENT ON COLUMN t_salesorder_item.id IS 'ID';
COMMENT ON COLUMN t_salesorder_item.order_id IS '订单ID';
COMMENT ON COLUMN t_salesorder_item.order_no IS '订单编号';
COMMENT ON COLUMN t_salesorder_item.product_id IS '商品ID';
COMMENT ON COLUMN t_salesorder_item.product_name IS '商品名称';
COMMENT ON COLUMN t_salesorder_item.product_number IS '商品编码';
COMMENT ON COLUMN t_salesorder_item.num IS '购买数量';
COMMENT ON COLUMN t_salesorder_item.price IS '订单总金额';
COMMENT ON COLUMN t_salesorder_item.begin_date IS '开始日期';
COMMENT ON COLUMN t_salesorder_item.end_date IS '结束日期';
COMMENT ON COLUMN t_salesorder_item.begin_time IS '开始时间';
COMMENT ON COLUMN t_salesorder_item.end_time IS '结束时间';
COMMENT ON COLUMN t_salesorder_item.created_time IS '创建时间';
COMMENT ON COLUMN t_salesorder_item.modified_time IS '更新时间';
COMMENT ON COLUMN t_salesorder_item.del_flag IS '删除状态 0正常 1已删除';
COMMENT ON COLUMN t_salesorder_item.participate_status IS '参与状态(0:未参加; 1:已参加)';
COMMENT ON COLUMN t_salesorder_item.address IS '地点';
COMMENT ON COLUMN t_salesorder_item.picture_pc IS '图片电脑端';
COMMENT ON COLUMN t_salesorder_item.picture_mc IS '图片移动端';
COMMENT ON COLUMN t_salesorder_item.picture IS '原图';
COMMENT ON COLUMN t_salesorder_item.picture_horizontal IS '横图  13:7';
COMMENT ON COLUMN t_salesorder_item.picture_vertical IS '竖图  5:77';


--交易结果表
CREATE TABLE t_transaction_result (
	transaction_id VARCHAR2(32) NOT NULL,
	transaction_no VARCHAR2(50) NOT NULL,
	transaction_body VARCHAR2(500) NULL,
	out_trade_no VARCHAR2(50) NOT NULL,
	out_trade_body VARCHAR2(500) NOT NULL,
  payment_type VARCHAR2(25) NOT NULL,
	buyer_id VARCHAR2(32) NOT NULL,
	buyer_member_type VARCHAR2(25) NOT NULL,
	buyer_account_no VARCHAR2(50) NULL,
	buyer_account_name VARCHAR2(50) NULL,
	buyer_name VARCHAR2(50) NOT NULL,
	buyer_contact VARCHAR2(25) NOT NULL,
	seller_id VARCHAR2(32) NOT NULL,
	seller_member_type VARCHAR2(25) NOT NULL,
	seller_account_no VARCHAR2(50)  NULL,
	seller_account_name VARCHAR2(50) NULL,
	seller_name VARCHAR2(50) NOT NULL,
	seller_contact VARCHAR2(50) NOT NULL,
	amount NUMBER(10,2) NOT NULL,
	transaction_status VARCHAR2(25) NOT NULL,
	external_number VARCHAR2(256) NULL,
	remark VARCHAR2(256) NULL,
	transaction_time TIMESTAMP DEFAULT sysdate,
	created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP NULL,
	PRIMARY KEY (transaction_id)
);

create unique index index_unique_transaction_no on t_transaction_result(transaction_no);

COMMENT ON TABLE t_transaction_result IS '交易结果表';
COMMENT ON COLUMN t_transaction_result.transaction_id IS '流水ID';
COMMENT ON COLUMN t_transaction_result.transaction_no IS '交易流水号';
COMMENT ON COLUMN t_transaction_result.transaction_body IS '交易凭证(支付成功后返回的交易信息)';
COMMENT ON COLUMN t_transaction_result.out_trade_no IS '原始流水号(订单编号)';
COMMENT ON COLUMN t_transaction_result.out_trade_body IS '原始凭证内容(订单内容)';
COMMENT ON COLUMN t_transaction_result.payment_type IS '支付方式(支付宝支付，微信支付)';
COMMENT ON COLUMN t_transaction_result.buyer_id IS '买家标识';
COMMENT ON COLUMN t_transaction_result.buyer_member_type IS '买家账户类型';
COMMENT ON COLUMN t_transaction_result.buyer_account_no IS '买方资金账号';
COMMENT ON COLUMN t_transaction_result.buyer_account_name IS '买方账号名称';
COMMENT ON COLUMN t_transaction_result.buyer_name IS '买方名称';
COMMENT ON COLUMN t_transaction_result.buyer_contact IS '买方手机号';
COMMENT ON COLUMN t_transaction_result.seller_id IS '卖家标识';
COMMENT ON COLUMN t_transaction_result.seller_member_type IS '卖家账户类型';
COMMENT ON COLUMN t_transaction_result.seller_account_no IS '卖家资金账号';
COMMENT ON COLUMN t_transaction_result.seller_account_name IS '卖家账号名称';
COMMENT ON COLUMN t_transaction_result.seller_contact IS '卖家手机号';
COMMENT ON COLUMN t_transaction_result.amount IS '交易金额';
COMMENT ON COLUMN t_transaction_result.transaction_status IS '交易状态';
COMMENT ON COLUMN t_transaction_result.external_number IS '支付宝 微信 平台流水号';
COMMENT ON COLUMN t_transaction_result.remark IS '备注';
COMMENT ON COLUMN t_transaction_result.transaction_time IS '交易时间';
COMMENT ON COLUMN t_transaction_result.created_time IS '创建时间';
COMMENT ON COLUMN t_transaction_result.modified_time IS '修改时间';

--操作日志表
CREATE TABLE sys_log_info(
  id  VARCHAR2(32) NOT NULL,
  method_name VARCHAR2(32) NOT NULL,
  req_url VARCHAR2(2048) NOT NULL,
  req_mode VARCHAR2(8) NOT NULL,
  req_params CLOB NOT NULL,
  req_ip VARCHAR2(32) NOT NULL,
  run_time NUMBER(11) NOT NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
  PRIMARY KEY (id)
);
create index index_create_user on sys_log_info(create_user);
create index index_created_time on sys_log_info(created_time);

COMMENT ON TABLE sys_log_info IS '操作日志表';
COMMENT ON COLUMN sys_log_info.id IS '主键ID';
COMMENT ON COLUMN sys_log_info.method_name IS '方法名称';
COMMENT ON COLUMN sys_log_info.req_url IS '请求url';
COMMENT ON COLUMN sys_log_info.req_mode IS '请求方式';
COMMENT ON COLUMN sys_log_info.req_params IS '请求参数';
COMMENT ON COLUMN sys_log_info.req_ip IS '请求ip';
COMMENT ON COLUMN sys_log_info.run_time IS '运行时间';
COMMENT ON COLUMN sys_log_info.created_time IS '添加时间';
COMMENT ON COLUMN sys_log_info.create_user IS '添加人';
COMMENT ON COLUMN sys_log_info.modified_time IS '修改时间';
COMMENT ON COLUMN sys_log_info.update_user IS '修改人';
COMMENT ON COLUMN sys_log_info.del_flg IS '删除标志（0正常,1删除）';