--新闻信息表
CREATE TABLE t_news_info(
  id VARCHAR2(32) NOT NULL,
  title VARCHAR2(64) NOT NULL,
  type NUMBER(11) NOT NULL,
	details CLOB NOT NULL,
	is_hot NUMBER(11)  DEFAULT 2,
	sticky_post NUMBER(11)  DEFAULT 1,
	picture    VARCHAR2(1024)  NULL,
	picture_horizontal VARCHAR2(1024)  NULL,
	picture_vertical VARCHAR2(1024)  NULL,
	Is_File NUMBER(11) DEFAULT 1,
	release_time timestamp NOT NULL,
	release_name VARCHAR2(16)  NOT NULL,
	release_status NUMBER(11) DEFAULT 1,
	putaway_status NUMBER(11) DEFAULT 1,
	source VARCHAR2(32)  NOT NULL,
	click_num NUMBER(11)  DEFAULT 0,
  enterprise_id VARCHAR2(32)  NOT NULL,
  store_id VARCHAR2(32)  NOT NULL,
  city_id VARCHAR2(32) NULL,
	city_name VARCHAR2(50) NULL,
	district_id VARCHAR2(32 NULL,
	district_name VARCHAR2(50) NULL,
	province_id VARCHAR2(32) NULL,
	province_name VARCHAR2(50) NULL,
	sub_district_id VARCHAR2 DEFAULT NULL,
  sub_district_name VARCHAR2(50) DEFAULT NULL,
	remark VARCHAR2(128) NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
  PRIMARY KEY (id)
);

create index index_release_time on t_news_info(release_time);
create index index_type on news_info(type);
COMMENT ON TABLE t_news_info IS '新闻信息表';
COMMENT ON COLUMN t_news_info.id IS '主键ID';
COMMENT ON COLUMN t_news_info.title IS '新闻标题';
COMMENT ON COLUMN t_news_info.type IS '类型：1文化新闻，2体育新闻，3旅游新闻';
COMMENT ON COLUMN t_news_info.IS_HOT IS '热门新闻：1是2否';
COMMENT ON COLUMN t_news_info.sticky_post IS '置顶标志：1否，2是';
COMMENT ON COLUMN t_news_info.details IS '内容详情';
COMMENT ON COLUMN t_news_info.picture IS ' 原图';
COMMENT ON COLUMN t_news_info.picture_horizontal IS '横图  13:7';
COMMENT ON COLUMN t_news_info.picture_vertical IS '竖图 5:7';
COMMENT ON COLUMN t_news_info.Is_File IS '是否有图片或视频文件，1无：2有';
COMMENT ON COLUMN t_news_info.release_time IS '发布日期';
COMMENT ON COLUMN t_news_info.release_name IS '发布人';
COMMENT ON COLUMN t_news_info.release_status IS '1：待提交 2：待审核  4：未通过 3：已通过';
COMMENT ON COLUMN t_news_info.putaway_status IS '上架状态：1下架，0上架';
COMMENT ON COLUMN t_news_info.source IS '来源';
COMMENT ON COLUMN t_news_info.click_num IS '点击数';
COMMENT ON COLUMN t_news_info.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_news_info.store_id IS '门店ID';
COMMENT ON COLUMN t_news_info.city_id IS '市编码';
COMMENT ON COLUMN t_news_info.city_name IS '市名称';
COMMENT ON COLUMN t_news_info.district_id IS '区域编码';
COMMENT ON COLUMN t_news_info.district_name IS '区域名称';
COMMENT ON COLUMN t_news_info.sub_district_id IS '街道编码';
COMMENT ON COLUMN t_news_info.sub_district_name IS '街道名称';
COMMENT ON COLUMN t_news_info.province_id IS '省编码';
COMMENT ON COLUMN t_news_info.province_name IS '省名称';
COMMENT ON COLUMN t_news_info.remark IS '备注';
COMMENT ON COLUMN t_news_info.created_time IS '添加时间';
COMMENT ON COLUMN t_news_info.create_user IS '添加人';
COMMENT ON COLUMN t_news_info.modified_time IS '修改时间';
COMMENT ON COLUMN t_news_info.update_user IS '修改人';
COMMENT ON COLUMN t_news_info.del_flg IS '删除标志（0正常,1删除）';


--新闻阅读记录表
CREATE TABLE t_news_read_record(
  id VARCHAR2(32) NOT NULL,
  news_id VARCHAR2(32) NOT NULL,
  title VARCHAR2(64) NOT NULL,
  type NUMBER(11) NOT NULL,
  req_terminal NUMBER(11) NULL,
  req_ip VARCHAR2(16) NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
  PRIMARY KEY (id)
);
create index index_news_id on news_read_record(news_id);
create index index_type on news_read_record(type);
COMMENT ON TABLE t_news_read_record IS '新闻阅读记录表';
COMMENT ON COLUMN t_news_read_record.id IS '主键ID';
COMMENT ON COLUMN t_news_read_record.news_id IS '新闻ID';
COMMENT ON COLUMN t_news_read_record.title IS '新闻标题';
COMMENT ON COLUMN t_news_read_record.type IS '类型：1文化新闻，2体育新闻，3旅游新闻';
COMMENT ON COLUMN t_news_read_record.req_terminal IS '请求终端：1PC,2android,3ios,4其他';
COMMENT ON COLUMN t_news_read_record.req_ip IS '请求ip';
COMMENT ON COLUMN t_news_read_record.created_time IS '添加时间';
COMMENT ON COLUMN t_news_read_record.create_user IS '添加人';
COMMENT ON COLUMN t_news_read_record.modified_time IS '修改时间';
COMMENT ON COLUMN t_news_read_record.update_user IS '修改人';
COMMENT ON COLUMN t_news_read_record.del_flg IS '删除标志（0正常,1删除）';


--操作日志表
CREATE TABLE sys_log_info(
  id  VARCHAR2(32) NOT NULL,
  method_name VARCHAR2(32) NOT NULL,
  req_url VARCHAR2(64) NOT NULL,
  req_mode VARCHAR2(8) NOT NULL,
  req_params VARCHAR2(1024) NOT NULL,
  req_ip VARCHAR2(32) NOT NULL,
  run_time NUMBER(11) NOT NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
  PRIMARY KEY (id)
);
create index index_create_user on sys_log_info(create_user);
create index index_created_time on sys_log_info(created_time);
COMMENT ON TABLE sys_log_info IS '操作日志表';
COMMENT ON COLUMN sys_log_info.id IS '主键ID';
COMMENT ON COLUMN sys_log_info.method_name IS '方法名称';
COMMENT ON COLUMN sys_log_info.req_url IS '请求url';
COMMENT ON COLUMN sys_log_info.req_mode IS '请求方式';
COMMENT ON COLUMN sys_log_info.req_params IS '请求参数';
COMMENT ON COLUMN sys_log_info.req_ip IS '请求ip';
COMMENT ON COLUMN sys_log_info.run_time IS '运行时间';
COMMENT ON COLUMN sys_log_info.created_time IS '添加时间';
COMMENT ON COLUMN sys_log_info.create_user IS '添加人';
COMMENT ON COLUMN sys_log_info.modified_time IS '修改时间';
COMMENT ON COLUMN sys_log_info.update_user IS '修改人';
COMMENT ON COLUMN sys_log_info.del_flg IS '删除标志（0正常,1删除）';


  CREATE TABLE t_news_audit_log (
   ID VARCHAR2(32) NOT NULL,
	BUSINESS_ID VARCHAR2(32 BYTE),
	ROLLBACK_REASON VARCHAR2(255 BYTE),
	MODIFIED_SUGGEST VARCHAR2(255 BYTE),
	AUDIT_STATUS NUMBER(2,0) DEFAULT 1,
	CREATE_USER VARCHAR2(32 BYTE),
	CREATE_USER_NAMME VARCHAR2(32 BYTE),
	CREATE_TIME TIMESTAMP (6),
  PRIMARY KEY (ID)
  )

   --新闻审核记录
   create index index_BUSINESS_ID on t_news_audit_log(BUSINESS_ID);
   COMMENT ON TABLE t_news_audit_log  IS '审核记录表';
   COMMENT ON COLUMN t_news_audit_log."ID" IS 'ID';
   COMMENT ON COLUMN t_news_audit_log."BUSINESS_ID" IS '对应业务表ID';
   COMMENT ON COLUMN t_news_audit_log."ROLLBACK_REASON" IS '回退原因';
   COMMENT ON COLUMN t_news_audit_log."MODIFIED_SUGGEST" IS '修改建议';
   COMMENT ON COLUMN t_news_audit_log."AUDIT_STATUS" IS '审核状态（1：待提交 2：待审核  4：未通过 3：已通过 ）';
   COMMENT ON COLUMN t_news_audit_log."CREATE_TIME" IS '创建时间';
   COMMENT ON COLUMN t_news_audit_log."CREATE_USER_NAMME" IS '创建人名称';
   COMMENT ON COLUMN t_news_audit_log."CREATE_USER" IS '创建人';