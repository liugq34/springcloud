﻿--活动基本信息表
CREATE TABLE t_activity_info (
	activity_id VARCHAR2(32) NOT NULL,
	picture VARCHAR2(2048) NOT NULL,
	picture_horizontal VARCHAR2(2048) NOT NULL,
	picture_vertical VARCHAR2(2048) NOT NULL,
	activity_name VARCHAR2(128) NOT NULL,
	activity_type number(5) NULL,
	activity_class number(5) NOT NULL,
	moviesType number(5) null,
	enterprise_id VARCHAR2(32) NULL,
	store_id VARCHAR2(32) NULL,
	store_name VARCHAR2(128) NULL,
	location VARCHAR2(32) NULL,
	street VARCHAR2(100) NULL,
	address VARCHAR2(100) NULL,
	longitude VARCHAR2(50) NOT NULL,
	latitude VARCHAR2(50) NOT NULL,
	years VARCHAR2(20) NOT NULL,
	months VARCHAR2(20) NOT NULL,
	begin_date VARCHAR2(20) NOT NULL,
	end_date VARCHAR2(20)   NULL,
	begin_time VARCHAR2(20) NOT NULL,
	end_time VARCHAR2(10) NOT NULL,
	reserve_status number(5) DEFAULT 0,
	reserve_max number(5) DEFAULT 0,
	reserve_bedate VARCHAR2(20) NULL,
	reserve_endate VARCHAR2(20)   NULL,
	reserve_betime VARCHAR2(20) NOT NULL,
	reserve_entime VARCHAR2(10) NOT NULL,
	time_notes  VARCHAR2(256)  NULL,
	appoint_type  number(5) NOT NULL,
	ticket_remainder  number(5)  DEFAULT 0,
	ticket_appointed  number(5)  DEFAULT 0,
 	ticket_fee  number(4,2)   NULL,
	ticket_tips VARCHAR2(2048) NULL,
	sponsor  VARCHAR2(256) NULL,
	organizer  VARCHAR2(256) NULL,
	linkman VARCHAR2(50) NULL,
	phone VARCHAR2(20) NULL,
	email VARCHAR2(20) NULL,
	activity_title VARCHAR2(256) NULL,
	warm_point VARCHAR2(256) NULL,
	join_type number(5) DEFAULT 0,
	remark VARCHAR2(256) NULL,
	keywords VARCHAR2(50) NULL,
	introduce CLOB NOT NULL,
	status  number(5) DEFAULT 1,
	auditman VARCHAR2(128) NULL,
	audit_time VARCHAR2(20) NULL,
	audit_status number(5) DEFAULT 0,
	audit_remark VARCHAR2(256) NULL,
	access_mode number(5) DEFAULT 1,
	access_mode_address VARCHAR2(100) NULL,
	hot_num number(5)  DEFAULT 0,
	recommand_type number(5) DEFAULT 0,
	del_flag number(11) DEFAULT 0,
	create_user_id VARCHAR2(32) NOT NULL,
	create_user VARCHAR2(32) NOT NULL,
	create_user_venue_id VARCHAR2(32) NOT NULL,
	create_user_venue VARCHAR2(32) NOT NULL,
	create_user_enterprise_id VARCHAR2(32) NOT NULL,
	create_enterprise VARCHAR2(32) NOT NULL,
	created_time TIMESTAMP NOT NULL,
	update_user VARCHAR2(32) NULL,
	modified_time TIMESTAMP NULL,
	source number(5) DEFAULT 0,
	province_id VARCHAR2(32) NULL,
	province_name VARCHAR2(50) NULL,
	city_id VARCHAR2(32) NULL,
	city_name VARCHAR2(50) NULL,
	district_id VARCHAR2(32) NULL,
	district_name VARCHAR2(50) NULL,
	sub_district_id VARCHAR2(32) DEFAULT NULL,
  sub_district_name VARCHAR2(50) DEFAULT NULL,
  sub_district_name VARCHAR2(50) DEFAULT NULL,
  activity_product_number VARCHAR2(32) NULL,
  send_status number(5) NULL
	PRIMARY KEY (activity_id)
);

create index index_activity_name on t_activity_info(activity_name);
create index index_unique_years on t_activity_info(years);
create index index_unique_months on t_activity_info(months);

COMMENT ON TABLE t_activity_info IS '活动信息表';
COMMENT ON COLUMN t_activity_info.activity_id IS '主键ID';
COMMENT ON COLUMN t_activity_info.picture IS '原图';
COMMENT ON COLUMN t_activity_info.picture_horizontal IS '横图  13:7';
COMMENT ON COLUMN t_activity_info.picture_vertical IS '竖图  5:7';
COMMENT ON COLUMN t_activity_info.activity_name IS '活动名称';
COMMENT ON COLUMN t_activity_info.activity_type IS '活动类型';
COMMENT ON COLUMN t_activity_info.activity_class IS '活动类别';
COMMENT ON COLUMN t_activity_info.moviesType IS '活动影视类型，1.公益 2.商业';
COMMENT ON COLUMN t_activity_info.enterprise_id IS '企业id';
COMMENT ON COLUMN t_activity_info.store_id IS '场馆ID';
COMMENT ON COLUMN t_activity_info.store_name IS '场馆名称';
COMMENT ON COLUMN t_activity_info.location IS '所在区';
COMMENT ON COLUMN t_activity_info.street IS '街道';
COMMENT ON COLUMN t_activity_info.address IS '活动地点';
COMMENT ON COLUMN t_activity_info.longitude IS '经度';
COMMENT ON COLUMN t_activity_info.latitude IS '维度';
COMMENT ON COLUMN t_activity_info.years IS '年份';
COMMENT ON COLUMN t_activity_info.months IS '月份';
COMMENT ON COLUMN t_activity_info.begin_date IS '开始日期(格式:yyyy-MM-dd)';
COMMENT ON COLUMN t_activity_info.end_date IS '结束日期(格式:yyyy-MM-dd)';
COMMENT ON COLUMN t_activity_info.begin_time IS '开始时间(格式:HH:mm)';
COMMENT ON COLUMN t_activity_info.end_time IS '结束时间(格式:HH:mm)';
COMMENT ON COLUMN t_activity_info.reserve_status IS '是否需要预定0.不需要 1.需要';
COMMENT ON COLUMN t_activity_info.reserve_max IS '一次性允许最大预定人数';
COMMENT ON COLUMN t_activity_info.reserve_bedate IS '预定日期(格式:yyyy-MM-dd)';
COMMENT ON COLUMN t_activity_info.reserve_endate IS '预定日期(格式:yyyy-MM-dd)';
COMMENT ON COLUMN t_activity_info.reserve_betime IS '预定时间(格式:HH:mm)';
COMMENT ON COLUMN t_activity_info.reserve_entime IS '预定时间(格式:HH:mm)';
COMMENT ON COLUMN t_activity_info.time_notes IS '时间说明';
COMMENT ON COLUMN t_activity_info.appoint_type IS '预定类型';
COMMENT ON COLUMN t_activity_info.ticket_remainder IS '剩余门票数量';
COMMENT ON COLUMN t_activity_info.ticket_appointed IS '已预订门票数量';
COMMENT ON COLUMN t_activity_info.ticket_fee IS '门票价格';
COMMENT ON COLUMN t_activity_info.ticket_tips IS '预订提示';
COMMENT ON COLUMN t_activity_info.sponsor IS '主办方';
COMMENT ON COLUMN t_activity_info.organizer IS '承办方';
COMMENT ON COLUMN t_activity_info.linkman IS '联系人';
COMMENT ON COLUMN t_activity_info.phone IS '联系方式';
COMMENT ON COLUMN t_activity_info.email IS '联系email';
COMMENT ON COLUMN t_activity_info.activity_title IS '活动简述';
COMMENT ON COLUMN t_activity_info.warm_point IS '温馨提示';
COMMENT ON COLUMN t_activity_info.join_type IS '参与方式';
COMMENT ON COLUMN t_activity_info.remark IS '备注';
COMMENT ON COLUMN t_activity_info.introduce IS '活动详情';
COMMENT ON COLUMN t_activity_info.keywords IS '活动关键字';
COMMENT ON COLUMN t_activity_info.status IS '活动状态(0:正常; 1:下架)';
COMMENT ON COLUMN t_activity_info.auditman IS '审核人';
COMMENT ON COLUMN t_activity_info.audit_time IS '审核时间';
COMMENT ON COLUMN t_activity_info.audit_remark IS '审核备注';
COMMENT ON COLUMN t_activity_info.audit_status IS '审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)';
COMMENT ON COLUMN t_activity_info.access_mode IS '允许取件方式，支持多种选择，（订单只能选取一个）1.自取 2.邮寄 3.ALL';
COMMENT ON COLUMN t_activity_info.access_mode_address IS '用于取票方式的自取，填写取票地址';
COMMENT ON COLUMN t_activity_info.hot_num IS '热度';
COMMENT ON COLUMN t_activity_info.recommand_type IS '推荐热门';
COMMENT ON COLUMN t_activity_info.del_flag IS '删除状态(0:正常; 1:已删除)';
COMMENT ON COLUMN t_activity_info.create_user_id IS '创建人ID';
COMMENT ON COLUMN t_activity_info.create_user IS '创建人';
COMMENT ON COLUMN t_activity_info.create_user_venue_id IS '创建人场馆ID';
COMMENT ON COLUMN t_activity_info.create_user_venue IS '创建人场馆名称';
COMMENT ON COLUMN t_activity_info.create_user_enterprise_id IS '创建人企业ID';
COMMENT ON COLUMN t_activity_info.create_enterprise IS '创建人企业名称';
COMMENT ON COLUMN t_activity_info.created_time IS '创建时间';
COMMENT ON COLUMN t_activity_info.update_user IS '修改人';
COMMENT ON COLUMN t_activity_info.modified_time IS '修改时间';
COMMENT ON COLUMN t_activity_info.source IS '活动来源';
COMMENT ON COLUMN t_activity_info.province_id IS '省编码';
COMMENT ON COLUMN t_activity_info.province_name IS '省名称';
COMMENT ON COLUMN t_activity_info.city_id IS '市编码';
COMMENT ON COLUMN t_activity_info.city_name IS '市名称';
COMMENT ON COLUMN t_activity_info.district_id IS '区域编码';
COMMENT ON COLUMN t_activity_info.district_name IS '区域名称';
COMMENT ON COLUMN t_activity_info.sub_district_id IS '街道编码';
COMMENT ON COLUMN t_activity_info.sub_district_name IS '街道名称';
COMMENT ON COLUMN t_activity_info.activity_product_number IS '活动Id(用于对接)';
COMMENT ON COLUMN t_activity_info.send_status IS '是否发送， 0.未发送 1.发送';

--活动评论表
CREATE TABLE t_activity_comment (
    commentid VARCHAR2(32) NOT NULL,
    activityInfoid VARCHAR2(32) NOT NULL,
    userid VARCHAR2(32) NOT NULL,
    username VARCHAR2(32) NOT NULL,
    anonymous NUMBER(11) DEFAULT 0,
    starrating NUMBER(11) DEFAULT 5,
    content VARCHAR2(256) NULL,
    picturepath VARCHAR2(128) NULL,
    created_time TIMESTAMP NOT NULL,
    PRIMARY KEY (commentid)
);

create index index_activityInfoid on t_activity_comment(activityInfoid);
create index index_activityInfoid_userid on t_activity_comment(activityInfoid,userid);

COMMENT ON TABLE t_activity_comment IS '活动评论表';
COMMENT ON COLUMN t_activity_comment.commentid IS '主键ID';
COMMENT ON COLUMN t_activity_comment.activityInfoid IS '活动ID';
COMMENT ON COLUMN t_activity_comment.userid IS '用户ID';
COMMENT ON COLUMN t_activity_comment.username IS '用户名称';
COMMENT ON COLUMN t_activity_comment.anonymous IS '是否匿名（0.否1.是）';
COMMENT ON COLUMN t_activity_comment.starrating IS '评价（1.一星 2.二星 ...5.五星）';
COMMENT ON COLUMN t_activity_comment.content IS '评论内容';
COMMENT ON COLUMN t_activity_comment.picturepath IS '图片路径';
COMMENT ON COLUMN t_activity_comment.created_time IS '创建时间';


---------------------------------------------------------------
-------------------------------------数字字典（没有使用）------------------
---------------------------------------------------------------

--系统数字字典
CREATE TABLE t_sys_code (
	id VARCHAR2(32) NOT NULL,
	sys_code_name VARCHAR2(32) NOT NULL,
	add_child NUMBER(11) DEFAULT 0,
	sort_num VARCHAR2(32) NOT NULL,
	remark VARCHAR2(32) NOT NULL,
	record VARCHAR2(32) NOT NULL,
	created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP DEFAULT NULL,
	del_flag NUMBER(11) DEFAULT 0,
	PRIMARY KEY (id)
);
create unique index index_unique_sys_code_name on t_sys_code(sys_code_name);

COMMENT ON TABLE t_sys_code IS '系统数字字典';
COMMENT ON COLUMN t_sys_code.id IS 'ID';
COMMENT ON COLUMN t_sys_code.sys_code_name IS '名称';
COMMENT ON COLUMN t_sys_code.add_child IS '添加子项（0.不添加，1.添加）';
COMMENT ON COLUMN t_sys_code.sort_num IS '排序';
COMMENT ON COLUMN t_sys_code.remark IS '备注信息';
COMMENT ON COLUMN t_sys_code.record IS '记录';
COMMENT ON COLUMN t_sys_code.created_time IS '创建时间';
COMMENT ON COLUMN t_salesorder_item.modified_time IS '更新时间';
COMMENT ON COLUMN t_salesorder_item.del_flag IS '删除状态 0正常 1已删除';

--系统数字字典子表
CREATE TABLE t_sys_code_item (
	id VARCHAR2(32) NOT NULL,
	sys_code_name VARCHAR2(32) NOT NULL,
	parent_id VARCHAR2(32) NOT NULL,
	sys_code_id VARCHAR2(32) NOT NULL,
	is_add_child NUMBER(11) DEFAULT 0,
	sort_num VARCHAR2(32) NOT NULL,
	remark VARCHAR2(32) NOT NULL,
	record VARCHAR2(32) NOT NULL,
	levels NUMBER(32) DEFAULT 1,
	created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP DEFAULT NULL,
	del_flag NUMBER(11) DEFAULT 0,
	PRIMARY KEY (id)
);
create unique index index_unique_sys_code_name on t_sys_code_item(sys_code_name);

COMMENT ON TABLE t_sys_code_items IS '系统数字字典子项目';
COMMENT ON COLUMN t_sys_code_item.id IS 'ID';
COMMENT ON COLUMN t_sys_code_item.sys_code_name IS '名称';
COMMENT ON COLUMN t_sys_code_item.parent_id IS '父级id';
COMMENT ON COLUMN t_sys_code_item.sys_code_id IS '系统数字字典主表id';
COMMENT ON COLUMN t_sys_code_item.is_add_child IS '添加子项（0.不添加，1.添加）';
COMMENT ON COLUMN t_sys_code_item.sort_num IS '排序';
COMMENT ON COLUMN t_sys_code_item.remark IS '备注信息';
COMMENT ON COLUMN t_sys_code_item.record IS '记录';
COMMENT ON COLUMN t_sys_code_item.levels IS '级别';
COMMENT ON COLUMN t_sys_code_item.created_time IS '创建时间';
COMMENT ON COLUMN t_sys_code_item.modified_time IS '更新时间';
COMMENT ON COLUMN t_sys_code_item.del_flag IS '删除状态 0正常 1已删除';

---------------------------------------------------------------
-------------------------------------场馆部分------------------
---------------------------------------------------------------


--场馆信息表
CREATE TABLE t_venue_info (
  venue_id VARCHAR2(32) NOT NULL,
	picture_pc VARCHAR2(2048) NOT NULL,
	picture_mc VARCHAR2(2048) NOT NULL,
	venue_name VARCHAR2(128) NOT NULL,
	venue_type number(5) NOT NULL,
	venue_class number(5) NOT NULL,
  location VARCHAR2(32) NULL,
  street VARCHAR2(100) NULL,
  address VARCHAR2(100) NOT NULL,
  longitude VARCHAR2(50) NOT NULL,
	latitude VARCHAR2(50) NOT NULL,
	reserve_status  number(5) DEFAULT 1,
  ticket_tips VARCHAR2(256) NULL,
	linkman VARCHAR2(50) NULL,
  phone VARCHAR2(20) NULL,
  warm_point VARCHAR2(256) NULL,
  open_time VARCHAR2(256) NOT NULL,
  introduce CLOB NOT NULL,
  remark VARCHAR2(256) NULL,
  status  number(5) DEFAULT 1,
  hot_num number(5)  DEFAULT 0,
	recommand_type number(5) DEFAULT 0,
  auditman VARCHAR2(128) NULL,
	audit_time VARCHAR2(20) NULL,
	audit_status number(5) DEFAULT 0,
	audit_remark VARCHAR2(256) NULL,
  del_flag number(5) DEFAULT 0,
  create_user_id VARCHAR2(32) NULL,
  create_user VARCHAR2(128) NULL,
  created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP NULL,
	enterpriseId VARCHAR2(32),
	province_id VARCHAR2(32) NULL,
	province_name VARCHAR2(50) NULL,
	city_id VARCHAR2(32) NULL,
	city_name VARCHAR2(50) NULL,
	district_id VARCHAR2(32) NULL,
	district_name VARCHAR2(50) NULL,
	sub_district_id VARCHAR2(32) DEFAULT NULL,
  sub_district_name VARCHAR2(50) DEFAULT NULL,
  institution_code VARCHAR2(50) NOT NULL,
  unit_nature VARCHAR2(50) NOT NULL,
  legal_representative VARCHAR2(50) NOT NULL,
  legal_representative_phone VARCHAR2(50) NOT NULL,
  person_in_charge VARCHAR2(50) NOT NULL,
  person_in_charge_phone VARCHAR2(50) NOT NULL,
  competent_department_type number(5) NOT NULL,
  facility_area VARCHAR2(50) NULL,
  completion_time VARCHAR2(50) NULL,
  land_area VARCHAR2(50) NULL,
  built_up_area VARCHAR2(50) NULL,
  site_area VARCHAR2(50) NULL,
  operational_model VARCHAR2(50) NULL,
  sources_funds VARCHAR2(50) NULL,
  employees_num VARCHAR2(50) NULL,
  brief_introduction VARCHAR2(1024) NULL,
  venue_product_number VARCHAR2(32) NULL,
  send_status number(5) NUll;
  PRIMARY KEY (venue_id)
);

create unique index index_unique_venue_name on t_venue_info(venue_name);

COMMENT ON TABLE t_venue_info IS '场馆信息表';
COMMENT ON COLUMN t_venue_info.venue_id IS '主键ID';
COMMENT ON COLUMN t_venue_info.picture_pc IS '场馆图片电脑（滚动图片）';
COMMENT ON COLUMN t_venue_info.picture_mc IS '场馆图片手机（滚动图片）';
COMMENT ON COLUMN t_venue_info.venue_name IS '场馆名称';
COMMENT ON COLUMN t_venue_info.venue_type IS '场馆类型';
COMMENT ON COLUMN t_venue_info.venue_class IS '场馆类别';
COMMENT ON COLUMN t_venue_info.location IS '所在区';
COMMENT ON COLUMN t_venue_info.street IS '街道';
COMMENT ON COLUMN t_venue_info.address IS '场馆地点';
COMMENT ON COLUMN t_venue_info.longitude IS '经度';
COMMENT ON COLUMN t_venue_info.latitude IS '维度';
COMMENT ON COLUMN t_venue_info.reserve_status IS '是否可以预定（0.不可预定，1.可以预定）';
COMMENT ON COLUMN t_venue_info.ticket_tips IS '预订提示';
COMMENT ON COLUMN t_venue_info.linkman IS '联系人';
COMMENT ON COLUMN t_venue_info.phone IS '联系方式';
COMMENT ON COLUMN t_venue_info.warm_point IS '温馨提示';
COMMENT ON COLUMN t_venue_info.open_time IS '开放时间';
COMMENT ON COLUMN t_venue_info.introduce IS '场馆详情';
COMMENT ON COLUMN t_venue_info.remark IS '备注';
COMMENT ON COLUMN t_venue_info.status IS '场馆状态(0:正常; 1:下架)';
COMMENT ON COLUMN t_venue_info.hot_num IS '热度';
COMMENT ON COLUMN t_venue_info.recommand_type IS '推荐热门';
COMMENT ON COLUMN t_venue_info.auditman IS '审核人';
COMMENT ON COLUMN t_venue_info.audit_time IS '审核时间';
COMMENT ON COLUMN t_venue_info.audit_remark IS '审核备注';
COMMENT ON COLUMN t_venue_info.audit_status IS '审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)';
COMMENT ON COLUMN t_venue_info.del_flag IS '删除状态(0:正常; 1:已删除)';
COMMENT ON COLUMN t_venue_info.create_user_id IS '创建人ID';
COMMENT ON COLUMN t_venue_info.create_user IS '创建人';
COMMENT ON COLUMN t_venue_info.created_time IS '创建时间';
COMMENT ON COLUMN t_venue_info.modified_time IS '修改时间';
COMMENT ON COLUMN t_venue_info.enterpriseId IS '企业ID';
COMMENT ON COLUMN t_venue_info.province_id IS '省编码';
COMMENT ON COLUMN t_venue_info.province_name IS '省名称';
COMMENT ON COLUMN t_venue_info.city_id IS '市编码';
COMMENT ON COLUMN t_venue_info.city_name IS '市名称';
COMMENT ON COLUMN t_venue_info.district_id IS '区域编码';
COMMENT ON COLUMN t_venue_info.district_name IS '区域名称';
COMMENT ON COLUMN t_venue_info.sub_district_id IS '街道编码';
COMMENT ON COLUMN t_venue_info.sub_district_name IS '街道名称';
COMMENT ON COLUMN t_venue_info.institution_code IS '机构代码';
COMMENT ON COLUMN t_venue_info.unit_nature IS '单位性质';
COMMENT ON COLUMN t_venue_info.legal_representative IS '法人代表';
COMMENT ON COLUMN t_venue_info.legal_representative_phone IS '法人代表联系电话';
COMMENT ON COLUMN t_venue_info.person_in_charge IS '负责人';
COMMENT ON COLUMN t_venue_info.person_in_charge_phone IS '负责人电话';
COMMENT ON COLUMN t_venue_info.competent_department_type IS '主管部门';
COMMENT ON COLUMN t_venue_info.facility_area IS '设施面积';
COMMENT ON COLUMN t_venue_info.completion_time IS '建成时间';
COMMENT ON COLUMN t_venue_info.land_area IS '用地面积';
COMMENT ON COLUMN t_venue_info.built_up_area IS '建筑面积';
COMMENT ON COLUMN t_venue_info.site_area IS '场地面积';
COMMENT ON COLUMN t_venue_info.operational_model IS '运营模式';
COMMENT ON COLUMN t_venue_info.sources_funds IS '经费来源';
COMMENT ON COLUMN t_venue_info.employees_num IS '员工人数';
COMMENT ON COLUMN t_venue_info.brief_introduction IS '场馆简介';
COMMENT ON COLUMN t_activity_info.venue_product_number IS '场馆Id(用于对接)';
COMMENT ON COLUMN t_activity_info.send_status IS '是否发送， 0.未发送 1.发送';


--场馆活动室信息表
CREATE TABLE t_field(
  field_id VARCHAR2(32) NOT NULL,
  field_name VARCHAR2(128) NOT NULL,
  field_num VARCHAR2(128) NOT NULL,
  field_type_id VARCHAR2(32) NOT NULL,
  field_type_name VARCHAR2(32) NOT NULL,
  picture_pc VARCHAR2(2048) NOT NULL,
	picture_mc VARCHAR2(2048) NOT NULL,
  venue_id VARCHAR2(32) NOT NULL,
  venue_name VARCHAR2(128) NOT NULL,
  enterprise_id varchar2(32) null,
  field_introduce VARCHAR2(2048) NULL,
  field_device VARCHAR2(1024) NULL,
  field_function VARCHAR2(1024) NULL,
  field_open_time VARCHAR2(1024) NULL,
  max_contain_people number(11) NULL,
  field_status number(5) DEFAULT 1,
  audit_type number(5) DEFAULT 1,
  del_flag NUMBER(5) DEFAULT 0,
  PRIMARY KEY (field_id)
);

create index index_unique_field_name on t_field(field_name);
create index index_venue_id on t_field(venue_id);
create index index_venue_name on t_field(venue_name);

COMMENT ON TABLE t_field IS '场馆活动室信息表';
COMMENT ON COLUMN t_field.field_id IS '场馆活动室主键ID';
COMMENT ON COLUMN t_field.field_name IS '场馆活动室名称';
COMMENT ON COLUMN t_field.field_num IS '场馆活动室编号';
COMMENT ON COLUMN t_field.field_type_id IS '类别ID';
COMMENT ON COLUMN t_field.field_type_name IS '类别名称';
COMMENT ON COLUMN t_field.picture_pc IS '电脑端图片';
COMMENT ON COLUMN t_field.picture_mc IS '手机端图片';
COMMENT ON COLUMN t_field.venue_id IS '场馆ID';
COMMENT ON COLUMN t_field.venue_name IS '场馆名称';
COMMENT ON COLUMN t_field.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_field.field_introduce IS '活动室介绍';
COMMENT ON COLUMN t_field.field_device IS '活动室设备';
COMMENT ON COLUMN t_field.field_function IS '活动室功能用途';
COMMENT ON COLUMN t_field.field_open_time IS '活动室开放时间';
COMMENT ON COLUMN t_field.max_contain_people IS '最大容纳人数';
COMMENT ON COLUMN t_field.field_status IS '活动室状态 1.正常 2.禁止';
COMMENT ON COLUMN t_field.audit_type IS '活动室状态 1.手动审核 2.自动审核';
COMMENT ON COLUMN t_field.del_flag IS '删除 0.未删除 1.删除';


--场地预定表
CREATE TABLE t_venue_destine (
  id VARCHAR2(32) NOT NULL,
  venue_id VARCHAR2(32) NOT NULL,
  venue_name VARCHAR2(128) NULL,
  field_id VARCHAR2(32) NOT NULL,
  field_name VARCHAR2(128) NULL,
  reserve_people number(11) NOT NULL,
  destine_date number(11) NOT NULL,
  destine_week number(5) NOT NULL,
  begin_time number(11) NOT NULL,
	end_time number(11) NOT NULL,
	ticket_fee  number(5,2)   NULL,
	destine_status number(5) DEFAULT 0,
	destine_customname VARCHAR2(128) NULL,
	destine_id VARCHAR2(32),
  status  number(5) DEFAULT 0,
  del_flag number(5) DEFAULT 0,
  create_user VARCHAR2(128) NULL,
  created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP NULL,
  PRIMARY KEY (id)
);

create unique index index_unique_destine_date on t_venue_destine(destine_date);

COMMENT ON TABLE t_venue_destine IS '场地预定表';
COMMENT ON COLUMN t_venue_destine.id IS '主键ID';
COMMENT ON COLUMN t_venue_destine.venue_id IS '场馆ID';
COMMENT ON COLUMN t_venue_destine.venue_name IS '场馆名称';
COMMENT ON COLUMN t_venue_destine.field_id IS '活动室ID';
COMMENT ON COLUMN t_venue_destine.field_name IS '活动室名称';
COMMENT ON COLUMN t_venue_destine.reserve_people IS '预定人数';
COMMENT ON COLUMN t_venue_destine.destine_date IS '预定日期(格式:例如2019-08-26 ==》 20190826)';
COMMENT ON COLUMN t_venue_destine.destine_week IS '预定星期(星期 2 3 4 5 6 7 1 对应星期一到星期天)';
COMMENT ON COLUMN t_venue_destine.begin_time IS '开始时间(格式: 例如09：30 ==》 930)';
COMMENT ON COLUMN t_venue_destine.end_time IS '结束时间(格式: 例如09：30 ==》 930)';
COMMENT ON COLUMN t_venue_destine.ticket_fee IS '预定价格';
COMMENT ON COLUMN t_venue_destine.destine_status IS '预定状态(0:未预定; 1:已预订; 2:自定义合并预定)';
COMMENT ON COLUMN t_venue_destine.destine_customname IS '自定义合并预定名称(用于自定义添加名称)';
COMMENT ON COLUMN t_venue_destine.destine_id IS '预定人ID';
COMMENT ON COLUMN t_venue_destine.status IS '场地状态(0:正常; 1:下架)';
COMMENT ON COLUMN t_venue_destine.del_flag IS '删除状态(0:正常; 1:已删除)';
COMMENT ON COLUMN t_venue_destine.create_user IS '创建人';
COMMENT ON COLUMN t_venue_destine.created_time IS '创建时间';
COMMENT ON COLUMN t_venue_destine.modified_time IS '修改时间';


--场馆发布预定信息模板
CREATE TABLE t_venueroom_template (
	id VARCHAR2(32) NOT NULL,
	venue_id VARCHAR2(32)  NULL,
	enterprise_id VARCHAR2(32) NULL,
	create_by_user varchar(32) NULL,
	temp_id VARCHAR2(32) NOT NULL,
	temp_name VARCHAR2(32) NOT NULL,
	start_time NUMBER(11) NOT NULL,
	end_time NUMBER(11) NOT NULL,
	fee NUMBER(5,2) DEFAULT 0,
	del_flag NUMBER(2) DEFAULT 0,
	created_time TIMESTAMP DEFAULT sysdate,
	PRIMARY KEY (id)
);

create index index_temp_id on t_venueroom_template(temp_id);

COMMENT ON TABLE t_venueroom_template IS '活动室时间模板表';
COMMENT ON COLUMN t_venueroom_template.id IS '主键ID';
COMMENT ON COLUMN t_venueroom_template.venue_id IS '场馆id';
COMMENT ON COLUMN t_venueroom_template.enterprise_id  IS '企业ID';
COMMENT ON COLUMN t_venueroom_template.create_by_user IS '创建人id';
COMMENT ON COLUMN t_venueroom_template.temp_id IS '模板号';
COMMENT ON COLUMN t_venueroom_template.temp_name IS '模板名称';
COMMENT ON COLUMN t_venueroom_template.start_time IS '开始时间';
COMMENT ON COLUMN t_venueroom_template.end_time IS '结束时间';
COMMENT ON COLUMN t_venueroom_template.fee IS '价格';
COMMENT ON COLUMN t_venueroom_template.del_flag IS '删除状态';
COMMENT ON COLUMN t_venueroom_template.created_time IS '创建时间';




--场馆评论表
CREATE TABLE t_venue_comment (
    commentid VARCHAR2(32) NOT NULL,
    venueid VARCHAR2(32) NOT NULL,
    userid VARCHAR2(32) NOT NULL,
    username VARCHAR2(32) NOT NULL,
    anonymous NUMBER(11) DEFAULT 0,
    starrating NUMBER(11) DEFAULT 5,
    content VARCHAR2(256) NULL,
    picturepath VARCHAR2(128) NULL,
    created_time TIMESTAMP NOT NULL,
    PRIMARY KEY (commentid)
);

create index index_venueid on t_venue_comment(venueid);
create index index_venueid_userid on t_venue_comment(venueid,userid);

COMMENT ON TABLE t_venue_comment IS '场馆评论表';
COMMENT ON COLUMN t_venue_comment.commentid IS '主键ID';
COMMENT ON COLUMN t_venue_comment.venueid IS '场馆ID';
COMMENT ON COLUMN t_venue_comment.userid IS '用户ID';
COMMENT ON COLUMN t_venue_comment.username IS '用户名称';
COMMENT ON COLUMN t_venue_comment.anonymous IS '是否匿名（0.否1.是）';
COMMENT ON COLUMN t_venue_comment.starrating IS '评价（1.一星 2.二星 ...5.五星）';
COMMENT ON COLUMN t_venue_comment.content IS '场馆评论内容';
COMMENT ON COLUMN t_venue_comment.picturepath IS '图片路径';
COMMENT ON COLUMN t_venue_comment.created_time IS '创建时间';


--活动标签关联表
CREATE TABLE t_activity_relationship_tag (
  relationship_id VARCHAR2(32) NOT NULL,
  tag_id VARCHAR2(32) NOT NULL,
  tag_name VARCHAR2(32) NOT NULL,
  activityinfo_id VARCHAR2(32) NOT NULL,
  del_flag NUMBER(5) DEFAULT 0,
  created_time TIMESTAMP DEFAULT sysdate,
	modified_time TIMESTAMP NULL,
  PRIMARY KEY (relationship_id)
);

COMMENT ON TABLE t_activity_relationship_tag IS '活动标签关联表';
COMMENT ON COLUMN t_activity_relationship_tag.relationship_id IS '企业标签关系表ID';
COMMENT ON COLUMN t_activity_relationship_tag.tag_id IS '标签ID';
COMMENT ON COLUMN t_activity_relationship_tag.tag_name IS '标签名称';
COMMENT ON COLUMN t_activity_relationship_tag.activityinfo_id IS '活动ID';
COMMENT ON COLUMN t_activity_relationship_tag.del_flag IS '删除状态(0:正常; 1:已删除)';
COMMENT ON COLUMN t_activity_relationship_tag.created_time IS '创建时间';
COMMENT ON COLUMN t_activity_relationship_tag.modified_time IS '修改时间';



--场地申请表
CREATE TABLE t_venue_apply (
  id VARCHAR2(32) NOT NULL,
  venue_id VARCHAR2(32) NOT NULL,
  destine_id VARCHAR2(500) NOT NULL,
  apply_enterprise_id VARCHAR2(32) NULL,
  apply_user VARCHAR2(32) NOT NULL,
  apply_name VARCHAR2(50) NULL,
  apply_phone VARCHAR2(20) NULL,
  description VARCHAR2(500) NULL,
  site_use NUMBER(5) NULL,
  apply_bedate VARCHAR2(20) NOT NULL,
  apply_endate VARCHAR2(20) NULL,
  begin_time VARCHAR2(200) NULL,
  end_time VARCHAR2(10) NULL,
  province_id VARCHAR2(32) DEFAULT NULL,
  province_name VARCHAR2(50) DEFAULT NULL,
  city_id VARCHAR2(32) DEFAULT NULL,
  city_name VARCHAR2(50) DEFAULT NULL,
  district_id VARCHAR2(32) DEFAULT NULL,
  district_name VARCHAR2(50) DEFAULT NULL,
  sub_district_id VARCHAR2(32) DEFAULT NULL,
  sub_district_name VARCHAR2(50) DEFAULT NULL,
  auditman VARCHAR2(128) NULL,
  audit_time VARCHAR2(20) NULL,
  audit_status number(5) DEFAULT 0,
  audit_remark VARCHAR2(256) NULL,
  create_by_user VARCHAR2(32) NOT NULL,
  created_time TIMESTAMP NOT NULL,
  update_by_user VARCHAR2(32) NULL,
  modified_time TIMESTAMP NULL,
  del_flag NUMBER(5) DEFAULT 0,
  apply_type NUMBER(5) NULL,
  destine_customname VARCHAR2(50) NULL,
  apply_source NUMBER(5) NULL,
  PRIMARY KEY (id)
);

create index index_venue_id on t_venue_apply(venue_id);
create index index_apply_user on t_venue_apply(apply_user);


COMMENT ON TABLE t_venue_apply IS '场地申请表';
COMMENT ON COLUMN t_venue_apply.id IS '主键ID';
COMMENT ON COLUMN t_venue_apply.venue_id IS '场馆ID';
COMMENT ON COLUMN t_venue_apply.destine_id IS '预订信息ID';
COMMENT ON COLUMN t_venue_apply.apply_enterprise_id IS '申请企业ID';
COMMENT ON COLUMN t_venue_apply.apply_user IS '申请人ID';
COMMENT ON COLUMN t_venue_apply.apply_name IS '申请人名称';
COMMENT ON COLUMN t_venue_apply.apply_phone IS '申请人联系方式';
COMMENT ON COLUMN t_venue_apply.description IS '申请说明';
COMMENT ON COLUMN t_venue_apply.site_use IS '场地用途';
COMMENT ON COLUMN t_venue_apply.apply_bedate IS '预定日期(开始)';
COMMENT ON COLUMN t_venue_apply.apply_endate IS '预定日期(结束)';
COMMENT ON COLUMN t_venue_apply.begin_time IS '开始时间';
COMMENT ON COLUMN t_venue_apply.end_time IS '结束时间';
COMMENT ON COLUMN t_venue_apply.province_id IS '省编码';
COMMENT ON COLUMN t_venue_apply.province_name IS '省名称';
COMMENT ON COLUMN t_venue_apply.city_id IS '市编码';
COMMENT ON COLUMN t_venue_apply.city_name IS '市名称';
COMMENT ON COLUMN t_venue_apply.district_id IS '区域编码';
COMMENT ON COLUMN t_venue_apply.district_name IS '区域名称';
COMMENT ON COLUMN t_venue_apply.sub_district_id IS '街道编码';
COMMENT ON COLUMN t_venue_apply.sub_district_name IS '街道名称';
COMMENT ON COLUMN t_venue_apply.auditman IS '审核人';
COMMENT ON COLUMN t_venue_apply.audit_time IS '审核时间(格式:yyyy-MM-dd HH:mm:ss)';
COMMENT ON COLUMN t_venue_apply.audit_status IS '审核状态(1:未提交; 2:未审核; 3:审核通过; 4:审核未通过)';
COMMENT ON COLUMN t_venue_apply.audit_remark IS '审核备注';
COMMENT ON COLUMN t_venue_apply.create_by_user IS '创建人';
COMMENT ON COLUMN t_venue_apply.created_time IS '创建时间';
COMMENT ON COLUMN t_venue_apply.update_by_user IS '修改人';
COMMENT ON COLUMN t_venue_apply.modified_time IS '修改时间';
COMMENT ON COLUMN t_venue_apply.del_flag IS '删除状态(0:正常; 1:已删除)';
COMMENT ON COLUMN t_venue_apply.apply_type IS '申请类型(1:单个申请; 2:自定义申请)';
COMMENT ON COLUMN t_venue_apply.destine_customname IS '申请自定义名称';
COMMENT ON COLUMN t_venue_apply.apply_source IS '申请来源(1:门户; 2:微信; 3:小程序)';


--操作日志表
CREATE TABLE sys_log_info(
  id  VARCHAR2(32) NOT NULL,
  method_name VARCHAR2(32) NOT NULL,
  req_url VARCHAR2(2048) NOT NULL,
  req_mode VARCHAR2(8) NOT NULL,
  req_params CLOB NOT NULL,
  req_ip VARCHAR2(32) NOT NULL,
  run_time NUMBER(11) NOT NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
  PRIMARY KEY (id)
);
create index index_create_user on sys_log_info(create_user);
create index index_created_time on sys_log_info(created_time);

COMMENT ON TABLE sys_log_info IS '操作日志表';
COMMENT ON COLUMN sys_log_info.id IS '主键ID';
COMMENT ON COLUMN sys_log_info.method_name IS '方法名称';
COMMENT ON COLUMN sys_log_info.req_url IS '请求url';
COMMENT ON COLUMN sys_log_info.req_mode IS '请求方式';
COMMENT ON COLUMN sys_log_info.req_params IS '请求参数';
COMMENT ON COLUMN sys_log_info.req_ip IS '请求ip';
COMMENT ON COLUMN sys_log_info.run_time IS '运行时间';
COMMENT ON COLUMN sys_log_info.created_time IS '添加时间';
COMMENT ON COLUMN sys_log_info.create_user IS '添加人';
COMMENT ON COLUMN sys_log_info.modified_time IS '修改时间';
COMMENT ON COLUMN sys_log_info.update_user IS '修改人';
COMMENT ON COLUMN sys_log_info.del_flg IS '删除标志（0正常,1删除）';



--审核记录表
CREATE TABLE t_audit_log (
  id VARCHAR2(32) NOT NULL ,
  business_id VARCHAR2(32) NOT NULL ,
  create_user_id VARCHAR2(32) ,
  create_user_name VARCHAR2(32) ,
  create_time TIMESTAMP(6) ,
  rollback_reason VARCHAR2(255) ,
  modified_suggest VARCHAR2(255) ,
  audit_status NUMBER(11) DEFAULT 1,
  PRIMARY KEY (id)
);
create index index_business_id on t_audit_log(business_id);

COMMENT ON TABLE t_audit_log IS '审核记录表';
COMMENT ON COLUMN t_audit_log.id IS '主键ID';
COMMENT ON COLUMN t_audit_log.business_id IS '对应业务表ID';
COMMENT ON COLUMN t_audit_log.create_user_id IS '创建人ID';
COMMENT ON COLUMN t_audit_log.create_user_name IS '创建人';
COMMENT ON COLUMN t_audit_log.create_time IS '创建时间';
COMMENT ON COLUMN t_audit_log.rollback_reason IS '回退原因';
COMMENT ON COLUMN t_audit_log.modified_suggest IS '修改建议';
COMMENT ON COLUMN t_audit_log.audit_status IS '审核状态（1.未提交 2：待审核  3：未通过 4：已通过 ）';


--------------------------------------------------------------------
-------------------------------------场馆、体育场馆------------------
--------------------------------------------------------------------

--运动项目表
CREATE TABLE t_sport_item
(
   sport_item_id varchar(32) NOT NULL,
   sport_item_code varchar(32) NULL,
   sport_item_name varchar(50) NULL,
   sport_item_icon varchar(200) NULL,
   sort number(5) NULL,
   status number(5) NULL,
   PRIMARY KEY (sport_item_id)
);

create index index_sport_item_name on t_sport_item(sport_item_name);
create index index_sport_item_code on t_sport_item(sport_item_code);

COMMENT ON TABLE t_sport_item IS '运动项目表';
COMMENT ON COLUMN t_sport_item.sport_item_id IS '主键ID';
COMMENT ON COLUMN t_sport_item.sport_item_code IS '运动项目编号';
COMMENT ON COLUMN t_sport_item.sport_item_name IS '运动项目名称';
COMMENT ON COLUMN t_sport_item.sport_item_icon IS '运动项目图标';
COMMENT ON COLUMN t_sport_item.sort IS '排序';
COMMENT ON COLUMN t_sport_item.status IS '状态 1.正常 2.禁止';


----------------------------------------------------------------------------------
--场馆项目
CREATE TABLE t_venue_sportitem
(
   venue_sportitem_id  varchar(32) NOT NULL,
   enterprise_id varchar(32) null,
   venue_id varchar(32) null,
   sport_item_code varchar(32) null,
   sport_item_name varchar(32) null,
   occupy_type number(5) null,
   step number(5,2) null,
   refundtime number(11) null,
   inoutdoor number(5) null,
   havelight number(5) null,
   floor_type number(5) null,
   weekday_start_time number(11) null,
   weekday_end_time number(11) null,
   weekend_start_time number(11) null,
   weekend_end_time number(11) null,
   status number(5) null,
   del_flag number(5) DEFAULT 0,
   create_by_user VARCHAR2(32) NOT NULL,
   created_time TIMESTAMP NOT NULL,
   update_by_user VARCHAR2(32) NULL,
   modified_time TIMESTAMP NULL,
   PRIMARY KEY (venue_sportitem_id)
);

create index index_venue_id_sportitem on t_venue_sportitem(venue_id);

COMMENT ON TABLE t_venue_sportitem IS '场馆项目';
COMMENT ON COLUMN t_venue_sportitem.venue_sportitem_id IS '主键ID';
COMMENT ON COLUMN t_venue_sportitem.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_venue_sportitem.venue_id IS '场馆ID';
COMMENT ON COLUMN t_venue_sportitem.sport_item_code IS '运动项目code';
COMMENT ON COLUMN t_venue_sportitem.sport_item_name IS '运动项目名称';
COMMENT ON COLUMN t_venue_sportitem.occupy_type IS '使用类型 1、按步长，2、按早晚，3、按天';
COMMENT ON COLUMN t_venue_sportitem.step IS '步长';
COMMENT ON COLUMN t_venue_sportitem.refundtime IS '提前退订时间，单位：小时';
COMMENT ON COLUMN t_venue_sportitem.inoutdoor IS '室内or室外';
COMMENT ON COLUMN t_venue_sportitem.havelight IS '是否有灯光';
COMMENT ON COLUMN t_venue_sportitem.floor_type IS '地板类型';
COMMENT ON COLUMN t_venue_sportitem.weekday_start_time IS '工作日开始营业时间';
COMMENT ON COLUMN t_venue_sportitem.weekday_end_time IS '工作日结束营业时间';
COMMENT ON COLUMN t_venue_sportitem.weekend_start_time IS '周末开始营业时间';
COMMENT ON COLUMN t_venue_sportitem.weekend_end_time IS '周末结束营业时间';
COMMENT ON COLUMN t_venue_sportitem.status IS '状态 1.正常 2.禁止';
COMMENT ON COLUMN t_venue_sportitem.del_flag IS '删除标志 0.未删除 1.删除';
COMMENT ON COLUMN t_venue_sportitem.create_by_user IS '创建人ID';
COMMENT ON COLUMN t_venue_sportitem.created_time IS '创建时间';
COMMENT ON COLUMN t_venue_sportitem.update_by_user IS '修改人ID';
COMMENT ON COLUMN t_venue_sportitem.modified_time IS '修改时间';

----------------------------------------------------------------------------------
--场馆场地信息

CREATE TABLE t_venue_space
(
   venue_space_id varchar(32) NOT NULL,
   venue_space_name varchar(64) null,
   enterprise_id varchar(32) null,
   venue_id varchar(32) null,
   venue_sportitem_id varchar(32) null,
   max_reserve_person number(11) null,
   create_by_user varchar(32) null,
   created_time TIMESTAMP NOT NULL,
   status number(5) null,
   del_flag number(5) DEFAULT 0,
   PRIMARY KEY (venue_space_id)
);

create index index_venue_space_name on t_venue_space(venue_space_name);

COMMENT ON TABLE t_venue_space IS '场馆场地信息';
COMMENT ON COLUMN t_venue_space.venue_space_id IS '主键ID';
COMMENT ON COLUMN t_venue_space.venue_space_name IS '场馆场地名称';
COMMENT ON COLUMN t_venue_space.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_venue_space.venue_id IS '场馆ID';
COMMENT ON COLUMN t_venue_space.venue_sportitem_id IS '场馆项目ID';
COMMENT ON COLUMN t_venue_space.max_reserve_person IS '最大预定人数';
COMMENT ON COLUMN t_venue_space.create_by_user IS '创建人ID';
COMMENT ON COLUMN t_venue_space.created_time IS '创建时间';
COMMENT ON COLUMN t_venue_space.status IS '状态 1.正常 2.禁止';
COMMENT ON COLUMN t_venue_space.del_flag IS '删除标志 0.未删除 1.删除';

-----------------------------------------------------------------------------------------
--场馆场号(场地划分编号)

CREATE TABLE t_venue_space_no
(
   venue_space_no_id varchar(32) NOT NULL,
   venue_space_no_name number(11) null,
   venue_space_no_sign varchar(32) null,
   venue_space_no_code varchar(32) null,
   enterprise_id varchar(32) null,
   venue_id varchar(32) null,
   venue_sportitem_id varchar(32) null,
   venue_space_id varchar(32) null,
   venue_space_name varchar(32) null,
   sport_item_code varchar(32) null,
   max_reserve_people number(5) null,
   status number(5) null,
   del_flag number(5) DEFAULT 0,
   create_by_user varchar(32) null,
   created_time TIMESTAMP NOT NULL,
   modified_time TIMESTAMP NULL,
   PRIMARY KEY (venue_space_no_id)
);


COMMENT ON TABLE t_venue_space_no IS '场馆场号';
COMMENT ON COLUMN t_venue_space_no.venue_space_no_id IS '主键ID';
COMMENT ON COLUMN t_venue_space_no.venue_space_no_name IS '场号编号 1 2 3 ，展示 1号场 2号场 3号场';
COMMENT ON COLUMN t_venue_space_no.venue_space_no_sign IS '场号名称';
COMMENT ON COLUMN t_venue_space_no.venue_space_no_code IS '场号编号';
COMMENT ON COLUMN t_venue_space_no.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_venue_space_no.venue_id IS '场馆ID';
COMMENT ON COLUMN t_venue_space_no.venue_sportitem_id IS '场馆项目ID';
COMMENT ON COLUMN t_venue_space_no.venue_space_id IS '场馆场地ID';
COMMENT ON COLUMN t_venue_space_no.venue_space_name IS '场馆场地名称';
COMMENT ON COLUMN t_venue_space_no.sport_item_code IS '运动项目编号';
COMMENT ON COLUMN t_venue_space_no.max_reserve_people IS '运行同时预定人数';
COMMENT ON COLUMN t_venue_space_no.status IS '状态 1.正常 2.禁止';
COMMENT ON COLUMN t_venue_space_no.del_flag IS '删除标志 0.未删除 1.删除';
COMMENT ON COLUMN t_venue_space_no.create_by_user IS '创建人ID';
COMMENT ON COLUMN t_venue_space_no.created_time IS '创建时间';
COMMENT ON COLUMN t_venue_space_no.modified_time IS '修改时间';

-----------------------------------------------------------------------------
--项目价格模板----------------------------------------------------
-----------------------------------------------------------------------------
create table t_sportitem_price_template
(
   price_template_id varchar(32) NOT NULL,
   enterprise_id varchar(32) NULL,
   venue_id varchar(32) NULL,
   venue_sportitem_id varchar(32) NULL,
   venue_sportitem_name varchar(32) NULL,
   price_template_name varchar(32) NULL,
   weekday_dayprice number(4,2) NULL,
   weekday_dayend_time number(11) NULL,
   weekday_nightprice number(4,2) NULL,
   weekend_dayprice number(4,2) NULL,
   weekend_dayend_time number(11) NULL,
   weekend_nightprice number(4,2) NULL,
   create_by_user varchar(32) NULL,
   created_time TIMESTAMP NOT NULL,
   status number(5) NULL,
   del_flag number(5) DEFAULT 0,
   PRIMARY KEY (price_template_id)
);

COMMENT ON TABLE t_sportitem_price_template IS '项目价格模板';
COMMENT ON COLUMN t_sportitem_price_template.price_template_id IS '主键ID';
COMMENT ON COLUMN t_sportitem_price_template.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_sportitem_price_template.venue_id IS '场馆ID';
COMMENT ON COLUMN t_sportitem_price_template.venue_sportitem_id IS '场馆项目ID';
COMMENT ON COLUMN t_sportitem_price_template.venue_sportitem_name IS '场馆项目名称';
COMMENT ON COLUMN t_sportitem_price_template.price_template_name IS '价格模板名称';
COMMENT ON COLUMN t_sportitem_price_template.weekday_dayprice IS '工作日早上价格';
COMMENT ON COLUMN t_sportitem_price_template.weekday_dayend_time IS '工作日早上截至时间';
COMMENT ON COLUMN t_sportitem_price_template.weekday_nightprice IS '工作日下午价格';
COMMENT ON COLUMN t_sportitem_price_template.weekend_dayprice IS '周末早上价格';
COMMENT ON COLUMN t_sportitem_price_template.weekend_dayend_time IS '周末早上截至时间';
COMMENT ON COLUMN t_sportitem_price_template.weekend_nightprice IS '周末下午价格';
COMMENT ON COLUMN t_sportitem_price_template.create_by_user IS '创建人ID';
COMMENT ON COLUMN t_sportitem_price_template.created_time IS '创建时间';
COMMENT ON COLUMN t_sportitem_price_template.status IS '状态 1.正常 2.禁止';
COMMENT ON COLUMN t_sportitem_price_template.del_flag IS '删除标志 0.未删除 1.删除';


------------------------------------------------------------------------------------
-- 商品信息
--------------------------

create table t_venue_good_info
(
   good_id varchar(32) null,
   good_name varchar(32) null,
   enterprise_id varchar(32) null,
   venue_id varchar(32) null,
   venue_item_id varchar(32) null,
   venue_groundtype_id varchar(32) null,
   venue_space_no_id varchar(32) null,
   venue_space_no_name number(11) null,
   sport_item_code varchar(10) null,
   use_date number(11) null,
   start_time number(11) null,
   end_time number(11) null,
   saleprice number(4,2) null,
   totalnum number(11) null,
   remainnum number(11) null,
   reservednum number(11) null,
   status number(5) null,
   delflag number(5) DEFAULT 0,
   PRIMARY KEY (good_id)
);


COMMENT ON TABLE t_venue_good_info IS '商品信息';
COMMENT ON COLUMN t_venue_good_info.good_id IS '主键ID';
COMMENT ON COLUMN t_venue_good_info.good_name IS '商品名称';
COMMENT ON COLUMN t_venue_good_info.enterprise_id IS '企业ID';
COMMENT ON COLUMN t_venue_good_info.venue_id IS '场馆ID';
COMMENT ON COLUMN t_venue_good_info.venue_item_id IS '场馆项目ID';
COMMENT ON COLUMN t_venue_good_info.venue_groundtype_id IS '场馆场地ID';
COMMENT ON COLUMN t_venue_good_info.venue_space_no_id IS '场馆场号ID';
COMMENT ON COLUMN t_venue_good_info.venue_space_no_name IS '场馆场号编号用于排序';
COMMENT ON COLUMN t_venue_good_info.sport_item_code IS '运动项目编号';
COMMENT ON COLUMN t_venue_good_info.use_date IS '使用日期';
COMMENT ON COLUMN t_venue_good_info.start_time IS '开始时间';
COMMENT ON COLUMN t_venue_good_info.end_time IS '结束时间';
COMMENT ON COLUMN t_venue_good_info.saleprice IS '售价';
COMMENT ON COLUMN t_venue_good_info.totalnum IS '总数量';
COMMENT ON COLUMN t_venue_good_info.remainnum IS '可预订数量';
COMMENT ON COLUMN t_venue_good_info.reservednum IS '已预定数量';
COMMENT ON COLUMN t_venue_good_info.status IS '状态 1.正常 2.禁止';
COMMENT ON COLUMN t_venue_good_info.delflag IS '删除标志 0.未删除 1.删除';



