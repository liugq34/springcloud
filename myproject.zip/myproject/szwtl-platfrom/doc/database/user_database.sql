--系统用户表
CREATE TABLE sys_user(
	id VARCHAR2(32) NOT NULL,
	account VARCHAR2(32) NOT NULL,
	realname VARCHAR2(100) NOT NULL,
	password VARCHAR2(255) NOT NULL,
	authorized_password VARCHAR2(255) NOT NULL,
	salt VARCHAR2(45) NOT NULL,
	avatar VARCHAR2(255) NULL,
	birthday VARCHAR2(15) NULL,
	sex NUMBER(11) DEFAULT 1,
	email VARCHAR2(45) NULL,
	status NUMBER(11) DEFAULT 1,
	province_id NUMBER(11) NULL,
	province_name VARCHAR2(50) NULL,
	city_id NUMBER(11) NULL,
	city_name VARCHAR2(50) NULL,
	district_id NUMBER(11) NULL,
	district_name VARCHAR2(50) NULL,
	address VARCHAR2(255) NOT NULL,
	del_flag NUMBER(11) DEFAULT 0,
	description VARCHAR2(255) NULL,
	create_by_user VARCHAR2(32) NOT NULL,
	created_time TIMESTAMP NOT NULL,
	update_by_user VARCHAR2(32) NULL,
	modified_time TIMESTAMP NULL,
	enterprise_id VARCHAR2(32) NOT NULL,
	store_id VARCHAR2(32) NOT NULL,
	PRIMARY KEY (id)
);

create unique index index_unique_sys_user_account on sys_user(account);

COMMENT ON TABLE sys_user IS '系统用户表';
COMMENT ON COLUMN sys_user.id IS 'ID';
COMMENT ON COLUMN sys_user.account IS '登录账号';
COMMENT ON COLUMN sys_user.realname IS '真实姓名';
COMMENT ON COLUMN sys_user.password IS '密码';
COMMENT ON COLUMN sys_user.authorized_password IS 'SSO授权密码';
COMMENT ON COLUMN sys_user.salt IS '密码盐';
COMMENT ON COLUMN sys_user.avatar IS '头像';
COMMENT ON COLUMN sys_user.birthday IS '生日';
COMMENT ON COLUMN sys_user.sex IS '性别（1：男 2：女）';
COMMENT ON COLUMN sys_user.email IS '电子邮件';
COMMENT ON COLUMN sys_user.status IS '状态(1：正常  2：冻结 ）';
COMMENT ON COLUMN sys_user.description IS '描述';
COMMENT ON COLUMN sys_user.create_by_user IS '创建人';
COMMENT ON COLUMN sys_user.created_time IS '创建时间';
COMMENT ON COLUMN sys_user.update_by_user IS '更新人';
COMMENT ON COLUMN sys_user.modified_time IS '更新时间';
COMMENT ON COLUMN sys_user.del_flag IS '删除状态（0，正常，1已删除）';
COMMENT ON COLUMN sys_user.enterprise_id IS '企业ID';
COMMENT ON COLUMN sys_user.store_id IS '门店ID';
COMMENT ON COLUMN sys_user.province_id IS '省编码';
COMMENT ON COLUMN sys_user.province_name IS '省名称';
COMMENT ON COLUMN sys_user.city_id IS '市编码';
COMMENT ON COLUMN sys_user.city_name IS '市名称';
COMMENT ON COLUMN sys_user.district_id IS '区域编码';
COMMENT ON COLUMN sys_user.district_name IS '区域名称';
COMMENT ON COLUMN sys_user.address IS '联系地址';

CREATE TABLE sys_permission(
	id VARCHAR2(32) NOT NULL,
	parent_id VARCHAR2(32) NULL,
	name VARCHAR2(100) NOT NULL,
	url VARCHAR2(255) NULL,
	menu_type NUMBER(11) NOT NULL,
	sort_no NUMBER(10) NOT NULL,
	icon VARCHAR2(100) NULL,
	forbidden NUMBER(2) DEFAULT '0',
	description VARCHAR2(255) NULL,
	create_by_user VARCHAR2(32) NOT NULL,
	created_time TIMESTAMP NOT NULL,
	update_by_user VARCHAR2(32) NULL,
	modified_time TIMESTAMP NULL,
	del_flag NUMBER(11) DEFAULT '0',
	PRIMARY KEY (id)
);

create index index_prem_pid on sys_permission(parent_id);

COMMENT ON TABLE sys_permission IS '菜单权限表';
COMMENT ON COLUMN sys_permission.id IS '主键ID';
COMMENT ON COLUMN sys_permission.parent_id IS '父ID';
COMMENT ON COLUMN sys_permission.name IS '菜单名称';
COMMENT ON COLUMN sys_permission.url IS '菜单跳转地址';
COMMENT ON COLUMN sys_permission.menu_type IS '菜单类型(0:一级菜单; 1:子菜单)';
COMMENT ON COLUMN sys_permission.sort_no IS '菜单排序';
COMMENT ON COLUMN sys_permission.icon IS '菜单图标';
COMMENT ON COLUMN sys_permission.forbidden IS '是否隐藏: 0否,1是';
COMMENT ON COLUMN sys_permission.description IS '描述';
COMMENT ON COLUMN sys_permission.create_by_user IS '创建人';
COMMENT ON COLUMN sys_permission.created_time IS '创建时间';
COMMENT ON COLUMN sys_permission.update_by_user IS '更新人';
COMMENT ON COLUMN sys_permission.modified_time IS '更新时间';
COMMENT ON COLUMN sys_permission.del_flag IS '删除状态 0正常 1已删除';

CREATE TABLE sys_role(
	id VARCHAR2(32) NOT NULL,
	role_name VARCHAR2(200) NOT NULL,
	role_code VARCHAR2(100) NOT NULL,
	description VARCHAR2(255) NULL,
	create_by_user VARCHAR2(32) NOT NULL,
	created_time TIMESTAMP NOT NULL,
	update_by_user VARCHAR2(32) NULL,
	modified_time TIMESTAMP NULL,
	del_flag NUMBER(11) DEFAULT '0',
	PRIMARY KEY (id)
);

create index index_role_code on sys_role(role_code);

COMMENT ON TABLE sys_role IS '角色表';
COMMENT ON COLUMN sys_role.id IS '主键ID';
COMMENT ON COLUMN sys_role.role_name IS '角色名称';
COMMENT ON COLUMN sys_role.role_code IS '角色编码';
COMMENT ON COLUMN sys_role.description IS '描述';
COMMENT ON COLUMN sys_role.create_by_user IS '创建人';
COMMENT ON COLUMN sys_role.created_time IS '创建时间';
COMMENT ON COLUMN sys_role.update_by_user IS '更新人';
COMMENT ON COLUMN sys_role.modified_time IS '更新时间';
COMMENT ON COLUMN sys_role.del_flag IS '删除状态 0正常 1已删除';

CREATE TABLE sys_role_permission(
	id VARCHAR2(32) NOT NULL,
	role_id VARCHAR2(32) NOT NULL,
	permission_id VARCHAR2(32) NOT NULL,
	PRIMARY KEY (id)
);

create index index_role_id_permission_id on sys_role_permission(role_id, permission_id);
create index index_role_id on sys_role_permission(role_id);
create index index_permission_id on sys_role_permission(permission_id);

COMMENT ON TABLE sys_role_permission IS '角色权限表';
COMMENT ON COLUMN sys_role_permission.id IS 'ID';
COMMENT ON COLUMN sys_role_permission.role_id IS '角色ID';
COMMENT ON COLUMN sys_role_permission.permission_id IS '权限ID';


CREATE TABLE sys_user_role(
	id VARCHAR2(32) NOT NULL,
	user_id VARCHAR2(32) NOT NULL,
	role_id VARCHAR2(32) NOT NULL,
	PRIMARY KEY (id)
);

create index index_user_id_role_id on sys_user_role(user_id, role_id);
create index index_user_id on sys_user_role(user_id);
create index index_role_id on sys_user_role(role_id);

COMMENT ON TABLE sys_user_role IS '用户角色表';
COMMENT ON COLUMN sys_user_role.id IS 'ID';
COMMENT ON COLUMN sys_user_role.user_id IS '用户ID';
COMMENT ON COLUMN sys_user_role.role_id IS '角色ID';


CREATE TABLE t_consumer_user(
	id VARCHAR2(32) NOT NULL,
	account VARCHAR2(20) NOT NULL,
	realname VARCHAR2(100) DEFAULT NULL,
	identity_card VARCHAR2(25)NOT NULL,
	contacts VARCHAR2(25)NOT NULL,
	wx_openid VARCHAR2(100) DEFAULT NULL,
	wx_nickname VARCHAR2(100) DEFAULT NULL,
	wx_headimgurl VARCHAR2(255) DEFAULT NULL,
	password VARCHAR2(255) NOT NULL,
	authorized_password VARCHAR2(255) NOT NULL,
	salt VARCHAR2(45) NOT NULL,
	avatar VARCHAR2(255) DEFAULT NULL,
	birthday VARCHAR2(15) DEFAULT NULL,
	sex NUMBER(11) DEFAULT 1,
	email VARCHAR2(45) DEFAULT NULL,
	status NUMBER(2) DEFAULT 1,
	province_id NUMBER(11) DEFAULT NULL,
	province_name VARCHAR2(50) DEFAULT NULL,
	city_id NUMBER(11) DEFAULT NULL,
	city_name VARCHAR2(50) DEFAULT NULL,
	district_id NUMBER(11) DEFAULT NULL,
	district_name VARCHAR2(50) DEFAULT NULL,
	address VARCHAR2(255) DEFAULT NULL,
	del_flag NUMBER(11) DEFAULT 0,
	description VARCHAR2(255) DEFAULT NULL,
	created_time TIMESTAMP DEFAULT NULL,
	update_by_user VARCHAR2(32) DEFAULT NULL,
	modified_time TIMESTAMP DEFAULT NULL,
	PRIMARY KEY (id)
);

create unique index index_unique_consumer_account on t_consumer_user(account);
create unique index index_unique_identity_card on t_consumer_user(identity_card);



COMMENT ON TABLE t_consumer_user IS '消费者用户';
COMMENT ON COLUMN t_consumer_user.id IS 'ID';
COMMENT ON COLUMN t_consumer_user.account IS '登录账号（手机号）';
COMMENT ON COLUMN t_consumer_user.realname IS '真实姓名';
COMMENT ON COLUMN t_consumer_user.identity_card IS '身份证号码';
COMMENT ON COLUMN t_consumer_user.contacts IS '手机号码';
COMMENT ON COLUMN t_consumer_user.wx_openid IS '用户的标识，对当前公众号唯一';
COMMENT ON COLUMN t_consumer_user.wx_nickname IS '微信用户的昵称';
COMMENT ON COLUMN t_consumer_user.wx_headimgurl IS '微信头像';
COMMENT ON COLUMN t_consumer_user.password IS '密码';
COMMENT ON COLUMN t_consumer_user.authorized_password IS 'SSO授权密码';
COMMENT ON COLUMN t_consumer_user.salt IS '密码盐';
COMMENT ON COLUMN t_consumer_user.avatar IS '头像';
COMMENT ON COLUMN t_consumer_user.birthday IS '生日';
COMMENT ON COLUMN t_consumer_user.sex IS '性别（1：男 2：女）';
COMMENT ON COLUMN t_consumer_user.email IS '电子邮件';
COMMENT ON COLUMN t_consumer_user.status IS '状态(1：正常  2：冻结 ）';
COMMENT ON COLUMN t_consumer_user.description IS '描述';
COMMENT ON COLUMN t_consumer_user.created_time IS '创建时间';
COMMENT ON COLUMN t_consumer_user.update_by_user IS '更新人';
COMMENT ON COLUMN t_consumer_user.modified_time IS '更新时间';
COMMENT ON COLUMN t_consumer_user.del_flag IS '删除状态（0，正常，1已删除）';
COMMENT ON COLUMN t_consumer_user.province_id IS '省编码';
COMMENT ON COLUMN t_consumer_user.province_name IS '省名称';
COMMENT ON COLUMN t_consumer_user.city_id IS '市编码';
COMMENT ON COLUMN t_consumer_user.city_name IS '市名称';
COMMENT ON COLUMN t_consumer_user.district_id IS '区域编码';
COMMENT ON COLUMN t_consumer_user.district_name IS '区域名称';
COMMENT ON COLUMN t_consumer_user.address IS '联系地址';

CREATE TABLE t_enterprise_group(
	id VARCHAR2(32) NOT NULL,
	enterprise_name VARCHAR2(100) NOT NULL,
	legal_entity_name VARCHAR2(100) NOT NULL,
	legal_entity_contacts VARCHAR2(100) NOT NULL,
	legal_entity_identity_card VARCHAR2(25) NOT NULL,
	unified_social_credit_code  VARCHAR2(25) NOT NULL,
	contacts VARCHAR2(100) NOT NULL,
	province_id NUMBER(11) NULL,
	province_name VARCHAR2(50) NULL,
	city_id NUMBER(11) NULL,
	city_name VARCHAR2(50) NULL,
	district_id NUMBER(11) NULL,
	district_name VARCHAR2(50) NULL,
	address VARCHAR2(255) NULL,
	logo VARCHAR2(255) NULL,
	email VARCHAR2(45) NULL,
	description VARCHAR2(45) NULL,
	audit_status NUMBER(2) DEFAULT 1,
	status NUMBER(2) DEFAULT 1,
	del_flag NUMBER(11) DEFAULT 0,
	created_time TIMESTAMP NULL,
	update_by_user VARCHAR2(32) NULL,
	modified_time TIMESTAMP NULL,
	PRIMARY KEY (id)
);

create unique index index_unique_enterprise_name on t_enterprise_group(enterprise_name);
create unique index index_unique_credit_code on t_enterprise_group(unified_social_credit_code);


COMMENT ON TABLE t_enterprise_group IS '企业信息';
COMMENT ON COLUMN t_enterprise_group.id IS 'ID';
COMMENT ON COLUMN t_enterprise_group.enterprise_name IS '企业名称';
COMMENT ON COLUMN t_enterprise_group.legal_entity_name IS '法人姓名';
COMMENT ON COLUMN t_enterprise_group.legal_entity IS '法人姓名';
COMMENT ON COLUMN t_enterprise_group.legal_entity_identity_card IS '法人身份证号码';
COMMENT ON COLUMN t_enterprise_group.unified_social_credit_code IS '统一社会信用代码';
COMMENT ON COLUMN t_enterprise_group.legal_entity_contacts IS '法人联系方式';
COMMENT ON COLUMN t_enterprise_group.contacts IS '企业联系方式';
COMMENT ON COLUMN t_enterprise_group.address IS '联系地址';
COMMENT ON COLUMN t_enterprise_group.logo IS '企业LOGO';
COMMENT ON COLUMN t_enterprise_group.email IS '企业邮箱';
COMMENT ON COLUMN t_enterprise_group.audit_status IS '审核状态（1：未审核  2：未通过 3：已通过 ）';
COMMENT ON COLUMN t_enterprise_group.status IS '状态(1：正常  2：冻结 ）';
COMMENT ON COLUMN t_enterprise_group.description IS '描述';
COMMENT ON COLUMN t_enterprise_group.created_time IS '创建时间';
COMMENT ON COLUMN t_enterprise_group.update_by_user IS '更新人';
COMMENT ON COLUMN t_enterprise_group.modified_time IS '更新时间';
COMMENT ON COLUMN t_enterprise_group.del_flag IS '删除状态 0正常 1已删除';
COMMENT ON COLUMN t_enterprise_group.province_id IS '省编码';
COMMENT ON COLUMN t_enterprise_group.province_name IS '省名称';
COMMENT ON COLUMN t_enterprise_group.city_id IS '市编码';
COMMENT ON COLUMN t_enterprise_group.city_name IS '市名称';
COMMENT ON COLUMN t_enterprise_group.district_id IS '区域编码';
COMMENT ON COLUMN t_enterprise_group.district_name IS '区域名称';



CREATE TABLE sys_areas(
	id (11) NOT NULL,
	type number(11) NOT NULL,
	name VARCHAR2(32) NOT NULL,
	parent_id number(100) NULL
	PRIMARY KEY (id)
);

COMMENT ON TABLE sys_areas IS '深圳市区域信息';
COMMENT ON COLUMN sys_areas.id IS 'ID';
COMMENT ON COLUMN sys_areas.type IS '区域类型 1:province/省/自治区/直辖市;2:city/地区(省下面的地级市);3:district/县/市(县级市)/区. 比如广东省的area_type 1,深圳市的area_type 2,福田区是深圳市的一个区,所以福田区的area_type = 3';
COMMENT ON COLUMN sys_areas.name IS '地域名称,如深圳市';
COMMENT ON COLUMN sys_areas.parent_id IS '父ID';


insert into sys_areas(id,type,name,parent_id)values(440000,1,'广东省',0);
insert into sys_areas(id,type,name,parent_id)values(440300,2,'深圳市',440000);
insert into sys_areas(id,type,name,parent_id)values(440301,3,'罗湖区',440300);
insert into sys_areas(id,type,name,parent_id)values(440302,3,'福田区',440300);
insert into sys_areas(id,type,name,parent_id)values(440303,3,'南山区',440300);
insert into sys_areas(id,type,name,parent_id)values(440304,3,'宝安区',440300);
insert into sys_areas(id,type,name,parent_id)values(440305,3,'龙岗区',440300);
insert into sys_areas(id,type,name,parent_id)values(440306,3,'盐田区',440300);
insert into sys_areas(id,type,name,parent_id)values(440307,3,'龙华区',440300);
insert into sys_areas(id,type,name,parent_id)values(440308,3,'坪山区',440300);
insert into sys_areas(id,type,name,parent_id)values(440309,3,'光明区',440300);
insert into sys_areas(id,type,name,parent_id)values(440310,3,'大鹏新区',440300);


insert into sys_areas_temp(id,type,name,parent_id)values('440000000000',1,'广东省','0');
insert into sys_areas_temp(id,type,name,parent_id)values('440300000000',2,'深圳市','440000000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440301000000',3,'市辖区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440303000000',3,'罗湖区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440304000000',3,'福田区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440305000000',3,'南山区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440306000000',3,'宝安区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440307000000',3,'龙岗区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440308000000',3,'盐田区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440309000000',3,'龙华区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440310000000',3,'坪山区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440311000000',3,'光明区','440300000000');
insert into sys_areas_temp(id,type,name,parent_id)values('440312000000',3,'大鹏新区','440300000000');


insert into sys_areas_temp(id,type,name,parent_id)values('440312000000',3,'大鹏新区','440300000000');

---开放接口个人信息
CREATE TABLE t_interface_person_info(
	id VARCHAR2(32) NOT NULL,
	person_name VARCHAR2(200) NOT NULL,
	mobile VARCHAR2(11) NOT NULL,
	email VARCHAR2(64) NOT NULL,
	id_type  NUMBER(11) NOT NULL,
  id_card  VARCHAR2(32) NOT NULL,
  trade_type VARCHAR2(64) NOT NULL,
  Work_unit VARCHAR2(64) NOT NULL,
  unit_nature  VARCHAR2(64) NOT NULL,
  address VARCHAR2(128) NOT NULL,
  purpose_use VARCHAR2(128) NOT NULL,
  audit_status NUMBER(11) NOT NULL,
  frozen_status NUMBER(11) NOT NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
	PRIMARY KEY (id)
);

create index index_mobile on t_interface_person_info(mobile);
COMMENT ON TABLE t_interface_person_info IS '开放接口个人信息';
COMMENT ON COLUMN t_interface_person_info.id IS '主键ID';
COMMENT ON COLUMN t_interface_person_info.person_name IS '姓名';
COMMENT ON COLUMN t_interface_person_info.mobile IS '手机';
COMMENT ON COLUMN t_interface_person_info.email IS '邮箱';
COMMENT ON COLUMN t_interface_person_info.id_type IS '证件类型';
COMMENT ON COLUMN t_interface_person_info.id_card IS '证件号';
COMMENT ON COLUMN t_interface_person_info.trade_type IS '所属行业';
COMMENT ON COLUMN t_interface_person_info.Work_unit IS '工作单位';
COMMENT ON COLUMN t_interface_person_info.unit_nature IS '单位性质';
COMMENT ON COLUMN t_interface_person_info.address IS '地址';
COMMENT ON COLUMN t_interface_person_info.purpose_use IS '使用目的';
COMMENT ON COLUMN t_interface_person_info.audit_status IS '1：待提交 2：待审核  4：未通过 3：已通过';
COMMENT ON COLUMN t_interface_person_info.frozen_status IS '冻结状态：0正常，1冻结';
COMMENT ON COLUMN t_interface_person_info.created_time IS '添加时间';
COMMENT ON COLUMN t_interface_person_info.create_user IS '添加人';
COMMENT ON COLUMN t_interface_person_info.modified_time IS '修改时间';
COMMENT ON COLUMN t_interface_person_info.update_user IS '修改人';
COMMENT ON COLUMN t_interface_person_info.del_flg IS '删除标志（0正常,1删除）';

---开放接口企业信息
CREATE TABLE t_interface_enterprise_info(
	id VARCHAR2(32) NOT NULL,
	Enterprise_name VARCHAR2(64) NOT NULL,
	trade_type VARCHAR2(64) NOT NULL,
	unit_nature  VARCHAR2(64) NOT NULL,
	id_type  NUMBER(11) NOT NULL,
  id_card VARCHAR2(64) NOT NULL,
  email VARCHAR2(64) NOT NULL,
  legal_name VARCHAR2(16) NOT NULL,
	legal_card   VARCHAR2(32)  NOT NULL,
	legal_card_type  NUMBER(11) NOT NULL,
  contacts VARCHAR2(16) NOT NULL,
	 mobile VARCHAR2(11) NOT NULL,
  address VARCHAR2(128) NOT NULL,
  tel 	 VARCHAR2(16) NOT NULL,
  purpose_use VARCHAR2(128) NOT NULL,
  audit_status NUMBER(11) NOT NULL,
  frozen_status NUMBER(11) NOT NULL,
  created_time TIMESTAMP NOT NULL,
  create_user VARCHAR2(32) NOT NULL,
  modified_time TIMESTAMP NOT NULL,
  update_user VARCHAR2(32) NOT NULL,
  del_flg NUMBER(11) DEFAULT 0,
	PRIMARY KEY (id)
);

create index index_mobile on t_interface_enterprise_info(mobile);
COMMENT ON TABLE t_interface_enterprise_info IS '开放接口企业信息';
COMMENT ON COLUMN t_interface_enterprise_info.id IS '主键ID';
COMMENT ON COLUMN t_interface_enterprise_info.Enterprise_name IS '企业名称';
COMMENT ON COLUMN t_interface_enterprise_info.trade_type IS '行业类型';
COMMENT ON COLUMN t_interface_enterprise_info.unit_nature IS '单位性质';
COMMENT ON COLUMN t_interface_enterprise_info.id_type IS '企业证件类型';
COMMENT ON COLUMN t_interface_enterprise_info.id_card IS '企业证件号';
COMMENT ON COLUMN t_interface_enterprise_info.email IS '邮箱';
COMMENT ON COLUMN t_interface_enterprise_info.legal_name IS '法人姓名';
COMMENT ON COLUMN t_interface_enterprise_info.legal_card IS '法人证件号';
COMMENT ON COLUMN t_interface_enterprise_info.legal_card_type IS '法人证件类型';
COMMENT ON COLUMN t_interface_enterprise_info.contacts IS '单位联系人';
COMMENT ON COLUMN t_interface_enterprise_info.mobile IS '手机号';
COMMENT ON COLUMN t_interface_enterprise_info.address IS '地址';
COMMENT ON COLUMN t_interface_enterprise_info.tel IS '企业电话';
COMMENT ON COLUMN t_interface_enterprise_info.purpose_use IS '使用目的';
COMMENT ON COLUMN t_interface_enterprise_info.audit_status IS '1：待提交 2：待审核  4：未通过 3：已通过';
COMMENT ON COLUMN t_interface_enterprise_info.frozen_status IS '冻结状态：0正常，1冻结';
COMMENT ON COLUMN t_interface_enterprise_info.created_time IS '添加时间';
COMMENT ON COLUMN t_interface_enterprise_info.create_user IS '添加人';
COMMENT ON COLUMN t_interface_enterprise_info.modified_time IS '修改时间';
COMMENT ON COLUMN t_interface_enterprise_info.update_user IS '修改人';
COMMENT ON COLUMN t_interface_enterprise_info.del_flg IS '删除标志（0正常,1删除）';

--系统接口用户表
CREATE TABLE sys_interface_user(
	id VARCHAR2(32) NOT NULL,
	account VARCHAR2(32) NOT NULL,
	password VARCHAR2(255) NOT NULL,
	authorized_password VARCHAR2(255) NOT NULL,
	salt VARCHAR2(45) NOT NULL,
	account_type NUMBER(11) DEFAULT 1,
	rel_id VARCHAR2(32) NOT NULL,
	status NUMBER(11) DEFAULT 1,
	del_flag NUMBER(11) DEFAULT 0,
	create_by_user VARCHAR2(32) NOT NULL,
	created_time TIMESTAMP NOT NULL,
	update_by_user VARCHAR2(32) NULL,
	modified_time TIMESTAMP NULL,
	PRIMARY KEY (id)
);

create unique index index_interface_user_account on sys_interface_user(account);
COMMENT ON TABLE sys_interface_user IS '系统接口用户表';
COMMENT ON COLUMN sys_interface_user.id IS 'ID';
COMMENT ON COLUMN sys_interface_user.account IS '登录账号';
COMMENT ON COLUMN sys_interface_user.password IS '密码';
COMMENT ON COLUMN sys_interface_user.authorized_password IS 'SSO授权密码';
COMMENT ON COLUMN sys_interface_user.salt IS '密码盐';
COMMENT ON COLUMN sys_interface_user.account_type IS '账号类型（1：个人 2：企业）';
COMMENT ON COLUMN sys_interface_user.rel_id IS '关联ID';
COMMENT ON COLUMN sys_interface_user.status IS '状态(0：冻结 1：正常  ）';
COMMENT ON COLUMN sys_interface_user.create_by_user IS '创建人';
COMMENT ON COLUMN sys_interface_user.created_time IS '创建时间';
COMMENT ON COLUMN sys_interface_user.update_by_user IS '更新人';
COMMENT ON COLUMN sys_interface_user.modified_time IS '更新时间';
COMMENT ON COLUMN sys_interface_user.del_flag IS '删除状态（0，正常，1已删除）';
