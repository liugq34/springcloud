(function() {
	$('.nav_cut a').on('click',function(){
		var _index = $(this).index();
		// $('.personData').eq(_index).removeClass('hide').siblings('.personData').addClass('hide');
		$('.personData').stop().eq(_index).show(300).siblings('.personData').hide(300);
		$(this).find('span').addClass('navActive').parent().siblings().find('span').removeClass('navActive');
	})
})()