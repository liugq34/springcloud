package com.jz.szwtl.auth.config.auth.encryp;

import com.jz.szwtl.util.MD5Util;
import org.springframework.security.crypto.password.PasswordEncoder;

public class MD5PasswordEncoder implements PasswordEncoder {


    @Override
    public String encode(CharSequence charSequence) {

        return MD5Util.encode(charSequence.toString());
    }

    @Override
    public boolean matches(CharSequence charSequence, String s) {
        return false;
    }
}
