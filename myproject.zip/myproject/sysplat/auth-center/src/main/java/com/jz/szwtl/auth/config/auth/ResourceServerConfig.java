package com.jz.szwtl.auth.config.auth;

import com.jz.szwtl.common.contant.StaticContant;
import com.jz.szwtl.config.security.authentication.CustomAccessDeniedHandler;
import com.jz.szwtl.config.security.authentication.CustomAuthenticationEntryPoint;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;


@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {


    @Bean
    public CustomAccessDeniedHandler customAccessDeniedHandler(){
        return new  CustomAccessDeniedHandler();
    }

    @Override
    public void configure(HttpSecurity http) throws Exception {
        http.antMatcher("/user")
                .exceptionHandling()
                .authenticationEntryPoint(new CustomAuthenticationEntryPoint())
        .and().authorizeRequests().anyRequest().authenticated();

    }

    @Override
    public void configure(ResourceServerSecurityConfigurer resources) {
        //与表OAUTH_CLIENT_DETAILS字段resource_ids一致
        resources.resourceId(StaticContant.OAUTH2_RESOURCE);
        resources
                .authenticationEntryPoint(new CustomAuthenticationEntryPoint())
                .accessDeniedHandler(customAccessDeniedHandler());
    }
}
