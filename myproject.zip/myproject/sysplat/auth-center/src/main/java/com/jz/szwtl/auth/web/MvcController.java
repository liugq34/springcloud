package com.jz.szwtl.auth.web;

import com.jz.szwtl.common.TokenDetail;
import com.jz.szwtl.common.UserTokenInfo;
import com.jz.szwtl.common.response.Result;
import com.jz.szwtl.config.feign.config.OAuth2FeignRequestInterceptor;
import lombok.extern.apachecommons.CommonsLog;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.Map;

@CommonsLog
@Controller
public class MvcController {


    @Autowired
    @Qualifier("consumerTokenServices")
    ConsumerTokenServices consumerTokenServices;

    @RequestMapping("/login")
    public ModelAndView login(){

        return new ModelAndView("login");
    }

    @ResponseBody
    @RequestMapping(value="/user")
    public Principal user(OAuth2Authentication authentication,Principal user){
        //UserTokenInfo baseUser = ((TokenDetail) authentication.getPrincipal()).getUserTokenInfo();
        return user;
    }


    /**
     * 登出回调
     * @param request
     * @param
     */
    @ResponseBody
    @RequestMapping("/logoutSuccess")
    public Result logoutSuccess(@RequestHeader(name="Authorization",required = false) String authorization,
                                HttpServletRequest request) {
        if(StringUtils.isNotEmpty(authorization)){
            String[] token = authorization.split(" ");
            if(token ==null || token.length != 2){
                return Result.createOther("退出失败,请求头信息错误");
            }
            if(!token[0].equalsIgnoreCase(OAuth2FeignRequestInterceptor.BEARER_TOKEN_TYPE)){
                return Result.createOther("退出失败,token类型错误");
            }
            boolean flag = consumerTokenServices.revokeToken(token[1]);
            if(flag){
                return Result.createSuccess("退出成功");
            }else{
                return Result.createOther("退出失败");
            }
        }
        return Result.createSuccess("退出成功");
    }

    /**
     * 授权页面
     * @param model
     * @return
     */
   @RequestMapping("/oauth/confirm_access")
    public ModelAndView authorizePage(Map<String, Object> model) {
        // 获取用户名
        String userName = ((UserDetails) SecurityContextHolder.getContext()
                .getAuthentication()
                .getPrincipal())
                .getUsername();
        model.put("userName", userName);
        return new ModelAndView("authorize", model);
    }

    /**
     * 主页，未从客户端跳转直接登陆会显示
     * @param model
     * @return
     */
    @RequestMapping("/")
    public ModelAndView indexPage(Map<String, Object> model) {
        // 获取用户名
        String userName = ((UserDetails) SecurityContextHolder.getContext()
                .getAuthentication()
                .getPrincipal())
                .getUsername();
        model.put("userName", userName);
        // 获取全部客户端应用
        return new ModelAndView("index", model);
    }
}
