package com.jz.szwtl.auth.service;

import com.jz.szwtl.common.UserTokenInfo;
import com.jz.szwtl.auth.config.auth.exception.CustomOauthException;
import com.jz.szwtl.auth.contant.StaticContant;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;


@Service
public class UsernameUserDetailService extends BaseUserDetailService {

    private final Logger logger = LoggerFactory.getLogger(UsernameUserDetailService.class);

    @Autowired
    JdbcTemplate jdbcTemplate;


    @Override
    protected UserTokenInfo getUser(String username) {
        if(StringUtils.isEmpty(username)){
            throw new CustomOauthException("请输入您的用户名");
        }
        try{

            UserTokenInfo userBase = jdbcTemplate.queryForObject(StaticContant.QUERY_USER,new Object[]{username},
                    new BeanPropertyRowMapper<>(UserTokenInfo.class));

            return userBase;
        }catch (Exception e){
            e.printStackTrace();
            logger.error("找不到该用户，用户名：" + username);
            throw new CustomOauthException("用户信息有误");
        }
    }
}
