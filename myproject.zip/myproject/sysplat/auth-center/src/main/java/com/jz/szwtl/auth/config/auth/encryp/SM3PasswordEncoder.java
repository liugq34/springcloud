package com.jz.szwtl.auth.config.auth.encryp;

import com.jz.szwtl.common.encryption.SM3Digest;
import lombok.extern.apachecommons.CommonsLog;
import org.springframework.security.crypto.password.PasswordEncoder;

@CommonsLog
public class SM3PasswordEncoder implements PasswordEncoder {


    @Override
    public String encode(CharSequence charSequence) {

        SM3Digest sm3Digest = new SM3Digest();
        return sm3Digest.encode(charSequence.toString());
    }

    /**
     *
     * @param charSequence 明文
     * @param s 密文
     * @return
     */
    @Override
    public boolean matches(CharSequence charSequence, String s) {

        SM3Digest sm3Digest = new SM3Digest();
        if(sm3Digest.encode(charSequence.toString()).equals(s)){
            return true;
        }
        return false;
    }
}
