package com.jz.szwtl;

import com.jz.szwtl.config.datasource.DruidConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.SpringCloudApplication;


@EnableConfigurationProperties({DruidConfig.class})
@SpringCloudApplication
public class AuthCenterApplication {


    public static void main(String[] args) {

        SpringApplication.run(AuthCenterApplication.class, args);
    }

}
