package com.jz.szwtl.auth.service;

import com.jz.szwtl.common.UserTokenInfo;
import org.springframework.stereotype.Service;

@Service
public class PhoneUserDetailService extends BaseUserDetailService {


    @Override
    protected UserTokenInfo getUser(String phone) {
        // 手机验证码调用FeignClient根据电话号码查询用户

        return new UserTokenInfo();
    }
}
