/*
package com.jz.szwtl.auth.config.auth.endpoint;

import com.jz.szwtl.common.response.Result;
import com.jz.szwtl.userserverapi.util.WebContextUtil;
import com.jz.szwtl.util.JsonUtils;
import lombok.extern.apachecommons.CommonsLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.oauth2.provider.token.ConsumerTokenServices;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@CommonsLog
@Controller
public class RevokeTokenEndpoint {

    @Autowired
    @Qualifier("consumerTokenServices")
    ConsumerTokenServices consumerTokenServices;


    @ResponseBody
    @RequestMapping(method = RequestMethod.GET, value = "/oauth/logout")
    @PreAuthorize("hasAuthority('login_user_right')")
    public Result logout() {

        log.error(JsonUtils.deserializer(WebContextUtil.getAccessToken()));
        if (consumerTokenServices.revokeToken(WebContextUtil.getAccessToken())){

            return Result.createSuccess("退出成功");
        }else{
            return Result.createError("退出失败");
        }
    }
}
*/
