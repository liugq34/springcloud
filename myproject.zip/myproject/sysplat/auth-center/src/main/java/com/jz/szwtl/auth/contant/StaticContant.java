package com.jz.szwtl.auth.contant;

public class StaticContant {


    public static final String QUERY_USER = "select * from systemuser_sys where loginid= ?";


    /**
     * 登录就拥有的权限
     */
    public static final String  LOGIN_USER_RIGHT = "user_right";
    //超级管理员权限
    public static final String SYS_ADMIN = "sys_admin";
}
