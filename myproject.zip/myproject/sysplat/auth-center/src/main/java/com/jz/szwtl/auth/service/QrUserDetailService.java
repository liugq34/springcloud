package com.jz.szwtl.auth.service;

import com.jz.szwtl.common.UserTokenInfo;
import org.springframework.stereotype.Service;

@Service
public class QrUserDetailService extends BaseUserDetailService {


    @Override
    protected UserTokenInfo getUser(String qrCode) {
        return null;
    }
}
