package com.jz.szwtl.auth.service;

import com.jz.szwtl.common.TokenDetail;
import com.jz.szwtl.common.UserTokenInfo;
import com.jz.szwtl.common.contant.Dict;
import com.jz.szwtl.auth.config.auth.exception.CustomOauthException;
import com.jz.szwtl.auth.contant.StaticContant;
import lombok.extern.apachecommons.CommonsLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.ArrayList;
import java.util.List;

@CommonsLog
public abstract class BaseUserDetailService implements UserDetailsService {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public TokenDetail loadUserByUsername(String s) throws CustomOauthException {

        UserTokenInfo baseUser = getUser(s);
        List roles = new ArrayList<>();
        //登录用户共有的权限
        roles.add(StaticContant.LOGIN_USER_RIGHT);
        //超级管理员(查询所有资源权限)
        roles.add(StaticContant.SYS_ADMIN);

        // 获取用户权限列表
        List<GrantedAuthority> authorities = convertToAuthorities(roles);
        User user =
                new User(baseUser.getLoginid(), baseUser.getPassword(),true, true, true, true, authorities);
        TokenDetail userDetail = new  TokenDetail(baseUser,user);

        return userDetail;
    }

    protected abstract UserTokenInfo getUser(String var1) ;


    private List<GrantedAuthority> convertToAuthorities(List<String> roles) {
        List<GrantedAuthority> authorities = new ArrayList();
        roles.forEach(e -> {
            // 存储用户、角色信息到GrantedAuthority，并放到GrantedAuthority列表
            GrantedAuthority authority = new SimpleGrantedAuthority(e);
            authorities.add(authority);
        });
        return authorities;
    }


}
