package com.jz.szwtl.auth.config.auth.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;
import org.springframework.stereotype.Component;

/**
 * 自定义endpoint异常
 */
@Component("mssWebResponseExceptionTranslator")
public class MssWebResponseExceptionTranslator implements WebResponseExceptionTranslator{


    @Override
    public ResponseEntity<OAuth2Exception> translate(Exception e) {

        return ResponseEntity
                .status(HttpStatus.OK)
                .body(new CustomOauthException("账号信息错误"));
    }
}

