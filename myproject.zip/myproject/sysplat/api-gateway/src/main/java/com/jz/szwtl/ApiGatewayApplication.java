package com.jz.szwtl;

import com.jz.szwtl.common.response.Result;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

@SpringBootApplication(exclude = DataSourceAutoConfiguration.class)
@RestController
@EnableFeignClients
public class ApiGatewayApplication {
    
    public static void main(String[] args) {
        
        SpringApplication.run(ApiGatewayApplication.class, args);
    }
    
    @RequestMapping("/fallback")
    public Mono<Result> fallback() {
        
        return Mono.just(Result.createTimeOut());
    }
    
}
