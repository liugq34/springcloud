package com.jz.szwtl.plat.mapper;

import com.jz.szwtl.vo.SystemuserSys;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SystemuserSysMapper {
    /**
     *
     * @mbggenerated
     */
    int deleteByPrimaryKey(Long userid);

    /**
     *
     * @mbggenerated
     */
    int insert(SystemuserSys record);

    /**
     *
     * @mbggenerated
     */
    int insertSelective(SystemuserSys record);

    /**
     *
     * @mbggenerated
     */
    SystemuserSys selectByPrimaryKey(Long userid);

    /**
     *
     * @mbggenerated
     */
    int updateByPrimaryKeySelective(SystemuserSys record);

    /**
     *
     * @mbggenerated
     */
    int updateByPrimaryKey(SystemuserSys record);

    List<SystemuserSys> findAll();

    String getMaxChildHierarchy(@Param("parentHierarchyLen") Integer parentHierarchyLen, @Param("childHierarchyLen") Integer childHierarchyLen, @Param("hierarchy")String hierarchy);


    SystemuserSys selectByLoginid(String loginid);

    int updatepassword(@Param("userid") Long userid,@Param("password") String password);


    List<SystemuserSys> selectChildrenByParentid(@Param("organizeid")long organizeid);
}