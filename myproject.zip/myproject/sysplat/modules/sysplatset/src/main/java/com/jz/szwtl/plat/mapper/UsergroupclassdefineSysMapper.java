package com.jz.szwtl.plat.mapper;

import com.jz.szwtl.vo.UsergroupclassdefineSys;

public interface UsergroupclassdefineSysMapper {
    /**
     *
     * @mbggenerated
     */
    int deleteByPrimaryKey(Long id);

    /**
     *
     * @mbggenerated
     */
    int insert(UsergroupclassdefineSys record);

    /**
     *
     * @mbggenerated
     */
    int insertSelective(UsergroupclassdefineSys record);

    /**
     *
     * @mbggenerated
     */
    UsergroupclassdefineSys selectByPrimaryKey(Long id);

    /**
     *
     * @mbggenerated
     */
    int updateByPrimaryKeySelective(UsergroupclassdefineSys record);

    /**
     *
     * @mbggenerated
     */
    int updateByPrimaryKey(UsergroupclassdefineSys record);
}