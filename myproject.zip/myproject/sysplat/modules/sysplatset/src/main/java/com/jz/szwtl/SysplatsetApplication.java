package com.jz.szwtl;

import com.jz.szwtl.config.annotation.ModuleConfiguration;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@ModuleConfiguration("场馆相关")
@MapperScan("com.jz.szwtl.plat.mapper")
public class SysplatsetApplication {

    public static void main(String[] args) {
        SpringApplication.run(SysplatsetApplication.class, args);
    }

}
