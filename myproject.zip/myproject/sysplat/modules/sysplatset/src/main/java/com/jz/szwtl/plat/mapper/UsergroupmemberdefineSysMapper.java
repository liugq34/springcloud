package com.jz.szwtl.plat.mapper;

import com.jz.szwtl.vo.UsergroupmemberdefineSys;

public interface UsergroupmemberdefineSysMapper {
    /**
     *
     * @mbggenerated
     */
    int insert(UsergroupmemberdefineSys record);

    /**
     *
     * @mbggenerated
     */
    int insertSelective(UsergroupmemberdefineSys record);
}