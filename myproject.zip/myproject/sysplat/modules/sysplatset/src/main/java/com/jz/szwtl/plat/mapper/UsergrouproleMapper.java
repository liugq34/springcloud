package com.jz.szwtl.plat.mapper;

import com.jz.szwtl.vo.UsergrouproleKey;

public interface UsergrouproleMapper {
    /**
     *
     * @mbggenerated
     */
    int deleteByPrimaryKey(UsergrouproleKey key);

    /**
     *
     * @mbggenerated
     */
    int insert(UsergrouproleKey record);

    /**
     *
     * @mbggenerated
     */
    int insertSelective(UsergrouproleKey record);
}