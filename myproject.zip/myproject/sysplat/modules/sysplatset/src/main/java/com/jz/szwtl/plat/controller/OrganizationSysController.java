package com.jz.szwtl.plat.controller;

import com.jz.szwtl.common.contant.I_ResourceConstant;
import com.jz.szwtl.common.exception.RestRuntimeException;
import com.jz.szwtl.common.response.OrganizationTreeResponse;
import com.jz.szwtl.common.response.Result;
import com.jz.szwtl.plat.service.OrganizationSysService;
import com.jz.szwtl.plat.service.SystemuserService;
import com.jz.szwtl.util.JsonUtils;
import com.jz.szwtl.util.StackTraceUtil;
import com.jz.szwtl.vo.OrganizationSys;
import com.jz.szwtl.vo.SystemuserSys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/v1/organization")
public class OrganizationSysController {

    @Autowired
    OrganizationSysService organizationSysService;
    @Autowired
    SystemuserService systemuserService;



    @PreAuthorize("hasAuthority('sys_admin')")
    @PostMapping("/save")
    public Result saveOrganization(@RequestBody  OrganizationSys organizationSys){
            try{
            organizationSysService.insert(organizationSys);
            }catch (Exception e){
               log.error(e.getMessage());
                StackTraceUtil.stackTraceToString(e);
                throw  new RestRuntimeException("系统异常");
            }
            return Result.createSuccess("成功");
    }

    @PreAuthorize("hasAuthority('sys_admin')")
    @PostMapping("/update")
    public Result update(@RequestBody  OrganizationSys organizationSys){
        log.error(JsonUtils.deserializer(organizationSys));
        try{
            organizationSysService.update(organizationSys);
        }catch (Exception e){
            log.error(e.getMessage());
            StackTraceUtil.stackTraceToString(e);
            throw  new RestRuntimeException("系统异常");
        }
        return Result.createSuccess("成功");
    }

    @PreAuthorize("hasAuthority('sys_admin')")
    @GetMapping("/findAll")
    public Result<List<?>> findAll(){

        //组织信息
        List<OrganizationSys> organizationSysList = organizationSysService.findAll();
        List<OrganizationTreeResponse> orgListTree = new ArrayList<>();
        for (OrganizationSys org:organizationSysList){
            OrganizationTreeResponse orgResp = new OrganizationTreeResponse();
            BeanUtils.copyProperties(org,orgResp);
            orgResp.setId(String.valueOf(org.getOrganizeid()));
            orgResp.setObjid(String.valueOf(org.getOrganizeid()));
            orgResp.setParentId(String.valueOf(org.getParentid()));
            orgResp.setResType(I_ResourceConstant.RESOURCE_TYPE_ORGANIZE);
            orgListTree.add(orgResp);
        }

        List<SystemuserSys> systemuserSysList = systemuserService.findAll();
        for (SystemuserSys user:systemuserSysList){

            OrganizationTreeResponse orgResp = new OrganizationTreeResponse();
            BeanUtils.copyProperties(user,orgResp);
            //防止用户id与组织id重复，重写用户id
            orgResp.setId(String.valueOf(user.getUserid())+"U");
            orgResp.setObjid(String.valueOf(user.getUserid()));
            orgResp.setParentId(String.valueOf(user.getOrganizeid()));
            orgResp.setResType(I_ResourceConstant.RESOURCE_TYPE_USER);
            orgListTree.add(orgResp);
        }
        List<OrganizationTreeResponse> topParents = new ArrayList<>();
        for (int i =0;i < orgListTree.size();i++){
            OrganizationTreeResponse organizationTreeResponse = orgListTree.get(i);
            if("0".equals(orgListTree.get(i).getParentId()) && I_ResourceConstant.RESOURCE_TYPE_ORGANIZE == orgListTree.get(i).getResType()){
                topParents.add(organizationTreeResponse);
            }
        }
        for (OrganizationTreeResponse p:topParents){
                p.setChildren(getChildren(orgListTree,p.getId()));
        }

        return Result.createSuccess(topParents);
    }

    /**
     * 递归取得子父节点的关系
     * @param data
     * @param id
     * @return
     */
    public List<OrganizationTreeResponse> getChildren(List<OrganizationTreeResponse> data, String id){
        //参数为数据库的（原数据，一级id）
        List<OrganizationTreeResponse> list = new ArrayList<>();

        if(data==null||data.size()==0){ return list; }

        for(OrganizationTreeResponse organizationTreeResponse:data ){

            if(id.equals(organizationTreeResponse.getParentId())){

                //如果本级id与下面数据的父id相同，就说明是子父级关系
                OrganizationTreeResponse treeObj = new OrganizationTreeResponse();
                BeanUtils.copyProperties(organizationTreeResponse,treeObj);
                if(I_ResourceConstant.RESOURCE_TYPE_ORGANIZE == organizationTreeResponse.getResType()){
                    treeObj.setChildren(getChildren(data,organizationTreeResponse.getId()));
                }
                list.add(treeObj);
            }
        } return list;
    }

    @PreAuthorize("hasAuthority('sys_admin')")
    @GetMapping("/getById")
    public Result getById(@RequestParam(required = true) String id,@RequestParam(required = true) char resType){
        Object obj = null;
        if(I_ResourceConstant.RESOURCE_TYPE_ORGANIZE == resType){
            obj = organizationSysService.getById(Long.valueOf(id));
        }
        else if(I_ResourceConstant.RESOURCE_TYPE_USER == resType){
            obj = systemuserService.getById(Long.valueOf(id));
        }
        return  Result.createSuccess(obj);
    }

    @PreAuthorize("hasAuthority('sys_admin')")
    @GetMapping("/delete")
    public Result delete(long id){

        if(id == 0L){
            return Result.createSuccess("失败");
        }
        organizationSysService.delete(id);
        return Result.createSuccess("删除成功");
    }

}
