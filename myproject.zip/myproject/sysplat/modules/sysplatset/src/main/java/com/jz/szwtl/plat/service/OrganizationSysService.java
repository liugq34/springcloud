package com.jz.szwtl.plat.service;

import com.jz.szwtl.common.contant.I_ResourceConstant;
import com.jz.szwtl.common.contant.StaticContant;
import com.jz.szwtl.common.exception.RestRuntimeException;
import com.jz.szwtl.plat.mapper.OrganizationSysMapper;
import com.jz.szwtl.util.HierarchyUtil;
import com.jz.szwtl.vo.OrganizationSys;
import com.jz.szwtl.vo.SystemuserSys;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class OrganizationSysService {

    @Autowired
    OrganizationSysMapper organizationSysMapper;
    @Autowired
    SystemuserService systemuserService;


    public void insert(OrganizationSys organizationSys){

        OrganizationSys porg  = organizationSysMapper.selectByPrimaryKey(organizationSys.getParentid());

        String nextHierarchy = organizationSysMapper.getMaxChildHierarchy(porg.getHierarchy().length(),
                porg.getHierarchy().length()+ I_ResourceConstant.RESOURCE_LEVEL_LENGTH,porg.getHierarchy());
        if(StringUtils.isNotEmpty(nextHierarchy)){

            nextHierarchy = porg.getHierarchy() + HierarchyUtil.getHexHierarchy(nextHierarchy.substring(nextHierarchy.length()-
                    I_ResourceConstant.RESOURCE_LEVEL_LENGTH,nextHierarchy.length()-1)) + I_ResourceConstant.RESOURCE_TYPE_ORGANIZE;
        }else{
            nextHierarchy = porg.getHierarchy() + HierarchyUtil.getMultiChar("0", I_ResourceConstant.RESOURCE_LEVEL_LENGTH-2) +
                    "1" + I_ResourceConstant.RESOURCE_TYPE_ORGANIZE;
        }
        organizationSys.setHierarchy(nextHierarchy);
        organizationSys.setHierarchyname(organizationSys.getName()+"."+porg.getHierarchyname());
        organizationSys.setDisplayorder(nextHierarchy);
        organizationSysMapper.insert(organizationSys);
    }

    public int update(OrganizationSys organizationSys){

        return organizationSysMapper.updateByPrimaryKey(organizationSys);
    }


    public List<OrganizationSys> findAll(){

        return organizationSysMapper.findAll();
    }

    public OrganizationSys getById(Long id){

        return organizationSysMapper.selectByPrimaryKey(Long.valueOf(id));
    }

    public int delete(long id){

        List<OrganizationSys> orgList = organizationSysMapper.selectChildrenByParentid(id);
        if (null != orgList && orgList.size() > 0){

            throw new RestRuntimeException("请先删除子节点");
        }
        List<SystemuserSys> userList = systemuserService.selectChildrenByParentid(id);
        if (null != userList && userList.size() > 0){

            throw new RestRuntimeException("请先删除子节点");
        }
        return organizationSysMapper.deleteByPrimaryKey(id);
    }
}
