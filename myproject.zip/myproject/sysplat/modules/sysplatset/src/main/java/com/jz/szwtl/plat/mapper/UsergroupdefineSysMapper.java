package com.jz.szwtl.plat.mapper;

import com.jz.szwtl.vo.UsergroupdefineSys;

public interface UsergroupdefineSysMapper {
    /**
     *
     * @mbggenerated
     */
    int deleteByPrimaryKey(Long groupid);

    /**
     *
     * @mbggenerated
     */
    int insert(UsergroupdefineSys record);

    /**
     *
     * @mbggenerated
     */
    int insertSelective(UsergroupdefineSys record);

    /**
     *
     * @mbggenerated
     */
    UsergroupdefineSys selectByPrimaryKey(Long groupid);

    /**
     *
     * @mbggenerated
     */
    int updateByPrimaryKeySelective(UsergroupdefineSys record);

    /**
     *
     * @mbggenerated
     */
    int updateByPrimaryKey(UsergroupdefineSys record);
}