package com.jz.szwtl.plat.service;

import com.jz.szwtl.common.contant.I_ResourceConstant;
import com.jz.szwtl.common.encryption.SM3Digest;
import com.jz.szwtl.common.exception.RestRuntimeException;
import com.jz.szwtl.common.request.UpdateUserPwd;
import com.jz.szwtl.common.response.ResultState;
import com.jz.szwtl.plat.mapper.OrganizationSysMapper;
import com.jz.szwtl.plat.mapper.SystemuserSysMapper;
import com.jz.szwtl.util.HierarchyUtil;
import com.jz.szwtl.vo.OrganizationSys;
import com.jz.szwtl.vo.SystemuserSys;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
@Transactional
public class SystemuserService {

    @Autowired
    SystemuserSysMapper systemuserSysMapper;
    @Autowired
    OrganizationSysMapper organizationSysMapper;

    public List<SystemuserSys> findAll(){

        return systemuserSysMapper.findAll();
    }

    public SystemuserSys getById(Long id){

        return systemuserSysMapper.selectByPrimaryKey(id);
    }

    public void insert(SystemuserSys systemuserSys){

        SystemuserSys user2 = systemuserSysMapper.selectByLoginid(systemuserSys.getLoginid());
        if(user2 != null){
            throw  new RestRuntimeException(ResultState.paramnopass,"该登录账号已经存在！");
        }

        OrganizationSys porg  = organizationSysMapper.selectByPrimaryKey(systemuserSys.getOrganizeid());
        String nextHierarchy = systemuserSysMapper.getMaxChildHierarchy(porg.getHierarchy().length(),
                porg.getHierarchy().length()+ I_ResourceConstant.RESOURCE_LEVEL_LENGTH,porg.getHierarchy());
        if(StringUtils.isNotEmpty(nextHierarchy)){

            nextHierarchy = porg.getHierarchy() + HierarchyUtil.getHexHierarchy(nextHierarchy.substring(nextHierarchy.length()-
                    I_ResourceConstant.RESOURCE_LEVEL_LENGTH,nextHierarchy.length()-1)) + I_ResourceConstant.RESOURCE_TYPE_USER;
        }else{
            nextHierarchy = porg.getHierarchy() + HierarchyUtil.getMultiChar("0", I_ResourceConstant.RESOURCE_LEVEL_LENGTH-2) +
                    "1" + I_ResourceConstant.RESOURCE_TYPE_USER;
        }
        systemuserSys.setHierarchy(nextHierarchy);
        systemuserSys.setHierarchyname(systemuserSys.getName()+"."+porg.getHierarchyname());
        systemuserSys.setDisplayorder(nextHierarchy);
        if(StringUtils.isEmpty(systemuserSys.getPassword())){
            systemuserSys.setPassword(I_ResourceConstant.DEFAULT_PWD);
        }
        SM3Digest sm3 = new SM3Digest();
        String encpassword = sm3.encode(systemuserSys.getPassword());
        systemuserSys.setPassword(encpassword);
        systemuserSys.setCreatetime(new Date());
        systemuserSysMapper.insert(systemuserSys);
    }


    public int updatepassword(UpdateUserPwd updateUserPwd){
        SM3Digest sm3 = new SM3Digest();
        String pwd = sm3.encode(updateUserPwd.getPassword());
      return systemuserSysMapper.updatepassword(Long.parseLong(updateUserPwd.getUserid()),pwd);
    }

    public int update(SystemuserSys systemuserSys){

        return systemuserSysMapper.updateByPrimaryKey(systemuserSys);
    }

    public int delete(long userid){

        return systemuserSysMapper.deleteByPrimaryKey(userid);
    }

    public List<SystemuserSys> selectChildrenByParentid(long organizeid){

        return systemuserSysMapper.selectChildrenByParentid(organizeid);
    }
}
