package com.jz.szwtl.plat.controller;

import com.jz.szwtl.WebContextUtil;
import com.jz.szwtl.common.UserTokenInfo;
import com.jz.szwtl.common.exception.RestRuntimeException;
import com.jz.szwtl.common.request.UpdateUserPwd;
import com.jz.szwtl.common.response.Result;
import com.jz.szwtl.common.response.ResultState;
import com.jz.szwtl.plat.service.SystemuserService;
import com.jz.szwtl.util.StackTraceUtil;
import com.jz.szwtl.vo.OrganizationSys;
import com.jz.szwtl.vo.SystemuserSys;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Slf4j
@RestController
@RequestMapping("/v1/user")
public class SystemuserController {

    @Autowired
    SystemuserService systemuserService;


    @PreAuthorize("hasAuthority('sys_admin')")
    @PostMapping("/save")
    public Result addUser(@RequestBody @Valid SystemuserSys systemuserSys){

        try{
            systemuserService.insert(systemuserSys);

        }catch (Exception e){
            e.printStackTrace();
            StackTraceUtil.stackTraceToString(e);
            throw  new RestRuntimeException("系统异常");
        }
        return Result.createSuccess("成功");
    }
    @PreAuthorize("hasAuthority('sys_admin')")
    @PostMapping("/update")
    public Result update(@RequestBody @Valid SystemuserSys systemuserSys){
        try{
            systemuserService.update(systemuserSys);
        }catch (Exception e){
            e.printStackTrace();
            StackTraceUtil.stackTraceToString(e);
            throw  new RestRuntimeException("系统异常");
        }
        return Result.createSuccess("成功");
    }

    @PreAuthorize("hasAuthority('sys_admin')")
    @GetMapping("/delete")
    public Result delete(long userid){

        if(userid == 0L){
            return Result.createSuccess("删除失败");
        }
        try{
            systemuserService.delete(userid);
        }catch (Exception e){
            StackTraceUtil.stackTraceToString(e);
            throw  new RestRuntimeException("系统异常");
        }
        return Result.createSuccess("删除成功");
    }

    @PreAuthorize("hasAuthority('sys_admin')")
    @PostMapping("/updatepassword")
    public Result updatepassword(@RequestBody @Valid UpdateUserPwd updateUserPwd){

        if(!updateUserPwd.getPassword().equals(updateUserPwd.getRepassword())){

            throw new RestRuntimeException(ResultState.paramnopass,"");
        }
        systemuserService.updatepassword(updateUserPwd);
        return Result.createSuccess("修改密码成功");
    }
}
