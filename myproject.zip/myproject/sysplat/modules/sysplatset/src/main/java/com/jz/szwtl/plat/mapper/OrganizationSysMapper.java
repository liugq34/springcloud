package com.jz.szwtl.plat.mapper;

import com.jz.szwtl.vo.OrganizationSys;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface OrganizationSysMapper {

    int deleteByPrimaryKey(Long organizeid);

    int insert(OrganizationSys record);

    int insertSelective(OrganizationSys record);

    OrganizationSys selectByPrimaryKey(Long organizeid);

    int updateByPrimaryKeySelective(OrganizationSys record);

    int updateByPrimaryKey(OrganizationSys record);

    String getMaxChildHierarchy(@Param("parentHierarchyLen") Integer parentHierarchyLen, @Param("childHierarchyLen") Integer childHierarchyLen, @Param("hierarchy")String hierarchy);

    List<OrganizationSys> findAll();

    List<OrganizationSys> selectChildrenByParentid(@Param("parentId")long parentId);
}