package com.jz.szwtl.common.response;

public enum ResultState {

    /**
     * 成功
     */
    success(200),
    /**
     * 超时
     */
    timeout(400),
    /**
     * 签名错误
     */
    signatureerror(401),
    /**
     * 系统异常
     */
    systemerror(500),
    /**
     * 权限不足
     */
    permissiondeny(402),
    /**
     * 参数校验不通过
     */
    paramnopass(600),
    /**
     * 其他
     */
    others(1000);



    private int val;

    private ResultState(int val){

        this.val = val;
    }

    public int getVal() {
        return val;
    }

    public void setVal(int val) {
        this.val = val;
    }
}
