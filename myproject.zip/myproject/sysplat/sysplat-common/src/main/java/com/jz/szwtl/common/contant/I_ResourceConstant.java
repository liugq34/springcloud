package com.jz.szwtl.common.contant;

public class I_ResourceConstant {

    /**
     * 节点长度
     */
    public static int RESOURCE_LEVEL_LENGTH = 5;

    /**
     * 组织
     */
    public static char RESOURCE_TYPE_ORGANIZE = 'O';

    /**
     * 用户
     */
    public static char RESOURCE_TYPE_USER = 'U';

    /**
     * 服务
     */
    public static char RESOURCE_TYPE_SERVICE = 'S';

    /**
     * 用户组分类
     */
    public static char RESOURCE_TYPE_GROUPCLASS = 'C';

    /**
     * 用户组
     */
    public static char RESOURCE_TYPE_USERGROUP = 'G';

    /**
     * 别名
     */
    public static char RESOURCE_TYPE_ALIAS = 'A';

    /**
     * 特殊：登录
     */
    public static char RESOURCE_TYPE_LOGON = '0';

    /**
     * 特殊：退出
     */
    public static char RESOURCE_TYPE_LOGOUT = '1';



    public static  String ALERT_MESSAGE = "message";

    public static String ALERT_SCRIPT = "script";

    public static String ALERT_URL = "url";

    /**
     * 主管：授权权限，可以将自己拥有的管理权限授权给其他的对象。
     */
    public static int RESOURCE_RIGHT_MANAGE = 1;
    /**
     * 浏览：对授权资源的浏览权限
     */
    public static int RESOURCE_RIGHT_ACCESS = 2;
    /**
     * 修改：对授权资源的修改权限
     */
    public static int RESOURCE_RIGHT_MODIFY = 4;
    /**
     * 创建：对授权资源的创建权限
     */
    public static int RESOURCE_RIGHT_CREATE = 8;

    /**
     * 删除：对授权资源的删除权限
     */
    public static int RESOURCE_RIGHT_DELETE = 16;

    public static int RESOURCE_RIGHT_CUSTOM = 256;


    /**
     * 权限的访问方式
     */
    int RESOURCE_ACCESS_MANAGE = 0;

    int RESOURCE_ACCESS_APPLY  = 1;

    /**
     * 默认密码
     */
    public static String DEFAULT_PWD = "888888";
}
