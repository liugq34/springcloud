package com.jz.szwtl.common.contant;

/**
 * 数据字典
 */
public class Dict {

    /**
     * 数据状态 1 正常，2 冻结
     */
    public static final Integer data_status_normal = 1;
    public static final Integer data_status_frozen = 2;
    /**
     * 审核状态 0 新增，1 初审通过，10 初审未通过，2 终审通过，20 终审未通过, 3 驳回
     */
    public static final Integer audit_status_new = 0;
    public static final Integer audit_status_onepass = 1;
    public static final Integer audit_status_onenopass = 10;
    public static final Integer audit_status_twopass = 2;
    public static final Integer audit_status_twonopass = 20;

    /**
     * 接口类型 1 管理系统，2 操作系统，3 前台
     */
    public static final Integer srouce_system_admin_api = 1;
    public static final Integer srouce_system_cust_api = 2;
    public static final Integer srouce_frontend_cust_api = 3;

    /**
     * 删除状态
     */
    public static final Integer delete_no = 1;
    public static final Integer delete_yes = 2;

    /**
     * 组织类型 1 政府机关，2 企业或场馆
     */
    public static final Integer organization_type_gov = 1;
    public static final Integer organization_type_enterprise = 2;

    /**
     * 用户类型 1 个人员工 ,2 企业用户，10 超级管理员
     */
    public static final Integer user_type_personal = 1;
    public static final Integer user_type_enterprise = 2;
    public static final Integer user_type_administrator = 10;






}
