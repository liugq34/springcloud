package com.jz.szwtl.common.request;


public class BaseRequestPojo {

    private Integer pageSize = 10;
    private Integer pageNo = 1;


    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNo() {
        return pageNo;
    }

    public void setPageNo(Integer pageNo) {
        this.pageNo = pageNo;
    }
}
