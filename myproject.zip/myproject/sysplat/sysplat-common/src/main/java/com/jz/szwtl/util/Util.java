package com.jz.szwtl.util;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;

public class Util {


    /**
     * 获取 @RequestBody的参数
     * @param request
     * @return
     */
    public static String getRequestBodyParams(HttpServletRequest request){

        try {
            ServletInputStream ris = request.getInputStream();
            if(null == ris){
                return "";
            }
            StringBuilder content = new StringBuilder();
            byte[] b = new byte[1024];
            int lens = -1;
            while ((lens = ris.read(b)) > 0) {
                content.append(new String(b, 0, lens,"utf-8"));
            }
            String reqJson = content.toString();
            return reqJson;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

}
