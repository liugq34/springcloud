package com.jz.szwtl.common.response;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * @author:yaohw
 * @JsonInclude(JsonInclude.Include.NON_NULL) 设置null字段不进行json
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Result<T> {
    
    private int state;
    
    private String msg;
    
    private T data;
    
    
    public static <T> Result<T> createSuccess(String msg, T data) {
        
        return create(ResultState.success, msg, data);
    }
    
    public static <T> Result<T> createSuccess(T data) {
        
        return create(ResultState.success, "调用接口成功", data);
    }
    
    public static <T> Result<T> createSuccess(String msg) {
        
        return create(ResultState.success, msg, null);
    }
    
    public static <T> Result<T> createError() {
        
        return createError("系统错误");
    }
    
    public static <T> Result<T> createError(String msg) {
        
        return create(ResultState.systemerror, msg, null);
    }
    
    public static <T> Result<T> createTimeOut() {
        
        return createTimeOut("请求超时");
    }
    
    public static <T> Result<T> createTimeOut(String msg) {
        
        return create(ResultState.timeout, msg, null);
    }
    
    public static <T> Result<T> createPermissiondeny() {
        
        return createPermissiondeny("权限不足");
    }
    
    public static <T> Result<T> createPermissiondeny(String msg) {
        
        return create(ResultState.permissiondeny, msg, null);
    }
    
    public static <T> Result<T> createSignature() {
        
        return createSignature("签名已过期或签名不合法");
    }
    
    public static <T> Result<T> createSignature(String msg) {
        
        return create(ResultState.signatureerror, msg, null);
    }
    
    public static <T> Result<T> createParamNoPass(String msg) {
        
        return create(ResultState.paramnopass, msg, null);
    }
    
    public static <T> Result<T> createOther(String msg) {
        
        return create(ResultState.others, msg, null);
    }
    
    public static <T> Result<T> create(ResultState state, String msg, T data) {
        
        Result result = new Result<>();
        result.setState(state.getVal());
        result.setMsg(msg);
        result.setData(data);
        return result;
    }
    
    
    public int getState() {
        
        return state;
    }
    
    public void setState(int state) {
        
        this.state = state;
    }
    
    public String getMsg() {
        
        return msg;
    }
    
    public void setMsg(String msg) {
        
        this.msg = msg;
    }
    
    public T getData() {
        
        return data;
    }
    
    public void setData(T data) {
        
        this.data = data;
    }
}
