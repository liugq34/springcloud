/*
package com.jz.szwtl.common.contant;

*/
/**
 * 自增type
 *//*

public class Sequence {

    */
/**
     * 市级 region_code（初始值40）
     *//*

    public static final Integer city_region_code = 1;
    */
/**
     * 区级 region_code（初始值1000）
     *//*

    public static final Integer area_region_code = 2;
    */
/**
     * 街道 region_code（初始值1000）
     *//*

    public static final Integer street_region_code = 3;
    */
/**
     * 社区 region_code（初始值1000）
     *//*

    public static final Integer street_region_community=4;

}
*/
