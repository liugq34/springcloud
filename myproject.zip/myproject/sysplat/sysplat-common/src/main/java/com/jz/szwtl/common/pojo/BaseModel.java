package com.jz.szwtl.common.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class BaseModel implements Serializable {

    @ApiModelProperty(value = "状态 字典码 status",required = true,name="status",hidden = true)
    private Integer status;
    @ApiModelProperty(value = "审核状态:字典码 audit_status",required = true,name="auditStatus",hidden = true)
    private Integer auditStatus;
    @ApiModelProperty(value = "添加时间",required = true,name="addtime",hidden = true)
    private Date addtime;
    @ApiModelProperty(value = "添加人",required = true,name="addtime",hidden = true)
    private String adduser;
    @ApiModelProperty(value = "删除状态",required = true,name="delflag",hidden = true)
    private Integer delflag;
    @ApiModelProperty(value = "更新时间",required = true,name="updatetime",hidden = true)
    private Date updatetime;

}
