package com.jz.szwtl.common.exception;

import com.jz.szwtl.common.response.ResultState;

import java.util.Objects;

/**
 * 统一RuntimeException
 */
public class RestRuntimeException extends  RuntimeException {


    private ResultState state;
    private String msg;

    public RestRuntimeException() {
    }
    public RestRuntimeException(String msg) {
        this.state = ResultState.others;
        this.msg = msg;
    }
    public RestRuntimeException(ResultState state, String msg) {
        super(msg);
        this.state = state;
        this.msg = msg;
    }

    public ResultState getState() {
        return state;
    }

    public void setState(ResultState state) {
        this.state = state;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }


    @Override
    public int hashCode() {

        return Objects.hash(state, msg);
    }
}
