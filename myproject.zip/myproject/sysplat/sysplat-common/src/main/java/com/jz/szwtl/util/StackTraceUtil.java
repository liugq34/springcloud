package com.jz.szwtl.util;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * @author: yaohw
 * @create: 2019-01-08 16:35
 **/
public class StackTraceUtil {

    /**
     * 将异常栈打印信息转字符串
     * @param e 异常类
     * @return 需要打印的栈信息字符串
     */
    public static String stackTraceToString(Throwable e){
        StringWriter sw = new StringWriter();
        e.printStackTrace(new PrintWriter(sw, true));
        return  sw.toString();
    }

}
