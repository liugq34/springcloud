package com.jz.szwtl.common.contant;

/**
 * eureka服务名称
 */
public class InterfaceService {


    public final static String USER_SERVICE = "user-server";
    public final static String ACTIVITY_SERVICE = "activity-service";
    public final static String VENUE_SERVICE = "venue-service";
    public final static String COMMON_SERVER="common-service";
    public final static String CONTENT_SERVICE = "content-service";

    //前端服务
    public final static String USER_SERVICE_FRONT = "user-server-front";
    public final static String ACTIVITY_SERVICE_FRONT = "activity-service-front";
    public final static String VENUE_SERVICE_FRONT = "venue-service-front";
    public final static String COMMON_SERVER_FRONT ="common-service-front";
    public final static String CONTENT_SERVICE_FONT = "content-service-front";
}
