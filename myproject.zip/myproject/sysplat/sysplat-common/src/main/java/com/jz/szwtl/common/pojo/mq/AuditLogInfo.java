package com.jz.szwtl.common.pojo.mq;

import lombok.Data;

import java.io.Serializable;

/**
 * 审核信息
 */
@Data
public class AuditLogInfo implements Serializable {


    private String objid;
    private String descript;
    private String ispass;
    private Integer audit_status;

}
