package com.jz.szwtl.common.response;

import java.io.Serializable;
import java.util.List;

public class BaseTreeResponse implements Serializable {

    private String id;
    private String parentId;
    private List<? extends BaseTreeResponse> children;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getParentId() {
        return parentId;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public List<? extends BaseTreeResponse> getChildren() {
        return children;
    }

    public void setChildren(List<? extends BaseTreeResponse> children) {
        this.children = children;
    }
}
