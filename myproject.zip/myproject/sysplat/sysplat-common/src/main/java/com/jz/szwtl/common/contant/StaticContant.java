package com.jz.szwtl.common.contant;

/**
 * 静态常量
 */
public class StaticContant {


    public final static String OAUTH2_RESOURCE = "unity-resource";
    //rabbitmq queues
    //数据审核队列
    public final static String AUDIT_QUEUES = "audit_queues";



}
