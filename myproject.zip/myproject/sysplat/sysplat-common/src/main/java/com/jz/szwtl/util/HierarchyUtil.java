package com.jz.szwtl.util;

import com.jz.szwtl.common.contant.I_ResourceConstant;
import com.jz.szwtl.common.exception.RestRuntimeException;
import com.jz.szwtl.common.response.ResultState;

public class HierarchyUtil {

    public static String getMultiChar(String str, int len) {
        StringBuffer tempBuf = new StringBuffer();

        if (str == null){
            return "";
        }

        for (int i = 0; i < len; i++) {
            tempBuf.append(str);
        }
        return tempBuf.toString();
    }

    /**
     * 层次码十六进制的算法
     *
     * @param nodeCode
     * @return
     */
    public static String getHexHierarchy(String nodeCode) {
        StringBuffer sb = new StringBuffer(nodeCode);
        char ch = ' ';

        if (sb.length() != I_ResourceConstant.RESOURCE_LEVEL_LENGTH - 1) {
            throw new RestRuntimeException(ResultState.others,"节点层次码不是固定的长度"
                    + I_ResourceConstant.RESOURCE_LEVEL_LENGTH);
        }
        ch = sb.charAt(sb.length() - 1);
        if (ch == '9') {
            ch = 'A';
        } else {
            ch = (char) (ch + 1);
        }
        sb.replace(sb.length() - 1, sb.length(), String.valueOf(ch));
        // 进位处理

        for (int i = sb.length() - 1; i >= 0; i--) {
            if (sb.charAt(i) > 'F') {
                if (i == 0) {throw new RestRuntimeException(ResultState.others,"节点层次码超过指定的范围"); }
                ch = (char) (sb.charAt(i) - 'F' + 47);
                // 当前位处理
                sb.replace(i, i + 1, String.valueOf(ch));
                // 下一位增1
                ch = sb.charAt(i - 1);
                if (ch == '9') {
                    ch = 'A';
                } else {
                    ch = (char) (ch + 1);
                }
                sb.replace(i - 1, i, String.valueOf(ch));
            } else {
                break;
            }
        }

        return sb.toString();
    }
}
