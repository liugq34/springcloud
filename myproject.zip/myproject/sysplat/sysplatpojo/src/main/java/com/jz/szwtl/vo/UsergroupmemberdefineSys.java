package com.jz.szwtl.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
@Data
public class UsergroupmemberdefineSys implements Serializable {
    /**
     * null
     */
    private long groupid;

    /**
     * null
     */
    private String userid;

    /**
     * null
     */
    private Integer orderindex;


}