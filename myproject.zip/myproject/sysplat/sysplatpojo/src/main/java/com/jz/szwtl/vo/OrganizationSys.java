package com.jz.szwtl.vo;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
public class OrganizationSys implements Serializable {


    private long organizeid;
    private long parentid;
    @NotBlank(message = "组织名称不能为空")
    private String name;
    private String hierarchy;
    private String hierarchyname;
    private String principal;
    private String linkman;
    private String contact;
    private String address;
    private String description;
    private String displayorder;
    private String unitcode;
    private String codecnname;
    private String orgztype;

}