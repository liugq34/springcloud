package com.jz.szwtl.vo;

import lombok.Data;

import java.io.Serializable;
@Data
public class UsergroupclassdefineSys implements Serializable {
    /**
     * null
     */
    private long id;

    /**
     * null
     */
    private long parentid;

    /**
     * null
     */
    private String name;

    /**
     * null
     */
    private String hierarchy;

    /**
     * null
     */
    private String hierarchyname;

    /**
     * null
     */
    private String description;

    /**
     * null
     */
    private String displayorder;


}