package com.jz.szwtl.common.request;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

/**
 * @author liuguoquan
 * @date 2019-07-08 16:05
 * @description 修改用户密码请求实体
 */
@Data
public class UpdateUserPwd implements Serializable {

    @NotBlank(message = "请先选择用户")
    private String userid;
    @NotBlank(message = "新密码不能为空")
    private String password;
    @NotBlank(message = "确认密码不能为空")
    private String repassword;
}
