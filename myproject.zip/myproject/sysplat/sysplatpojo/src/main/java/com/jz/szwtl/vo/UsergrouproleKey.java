package com.jz.szwtl.vo;

import java.io.Serializable;
import java.math.BigDecimal;

public class UsergrouproleKey implements Serializable {
    /**
     * null
     */
    private long userid;

    /**
     * null
     */
    private long groupid;

    /**
     * null
     */
    private long roleid;


}