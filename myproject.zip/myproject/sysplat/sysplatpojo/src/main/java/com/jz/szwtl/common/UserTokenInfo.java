package com.jz.szwtl.common;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class UserTokenInfo implements Serializable {

    private long userid;
    private String loginid;
    private String password;
    private String name;
    private Integer enctype;
    private Integer sex;
    private Long organizeid;
    private String hierarchy;
    private String hierarchyname;
    private String contact;
    private String email;
    private Date expiredate;
    private Date lastlogintime;
    private String creator;
    private Date createtime;
    private Integer state;
    private Integer displaymethod;
    private String displayorder;
    private String description;
}
