package com.jz.szwtl.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jz.szwtl.vaild.annotation.IsPhone;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.Date;

@Data
public class SystemuserSys implements Serializable {
    /**
     * null
     */
    private long userid;

    /**
     * null
     */
    @NotBlank
    private String loginid;

    /**
     * null
     */
    private String password;

    /**
     * null
     */
    @NotBlank
    private String name;

    /**
     * null
     */
    private Integer enctype;

    /**
     * null
     */
    private Integer sex;

    /**
     * null
     */
    private long organizeid;
    /**
     * null
     */
    private String hierarchy;

    /**
     * null
     */
    private String hierarchyname;

    /**
     * null
     */
    private String contact;

    /**
     * null
     */
    private String email;

    /**
     * null
     */
    private String officephone;

    /**
     * null
     */
    @IsPhone(required = false)
    private String mobile;

    /**
     * null
     */
    @JsonFormat(timezone = "GMT+8",pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date expiredate;

    /**
     * null
     */
    private Date lastlogintime;

    /**
     * null
     */
    private String creator;

    /**
     * null
     */
    private Date createtime;

    /**
     * null
     */
    private Integer state;

    /**
     * null
     */
    private Integer displaymethod;

    /**
     * null
     */
    private String displayorder;

    /**
     * null
     */
    private String description;


}