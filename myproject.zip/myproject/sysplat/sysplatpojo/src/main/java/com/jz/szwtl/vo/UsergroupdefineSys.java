package com.jz.szwtl.vo;

import lombok.Data;

import java.io.Serializable;
@Data
public class UsergroupdefineSys implements Serializable {
    /**
     * null
     */
    private long groupid;

    /**
     * null
     */
    private long groupclassid;

    /**
     * null
     */
    private String groupname;

    /**
     * null
     */
    private String hierarchy;

    /**
     * null
     */
    private String hierarchyname;

    /**
     * null
     */
    private String description;

    /**
     * null
     */
    private String displayorder;


}