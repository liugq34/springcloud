package com.jz.szwtl.common.response;

import com.jz.szwtl.common.pojo.TreeObj;
import lombok.Data;

@Data
public class OrganizationTreeResponse extends TreeObj {

    private String hierarchy;
    private String hierarchyname;
    private String displayorder;
    private char resType;
    private String objid;
}
