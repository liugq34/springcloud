package com.jz.szwtl.config.swagger;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.OAuthBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.util.Arrays;
import java.util.List;

@Configuration
@EnableSwagger2
@ConfigurationProperties(
        prefix = "swagger.security.oauth2"
)
public class SwaggerConfig {

    private String tokenInfoUri;
    private String authorizeInfoUri;

    @Bean
    public Docket createRestApi() {// 创建API基本信息
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo())
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.jz.szwtl"))
                .paths(PathSelectors.any())
                .build()
                .securitySchemes(Arrays.asList(oauth()))
                .securityContexts(Arrays.asList(securityContext()));
    }

    /**
     *  创建API的基本信息，这些信息会在Swagger UI中进行显示
     * @return
     */
    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("深圳市文体设施数字改造系统 RESTful APIs")
                .description("文体旅游局提供的用户信息管理RESTful APIs")
                .contact(new Contact("联系人", "http://wtl.sz.gov.cn/", "xx@qq.com"))
                .version("2.0")
                .build();
    }

    @Bean
    SecurityContext securityContext() {
        AuthorizationScope[] scopes = new AuthorizationScope[]
                {new AuthorizationScope("read", "for read operations")};
        SecurityReference securityReference = SecurityReference
                .builder()
                .reference("spring_oauth")
                .scopes(scopes)
                .build();

        return SecurityContext
                .builder()
                .securityReferences(Arrays.asList(securityReference))
                .forPaths(PathSelectors.any())
                .build();
    }

    @Bean
    SecurityScheme oauth() {

        return new OAuthBuilder()
                .name("spring_oauth")
                .grantTypes(grantTypes())
                .build();
    }

    List<GrantType> grantTypes() {
        GrantType grants = new AuthorizationCodeGrant(
                new TokenRequestEndpoint(authorizeInfoUri, "client", "123456"),
                new TokenEndpoint(tokenInfoUri, "oauth"));
        return Arrays.asList(grants);
    }


    public String getTokenInfoUri() {
        return tokenInfoUri;
    }

    public void setTokenInfoUri(String tokenInfoUri) {
        this.tokenInfoUri = tokenInfoUri;
    }

    public String getAuthorizeInfoUri() {
        return authorizeInfoUri;
    }

    public void setAuthorizeInfoUri(String authorizeInfoUri) {
        this.authorizeInfoUri = authorizeInfoUri;
    }
}