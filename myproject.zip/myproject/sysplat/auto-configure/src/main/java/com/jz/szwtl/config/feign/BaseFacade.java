package com.jz.szwtl.config.feign;

import com.github.pagehelper.PageInfo;
import com.jz.szwtl.common.response.Result;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

public abstract class BaseFacade<T, R> {

    /**
     * 表格查询
     */
    @RequestMapping(value = "/queryRecord", method = RequestMethod.POST)
    public abstract Result<PageInfo> queryRecord(@RequestBody  R query);

    /**
     * 根据id获取
     */
    @RequestMapping(value = "/queryById", method = RequestMethod.GET)
    public abstract Result<T> queryById(@RequestParam(value = "id",required = true) String id);

    /**
     * 添加记录
     */
    @RequestMapping(value = "/addRecord", method = RequestMethod.POST)
    public abstract Result<T> addRecord(@RequestBody  T record);

    /**
     * 根据id删除记录
     */
    @RequestMapping(value = "/deleteRecord", method = RequestMethod.GET)
    public abstract Result<T> deleteRecord(@RequestParam(value = "id",required = true) String id);

    /**
     * 更新记录
     */
    @RequestMapping(value = "/updateRecord", method = RequestMethod.POST)
    public abstract Result<T> updateRecord(@RequestBody T record);
}
