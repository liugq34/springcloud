
package com.jz.szwtl.config.exception;

import com.jz.szwtl.common.exception.RestRuntimeException;
import com.jz.szwtl.common.response.Result;
import com.jz.szwtl.common.response.ResultState;
import lombok.extern.log4j.Log4j2;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.InvalidGrantException;
import org.springframework.stereotype.Component;
import org.springframework.validation.ObjectError;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.validation.ValidationException;
import java.util.ArrayList;
import java.util.List;


@Log4j2
@RestControllerAdvice
@Component
public class ExceptionHandler {

    @Bean
    public MethodValidationPostProcessor methodValidationPostProcessor() {
        return new MethodValidationPostProcessor();
    }

    @org.springframework.web.bind.annotation.ExceptionHandler(ValidationException.class)
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public Result BadHandle(ValidationException exception) {
        String messages= exception.getMessage();
        String[] strings = messages.split(",");
        if(strings.length==1){
            String message = strings[0].substring(strings[0].lastIndexOf(":") + 1);
            return Result.create(ResultState.paramnopass,"参数校验不通过",message);
        }
        List<String> list=new ArrayList<>(strings.length);
        for(int i=0;i<strings.length;i++){
            String message = strings[i].substring(strings[i].lastIndexOf(":") + 1);
            list.add(message);
        }
        return Result.create(ResultState.paramnopass,"参数校验不通过",list);
    }


    /**
     * 参数校验异常统一处理
     * @param e
     * @return
     */
    @org.springframework.web.bind.annotation.ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public Result handle(MethodArgumentNotValidException e){
        List<ObjectError> allErrors = e.getBindingResult().getAllErrors();
        //List<String> messages=new ArrayList<>(allErrors.size());
        StringBuffer messages = new StringBuffer("");
        for(ObjectError error:allErrors){
            messages.append(error.getDefaultMessage()+";");
        }
        log.warn("参数校验失败");
        return Result.create(ResultState.paramnopass,messages.toString(),null);
    }

    /**
     * 统一抛出异常处理
     * @param e
     * @return
     */
    @org.springframework.web.bind.annotation.ExceptionHandler(RestRuntimeException.class)
    @ResponseBody
    public Result handle(RestRuntimeException e){

        return Result.create(e.getState(),e.getMsg(),null);
    }

}


