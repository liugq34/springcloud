package com.jz.szwtl.config.annotation;

import com.jz.szwtl.config.datasource.DruidConfig;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.client.SpringCloudApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

import java.lang.annotation.*;

@Target({ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
//@EnableFeignClients
@EnableConfigurationProperties({DruidConfig.class})
@SpringCloudApplication
@EnableGlobalMethodSecurity(prePostEnabled = true)
public @interface ModuleConfiguration {

    String value() default "";

}
