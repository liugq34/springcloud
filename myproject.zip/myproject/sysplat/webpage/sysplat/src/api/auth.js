/**
 * Created by jerry on 2017/11/13.
 * 用户相关api
 */
import * as AUTH from './'
import CONST from './contant'
import * as API from "./index";

export default {

  //转到登录页面
  loginpage:()  => {
    window.location.href = CONST.AUTHORIZEURL+"?client_id="+CONST.CLIENT_ID+"&response_type=code&scope=read&state=123456&redirect_uri="+CONST.REDIRECTURI;
  },
  authToken:(code) =>{
    console.log(code);
    let data = new FormData();
    data.append("client_id", CONST.CLIENT_ID);
    data.append("client_secret",CONST.CLIENT_SECRET);
    data.append("grant_type",CONST.GRANT_TYPE);
    data.append("code",code);
    data.append("redirect_uri",CONST.REDIRECTURI);
    return API.POST(CONST.GETTOKENURL, data)
  },
}
