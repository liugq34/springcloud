/**
 * Created by jerry on 2017/11/13.
 * 用户相关api
 */
import * as API from './'

export default {

  //查询所有组织tree
  findOrgList: () => {
    return API.GET('/api/sys/v1/organization/findAll')
  },
  getById: (id,resType) => {
    return API.GET('/api/sys/v1/organization/getById',{id:id,resType:resType})
  },
  addOrg: (params) => {
    return API.POST('/api/sys/v1/organization/save',params)
  },
  updateOrg: (params) => {
    return API.POST('/api/sys/v1/organization/update',params)
  },
  addUser: (params) => {
    return API.POST('/api/sys/v1/user/save',params)
  },
  updateUser: (params) => {
    return API.POST('/api/sys/v1/user/update',params)
  },
  delUser: (userid) => {
    return API.GET('/api/sys/v1/user/delete',{userid:userid})
  },
  updatepassword: (params) => {
    return API.POST('/api/sys/v1/user/updatepassword',params)
  }
}
