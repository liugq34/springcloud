//存储token字符串
const USERSTORE = "tokenInfo";
const AUTHHOST = "http://localhost:88";
const CLIENT_ID = 'client';
const CLIENT_SECRET = '123456';

const AUTHORIZEURL =  AUTHHOST+"/auth/oauth/authorize";
const GETTOKENURL = AUTHHOST+'/auth/oauth/token';
const LOGINOUT = AUTHHOST+'/auth/logout';
const  REDIRECTURI = "http://localhost:8081/authorize";
const GRANT_TYPE = 'authorization_code';



export default {
  USERSTORE,
  CLIENT_ID,
  CLIENT_SECRET,
  AUTHORIZEURL,
  GETTOKENURL,
  LOGINOUT,
  REDIRECTURI,
  GRANT_TYPE
}
