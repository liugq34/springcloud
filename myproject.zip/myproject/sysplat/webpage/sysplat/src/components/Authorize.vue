<template>

</template>

<script>
  import AUTH from '../api/auth'
  import storage from '../assets/js/storage'
  import CONST from '../api/contant'

    export default {
        name: "Authorize",
      mounted() {

        let that = this;

        AUTH.authToken(that.$route.query.code).then(function (result) {
          console.log(result);
          storage.set(CONST.USERSTORE,result)
          that.$router.push('/dashboard');
        }, function (err) {
          that.$message.error({showClose: true, message: err.toString(), duration: 2000});
        }).catch(function (error) {
          console.log(error);
          that.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        });
      }
    }
</script>

<style scoped>

</style>
