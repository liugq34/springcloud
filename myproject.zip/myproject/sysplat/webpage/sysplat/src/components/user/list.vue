<template>
  <el-row class="warp">
    <el-col :span="24" class="warp-breadcrum">
      <el-breadcrumb separator="/">
        <el-breadcrumb-item :to="{ path: '/' }"><b>首页</b></el-breadcrumb-item>
        <el-breadcrumb-item>用户列表</el-breadcrumb-item>
      </el-breadcrumb>
    </el-col>

    <el-col :span="8" class="warp-breadcrum">
    <el-tree
      v-loading="initload"
      class="filter-tree"
      :data="datatree"
      node-key="id"
      ref="tree"
      default-expanded-keys="[1]"
      @node-click="setClickNode"
      :props="defaultProps">
      <span class="custom-tree-node" slot-scope="{ node, data }">
            <span>
              <i class="icon-top" v-if="data.parentId==0"></i><i class="icon-org" v-else-if="data.resType == 'O'"></i><i class="icon-myuser" v-else></i>{{ node.label }}
            </span>
        </span>
    </el-tree>
    </el-col>
    <el-col :span="10"  >

      <el-button-group v-if="resType == 'O' && actionType == 'update'" class="act-button">

        <el-dropdown @command="handleObjCommand">
          <el-button type="primary" icon="el-icon-plus" size="small">
            添加对象<i class="el-icon-arrow-down el-icon--right"></i>
          </el-button>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item command="O">组织</el-dropdown-item>
            <el-dropdown-item command="U">用户</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>

        <el-button type="primary" class="el-icon-delete" size="small" @click="delOrg">删除</el-button>
        <el-button type="primary" icon="el-icon-sort" size="small">排序</el-button>

      </el-button-group>
      <el-button-group v-if="resType =='U' && actionType == 'update'" class="act-button">
        <el-button type="primary" icon="el-icon-edit" size="small" @click="actionType = 'pwd'">修改密码</el-button>
        <el-button type="primary" icon="el-icon-refresh" size="small">移动</el-button>
        <el-button type="primary" icon="el-icon-delete" size="small" @click="dialogVisible = true">删除</el-button>
      </el-button-group>

      <el-form ref="orgform" :model="orgform" :rules="orgrules" label-width="80px" v-if="resType =='O' && (actionType== 'add' ||actionType== 'update')" v-loading="loading">
        <el-form-item label="组织名称" prop="name">
        <el-input v-model="orgform.name"></el-input>
      </el-form-item>
        <el-form-item label="单位代码">
          <el-input v-model="orgform.unitcode"></el-input>
        </el-form-item>
        <el-form-item label="地址">
          <el-input v-model="orgform.address"></el-input>
        </el-form-item>
        <el-form-item label="联系人">
          <el-input v-model="orgform.linkman"></el-input>
        </el-form-item>
        <el-form-item label="联系方式">
          <el-input v-model="orgform.contact"></el-input>
        </el-form-item>
        <el-form-item label="其他说明">
          <el-input type="textarea" v-model="orgform.description"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmitOrg">确认</el-button>
        </el-form-item>
      </el-form>


      <el-form ref="user" :model="user" :rules="userrules" label-width="80px" v-if="resType =='U'&& (actionType== 'add' ||actionType== 'update')" v-loading="loading">
        <el-form-item label="姓　　名" prop="name">
          <el-input v-model="user.name"></el-input>
        </el-form-item>
        <el-form-item label="登录帐号" prop="loginid" v-if="actionType =='add'">
          <el-input v-model="user.loginid"></el-input>
        </el-form-item>
        <el-form-item label="登录帐号"   v-else>
           {{user.loginid}}
        </el-form-item>
        <el-form-item label="登录密码" v-if="actionType =='add'">
          <el-input v-model="user.password"></el-input>
        </el-form-item>
        <el-form-item label="性　　别">
          <el-radio-group v-model="user.sex">
            <el-radio   :label="1">男</el-radio>
            <el-radio   :label="2">女</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="手　　机">
          <el-input v-model="user.mobile"></el-input>
        </el-form-item>
        <el-form-item label="电　　话">
          <el-input v-model="user.officephone"></el-input>
        </el-form-item>

        <el-form-item label="联系地址">
          <el-input v-model="user.contact"></el-input>
        </el-form-item>

        <el-form-item label="邮件地址">
          <el-input v-model="user.email"></el-input>
        </el-form-item>
        <el-form-item label="截止日期">
          <el-date-picker
            v-model="user.expiredate"
            type="date"
            placeholder="选择日期时间"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="用户状态">
          <el-radio-group v-model="user.state">
            <el-radio   :label="1">正常</el-radio>
            <el-radio   :label="0">禁用</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="其他说明">
          <el-input type="textarea" v-model="user.description"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="onSubmitUser">确认</el-button>
        </el-form-item>
      </el-form>

      <el-form ref="userpwd" :model="userpwd" :rules="userpwdrules" label-width="80px" v-if="resType =='U' && actionType =='pwd'" v-loading="loading">
        <el-form-item label="姓　　名:">
          {{user.name}}
        </el-form-item>
        <el-form-item label="登录帐号:" >
          {{user.loginid}}
        </el-form-item>

        <el-form-item label="新 密 码" prop="password">
          <el-input v-model="userpwd.password"></el-input>
        </el-form-item>

        <el-form-item label="确认密码" prop="repassword">
          <el-input v-model="userpwd.repassword"></el-input>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" @click="updatePwd">确认</el-button>
        </el-form-item>
      </el-form>
      <el-dialog
        title="提示"
        :visible.sync="dialogVisible"
        width="20%" >
        <span>确认删除{{user.name}}？</span>
        <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="delUser">确 定</el-button>
  </span>
      </el-dialog>
    </el-col>
  </el-row>


</template>
<script>
  import API_USER from '../../api/api_user';

  export default {
    data() {
      return {
        dialogVisible: false,
        datatree: [],
        selectData:{},
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        orgform: {
          id:'',
          name: '',
          unitcode: '',
          address: '',
          linkman: '',
          contact: '',
          description: ''
        },
      user:{
        name: '',
        loginid: '',
        sex: '',
        state: '',
        officephone: '',
        mobile: '',
        contact: '',
        expiredate: '',
        description: ''
      },
        userpwd:{
          password:"",
          repassword:""
        },
        loading:false,
        initload:false,
        resType:'',  //O 组织，U 用户
        actionType:'update',  //add 新增，update 修改， pwd 修改密码
        orgrules:{
          name:[{ required: true, message: '请输入组织名称', trigger: 'blur' }]
        },
        userrules:{
          name:[{ required: true, message: '请输入用户姓名', trigger: 'blur' }],
          loginid:[{ required: true, message: '请输入登录账户', trigger: 'blur' }]
        },
        userpwdrules:{
          password:[{ required: true, message: '请输入新密码', trigger: 'blur' }],
          repassword:[{ required: true, message: '请输入确认密码', trigger: 'blur' }]
        }
      }

    },
    watch: {

    },
    methods: {
      handleObjCommand(command){
        if(command == "O"){
          this.addOrg();
        }else if(command == "U"){
          this.addUser();
        }
      },
      findOrgList(){
        API_USER.findOrgList().then( res => {
          this.initload = false;
          this.datatree = res.data;
        }).catch( error => {
          this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        });
      },
      setClickNode(obj,data,arr) {
        this.selectData = obj;
        console.log(this.selectData);
        this.actionType = "update";
        this.resType = obj.resType;
        this.loading = true;
        API_USER.getById(obj.objid,obj.resType).then( res => {

          this.loading = false;
          if('O' == this.selectData.resType){
            this.orgform = res.data;
          }else if('U' == this.selectData.resType){
            this.user = res.data;

          }
        }).catch( error => {
          this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        });
      },
      addOrg(){
        this.actionType = "add";
        this.resType = 'O';
        this.orgform = {};
      },
      addUser(){
        this.actionType = "add";
        this.resType = 'U'
        this.user = {};
      },
      onSubmitOrg(){
        this.$refs['orgform'].validate((valid) => {
          if (valid) {
            var params = this.orgform;
            if(this.actionType == 'add'){
              params.parentid = this.selectData.id;
              API_USER.addOrg(params).then( res => {
                if(res.state != 200){
                  this.$message.error({showClose: true, message: res.msg, duration: 2000});
                }else{
                  this.initload = true;
                  this.findOrgList();
                  this.resType = '';
                }
              }).catch( error => {
                this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
              });
            }else{
              params.organizeid = this.selectData.objid;
              API_USER.updateOrg(params).then( res => {
                if(res.state != 200){
                  this.$message.error({showClose: true, message: res.msg, duration: 2000});
                }else{
                  this.initload = true;
                  this.findOrgList();
                  this.resType = '';
                }
              }).catch( error => {
                this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
              });

            }


          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      onSubmitUser(){

        this.$refs['user'].validate((valid) => {
          if (valid) {
            var params = this.user;
            if(this.actionType == 'add'){
              params.organizeid = parseInt(this.selectData.id);
              API_USER.addUser(params).then( res => {
                if(res.state != 200){
                  this.$message.error({showClose: true, message: res.msg, duration: 2000});
                }else{
                  this.initload = true;
                  this.findOrgList();
                  this.resType = '';
                }
              }).catch( error => {
                this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
              });
            }else{
              params.userid = parseInt(this.selectData.objid);
              API_USER.updateUser(params).then( res =>{
                if(res.state != 200){
                  this.$message.error({showClose: true, message: res.msg, duration: 2000});
                }else{
                  this.initload = true;
                  this.findOrgList();
                  this.resType = '';
                }
              }).catch( error => {
                this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
              });
            }
          } else {
            console.log('error submit!!');
            return false;
          }
        });

      },
      delUser(){
        this.dialogVisible = false;
        API_USER.delUser(this.user.userid).then( res => {
          if(res.state != 200){
            this.$message.error({showClose: true, message: res.msg, duration: 2000});
          }else{
            this.$message({
              message: '删除成功',
              type: 'success'
            });
            this.initload = true;
            this.findOrgList();
            this.resType = '';
          }
        }).catch( error => {
          this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
        });
      },
      updatePwd(){

        this.$refs['userpwd'].validate((valid) => {
          if (valid) {

            var params = this.userpwd;
            params.userid = this.user.userid;
            API_USER.updatepassword(params).then(res => {
              if (res.state != 200) {
                this.$message.error({showClose: true, message: res.msg, duration: 2000});
              } else {
                this.$message({
                  message: '修改密码成功',
                  type: 'success'
                });
                this.resType = '';
              }
            }).catch(error => {
              this.$message.error({showClose: true, message: '请求出现异常', duration: 2000});
            });
          }else{
            console.log('error submit!!');
            return false;
          }
        })
      }
    },
    mounted() {
      this.initload = true;
      this.findOrgList();

    }
  }
</script>

<style scoped>
.icon-myuser{
  display: inline-block;
  background:url("../../assets/images/user.png") center left no-repeat;
  width:20px;
  height:20px;
}
.icon-top{
  display: inline-block;
  background:url("../../assets/images/top.png") center left no-repeat;
  width:20px;
  height:20px;
}
.icon-org{
  display: inline-block;
  background:url('../../assets/images/org.png') center left no-repeat;
  width:20px;
  height:20px;
}
.act-button{
    margin-bottom: 20px;
    margin-left: 100px;
  }
</style>
