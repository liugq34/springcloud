import Vue from 'vue'
import Router from 'vue-router'
import Home from '@/components/Home'
import Dashboard from '@/components/Dashboard'


import UserList from '@/components/user/list'


import AUTH from '../api/auth'
import storage from '../assets/js/storage'
import CONST from '../api/contant'

// 懒加载方式，当路由被访问的时候才加载对应组件
const Authorize = resolve => require(['@/components/Authorize'], resolve)

Vue.use(Router)

let router = new Router({
 mode: 'history',
  routes: [
    {
      path: '/authorize',
      name: '授权',
      component: Authorize
    },
    {
      path: '/',
      name: 'home',
      component: Home,
      redirect: '/dashboard',
      leaf: true, // 只有一个节点
      menuShow: true,
      iconCls: 'iconfont icon-home', // 图标样式class
      children: [
        {path: '/dashboard', component: Dashboard, name: '首页', menuShow: true}
      ]
    },
    {
      path: '/',
      component: Home,
      name: '用户管理',
      menuShow: true,
      leaf: true, // 只有一个节点
      iconCls: 'iconfont icon-users', // 图标样式class
      children: [
        {path: '/user/list', component: UserList, name: '用户列表', menuShow: true}
      ]
    }
  ]
})

router.beforeEach((to, from, next) => {

  let user = storage.get(CONST.USERSTORE);
   if(user){
    next();
  }else {
    if (to.path.startsWith('/authorize')){
      next();
    }else{
      storage.clear();
      AUTH.loginpage();
    }
  }

})

export default router
