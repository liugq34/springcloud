/**
 *f封装操作localStorage
 */
var storage = {

    set(key,obj){
        sessionStorage.setItem(key,JSON.stringify(obj))
    },
    get(key){
        return JSON.parse(sessionStorage.getItem(key));
    },
    remove(key){
        sessionStorage.removeItem(key);
    },
  clear(){
    sessionStorage.clear();
   }
}

export default  storage;
